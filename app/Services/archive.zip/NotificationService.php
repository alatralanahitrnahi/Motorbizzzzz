<?php

namespace App\Services;

use App\Models\User;
use App\Models\PurchaseOrder;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use App\Mail\PurchaseOrderApprovalMail;
use App\Notifications\PurchaseOrderNotification;

class NotificationService
{
    public function notifyPendingApproval(PurchaseOrder $purchaseOrder)
    {
        // 🔧 FIXED: No whereHas('roles'), we use role column directly
        $approvers = User::whereIn('role', ['admin', 'purchase_team', 'inventory_manager'])->get();

        foreach ($approvers as $approver) {
            // Send Email Notification
            if ($approver->email && ($approver->notification_preferences['email'] ?? true)) {
                $this->sendEmailNotification($approver, $purchaseOrder);
            }

            // Send SMS Notification
            if ($approver->phone && ($approver->notification_preferences['sms'] ?? false)) {
                $this->sendSmsNotification($approver, $purchaseOrder);
            }

            // Create Dashboard Notification
            $this->createDashboardNotification($approver, $purchaseOrder);
        }
    }

    private function sendEmailNotification(User $user, PurchaseOrder $purchaseOrder)
    {
        try {
            Mail::to($user->email)->send(new PurchaseOrderApprovalMail($purchaseOrder));
            Log::info("Approval email sent to {$user->email} for PO {$purchaseOrder->po_number}");
        } catch (\Exception $e) {
            Log::error("Failed to send approval email: " . $e->getMessage());
        }
    }

    private function sendSmsNotification(User $user, PurchaseOrder $purchaseOrder)
    {
        try {
            $message = "Purchase Order {$purchaseOrder->po_number} worth ₹" .
                       number_format($purchaseOrder->final_amount, 2) .
                       " is pending your approval. Login to review.";

            Log::info("SMS notification sent to {$user->phone} for PO {$purchaseOrder->po_number}");
        } catch (\Exception $e) {
            Log::error("Failed to send SMS notification: " . $e->getMessage());
        }
    }

    private function createDashboardNotification(User $user, PurchaseOrder $purchaseOrder)
    {
        $user->notifications()->create([
            'type' => 'dashboard',
            'data' => [
                'title' => 'Purchase Order Approval Required',
                'message' => "PO #{$purchaseOrder->po_number} requires your approval",
                'amount' => $purchaseOrder->final_amount,
                'vendor' => $purchaseOrder->vendor->name,
                'url' => route('purchase-orders.show', $purchaseOrder),
                'priority' => $purchaseOrder->final_amount > 50000 ? 'high' : 'normal'
            ]
        ]);
    }
}
