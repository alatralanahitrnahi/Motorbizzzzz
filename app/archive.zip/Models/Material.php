<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Material.php
class Material extends Model
{
    protected $fillable = [
        'name', 'code', 'description', 'unit', 'unit_price', 
        'gst_rate', 'category', 'is_active'
    ];

    protected $casts = [
        'unit_price' => 'decimal:2',
        'gst_rate' => 'decimal:2',
        'is_active' => 'boolean'
    ];

    public function purchaseOrderItems()
    {
        return $this->hasMany(PurchaseOrderItem::class);
    }

    public function inventoryBatches()
    {
        return $this->hasMany(InventoryBatch::class);
    }

    public function barcodes()
    {
        return $this->hasMany(Barcode::class);
    }

    public function getCurrentStock()
    {
        return $this->inventoryBatches()
            ->where('status', 'active')
            ->sum('current_quantity');
    }
}
