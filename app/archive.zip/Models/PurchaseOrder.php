<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    protected $fillable = [
        'po_number', 'vendor_id', 'po_date', 'expected_delivery',
        'total_amount', 'gst_amount', 'final_amount', 'shipping_cost',
        'payment_mode', 'credit_days', 'status', 'notes', 'supplier_contact'
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'gst_amount' => 'decimal:2',
        'final_amount' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'po_date' => 'date',
        'expected_delivery' => 'date',
          'status' => 'string'   // ✅ add this line
    ];

   // In PurchaseOrder.php model
public function vendor()
{
    return $this->belongsTo(Vendor::class);
}

public function purchaseOrderItems()
{
    return $this->hasMany(PurchaseOrderItem::class);
}

  
    public function items()
    {
        return $this->hasMany(PurchaseOrderItem::class);
    }

    public function inventoryBatches()
    {
        return $this->hasMany(InventoryBatch::class);
    }

    // Status constants
    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_ORDERED = 'ordered';
    const STATUS_RECEIVED = 'received';
    const STATUS_CANCELLED = 'cancelled';

    public function getStatusColorAttribute()
    {
        return [
            'pending' => 'warning',
            'approved' => 'info',
            'ordered' => 'primary',
            'received' => 'success',
            'cancelled' => 'danger'
        ][$this->status] ?? 'secondary';
    }

    public function getTotalItemsAttribute()
    {
        return $this->items()->sum('quantity');
    }

    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($model) {
            if (empty($model->po_number)) {
                $year = date('Y');
                $lastPo = static::where('po_number', 'like', "PO{$year}%")
                    ->orderBy('po_number', 'desc')
                    ->first();

                if ($lastPo) {
                    $lastNumber = intval(substr($lastPo->po_number, -6));
                    $newNumber = $lastNumber + 1;
                } else {
                    $newNumber = 1;
                }

                $model->po_number = 'PO' . $year . str_pad($newNumber, 6, '0', STR_PAD_LEFT);
            }
        });
    }


    // Relationships
    public function approvedBy()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // Status helper methods
    public function isPending()
    {
        return $this->status === 'pending';
    }

    public function isApproved()
    {
        return $this->status === 'approved';
    }

    public function isRejected()
    {
        return $this->status === 'rejected';
    }

    public function canBeApproved()
    {
        return $this->isPending();
    }

    public function canBeEdited()
    {
        return in_array($this->status, ['pending', 'rejected']);
    }

    // Approval workflow methods
    public function approve(User $approver, $notes = null)
    {
        $oldStatus = $this->status;
        
        $this->update([
            'status' => 'approved',
            'approved_by' => $approver->id,
            'approved_at' => now(),
            'approval_notes' => $notes
        ]);

        event(new \App\Events\PurchaseOrderStatusChanged($this, $oldStatus, 'approved'));
    }

    public function reject(User $approver, $notes)
    {
        $oldStatus = $this->status;
        
        $this->update([
            'status' => 'rejected',
            'approved_by' => $approver->id,
            'approved_at' => now(),
            'approval_notes' => $notes
        ]);

        event(new \App\Events\PurchaseOrderStatusChanged($this, $oldStatus, 'rejected'));
    }

    // Scopes
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }

    public function scopeRequiresApproval($query, User $user)
    {
        return $query->where('status', 'pending')
                    ->where('created_by', '!=', $user->id);
    }
}

