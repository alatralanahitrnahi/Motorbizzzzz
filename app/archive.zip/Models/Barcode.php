<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Barcode extends Model
{
    protected $fillable = [
        'barcode_number',
        'batch_id',
        'purchase_order_id',
        'material_id',
        'material_name',
        'material_code',
        'supplier_name',
        'quantity',
        'weight',
        'unit_price',
        'expiry_date',
        'storage_location',
        'quality_grade',
        'barcode_type',
        'status',
        'notes',
        'qr_code_data',
      'created_by',
      
    ];
  protected $casts = [
    'expiry_date' => 'datetime',
];


    public static function generateBarcodeNumber()
    {
        do {
            $number = 'BC' . strtoupper(uniqid()); // Example: BC65F3A4BDE
        } while (self::where('barcode_number', $number)->exists());

        return $number;
    }

    public function generateQRData()
    {
        return json_encode([
            'barcode_number'   => $this->barcode_number,
            'material_code'    => $this->material_code,
            'material_name'    => $this->material_name,
            'batch_number'     => optional($this->batch)->batch_number,
            'supplier_name'    => $this->supplier_name,
            'expiry_date'      => $this->expiry_date,
            'storage_location' => $this->storage_location,
            'quality_grade'    => $this->quality_grade,
        ]);
    }

public function batch()
{
    return $this->belongsTo(InventoryBatch::class, 'batch_id');
}
  public function purchaseOrder()
{
    return $this->belongsTo(PurchaseOrder::class);
}

public function material()
{
    return $this->belongsTo(Material::class);
}

}