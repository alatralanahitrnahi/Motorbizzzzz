<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'is_active',
        'email_verified_at',
        'notification_preferences',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'last_login_at' => 'datetime',
        'is_active' => 'boolean',
        'notification_preferences' => 'array',
    ];

    /**
     * Role display name (for UI)
     */
    public function getRoleDisplayName()
    {
        $roleDisplayNames = [
            'admin' => 'Administrator',
            'purchase_team' => 'Purchase Team',
            'inventory_manager' => 'Inventory Manager',
            'user' => 'User',
        ];

        return $roleDisplayNames[$this->role] ?? ucfirst(str_replace('_', ' ', $this->role));
    }

    /**
     * Active status display
     */
    public function getStatusDisplayAttribute()
    {
        return $this->is_active ? 'Active' : 'Inactive';
    }

    /**
     * Main role checker. Supports string or array input.
     */
    public function hasRole($roles): bool
    {
        return in_array($this->role, (array) $roles);
    }

    /**
     * Individual role shortcut helpers
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    public function isPurchaseTeam()
    {
        return $this->role === 'purchase_team';
    }

    public function isInventoryManager()
    {
        return $this->role === 'inventory_manager';
    }

    /**
     * Is active checker
     */
    public function isActive()
    {
        return $this->is_active;
    }

    /**
     * Scope for active users
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope for role filtering
     */
    public function scopeByRole($query, $role)
    {
        return $query->where('role', $role);
    }

    /**
     * Notification preferences helper
     */
    public function getNotificationPreferences()
    {
        return [
            'email' => $this->notification_preferences['email'] ?? true,
            'sms' => $this->notification_preferences['sms'] ?? false,
            'dashboard' => $this->notification_preferences['dashboard'] ?? true,
        ];
    }

    public function updateNotificationPreferences(array $preferences)
    {
        $this->update([
            'notification_preferences' => array_merge(
                $this->notification_preferences ?? [],
                $preferences
            )
        ]);
    }

    /**
     * Dashboard notifications shortcut
     */
    public function dashboardNotifications()
    {
        return $this->notifications()->where('type', 'dashboard');
    }

    /**
     * Relationship: Purchase Orders created by this user
     */
    public function purchaseOrders()
    {
        return $this->hasMany(PurchaseOrder::class, 'created_by');
    }
}
