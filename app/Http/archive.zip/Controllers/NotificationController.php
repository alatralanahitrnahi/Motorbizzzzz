<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\Notification;

class NotificationController extends Controller
{
    public function index()
    {
        $notifications = Notification::where('notifiable_id', Auth::id())
                            ->where('notifiable_type', User::class)
                            ->where('type', 'dashboard')
                            ->orderBy('created_at', 'desc')
                            ->paginate(20);

        return view('notifications.index', compact('notifications'));
    }

    public function markAsRead($id)
    {
        $notification = Notification::where('notifiable_id', Auth::id())->findOrFail($id);
        $notification->update(['read_at' => now()]);
        return response()->json(['success' => true]);
    }

    public function markAllAsRead()
    {
        Notification::where('notifiable_id', Auth::id())
            ->whereNull('read_at')
            ->update(['read_at' => now()]);
            
        return response()->json(['success' => true]);
    }

    public function getUnreadCount()
    {
        $count = Notification::where('notifiable_id', Auth::id())
                    ->where('type', 'dashboard')
                    ->whereNull('read_at')
                    ->count();

        return response()->json(['count' => $count]);
    }
}
