<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\InventoryItem;
use App\Models\PurchaseOrder;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display the dashboard
     */
  public function index()
{
    $user = Auth::user();

    $stats = $this->getDashboardStats($user); // or a simple stats array

    return view('dashboard.index', compact('user', 'stats'));
}

    /**
     * Get dashboard statistics based on user role
     */
    private function getDashboardStats($user)
    {
        $stats = [];

        switch ($user->role) {
            case 'admin':
                $stats = [
                    'total_users' => User::count(),
                    'active_users' => User::where('is_active', 1)->count(),
                    'inactive_users' => User::where('is_active', 0)->count(),
                    'admin_users' => User::where('role', 'admin')->count(),
                    'purchase_team_users' => User::where('role', 'purchase_team')->count(),
                    'inventory_managers' => User::where('role', 'inventory_manager')->count(),
                    'total_inventory_items' => InventoryItem::count(),
                    'low_stock_items' => InventoryItem::where('quantity', '<=', 10)->count(),
                    'recent_logins' => User::where('last_login_at', '>=', now()->subDays(7))->count(),
                    'total_records' => $this->getTotalRecords(),
                    'system_health' => 98,
                ];
                break;

            case 'purchase_team':
                $stats = [
                    'pending_orders' => PurchaseOrder::where('status', 'pending')->count(),
                    'completed_orders' => PurchaseOrder::where('status', 'completed')->count(),
                    'total_orders' => PurchaseOrder::count(),
                    'completed_today' => PurchaseOrder::where('status', 'completed')
                        ->whereDate('updated_at', today())
                        ->count(),
                    'monthly_budget' => $this->getMonthlyBudget(),
                    'in_transit' => PurchaseOrder::where('status', 'in_transit')->count(),
                ];
                break;

            case 'inventory_manager':
                $stats = [
                    'total_items' => InventoryItem::count(),
                    'low_stock_items' => InventoryItem::where('quantity', '<=', 10)->count(),
                    'out_of_stock' => InventoryItem::where('quantity', 0)->count(),
                   // 'categories' => DB::connection('inventory_db')->table('categories')->count(),
                    'items_added_today' => InventoryItem::whereDate('created_at', today())->count(),
                    'total_warehouses' => $this->getTotalWarehouses(),
                ];
                break;

            default:
                $stats = [
                    'profile_completion' => $this->getProfileCompletion($user),
                    'last_activity' => $user->updated_at?->diffForHumans() ?? 'Never',
                ];
                break;
        }

        $stats['user_role'] = $user->getRoleDisplayName();
        $stats['last_login'] = $user->last_login_at?->diffForHumans() ?? 'First time login';

        return $stats;
    }

    /**
     * Show users management page
     */
    public function showUsers(Request $request)
    {
        $user = Auth::user();

        if (!$user->isAdmin()) {
            return redirect()->route('dashboard')->with('error', 'You do not have permission to view this page.');
        }

        $query = User::query();

       if ($request->filled('search')) {
    $search = $request->get('search');
    $query->where(function ($q) use ($search) {
        $q->where('name', 'like', "%{$search}%")
            ->orWhere('email', 'like', "%{$search}%");
    }); // ✅ Close the closure & method
}

        if ($request->filled('role')) {
            $query->where('role', $request->get('role'));
        }

        if ($request->filled('is_active')) {
            $query->where('is_active', $request->get('is_active'));
        }

        $users = $query->orderBy('created_at', 'desc')->paginate(15);

        $stats = [
            'total_users' => User::count(),
            'active_users' => User::where('is_active', 1)->count(),
            'inactive_users' => User::where('is_active', 0)->count(),
            'total_vendors' => Vendor::count(),
        'total_items' => Inventory::count(),
        'total_orders' => PurchaseOrder::count(),
        ];

        return view('dashboard.users', compact('users', 'stats'));
    }

    /**
     * Store a new user
     */
    public function storeUser(Request $request)
    {
        $user = Auth::user();

        if (!$user->isAdmin()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'is_active' => 'required|boolean',
            'phone' => 'nullable|string|max:20',
        ]);

        try {
            $newUser = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'role' => $validated['role'],
                'is_active' => $validated['is_active'],
                'phone' => $validated['phone'],
                'email_verified_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'User created successfully!',
                'user' => $newUser
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to create user: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update user active status
     */
    public function updateUserStatus(Request $request, User $user)
    {
        $currentUser = Auth::user();

        if (!$currentUser->isAdmin()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        $validated = $request->validate([
            'is_active' => 'required|boolean'
        ]);

        $user->update(['is_active' => $validated['is_active']]);

        return response()->json([
            'success' => true,
            'message' => 'User activation status updated successfully!'
        ]);
    }

    /**
     * Deactivate a user (soft delete)
     */
    public function deleteUser(User $user)
    {
        $currentUser = Auth::user();

        if (!$currentUser->isAdmin()) {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        if ($user->id === $currentUser->id) {
            return response()->json(['error' => 'You cannot deactivate your own account'], 400);
        }

        try {
            $user->update(['is_active' => 0]);

            return response()->json([
                'success' => true,
                'message' => 'User deactivated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to deactivate user: ' . $e->getMessage()
            ], 500);
        }
    }

    // Placeholder methods if called
    private function getProfileCompletion($user)
    {
        return 100; // Simulated completion
    }

    private function getTotalRecords()
    {
        return 1024; // Example data
    }

    private function getMonthlyBudget()
    {
        return 150000; // Example data
    }

    private function getTotalWarehouses()
    {
        return 12; // Example data
    }
}
