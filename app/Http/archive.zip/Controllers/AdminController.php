<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\SoftDeletes;


class AdminController extends Controller
{
  
 public function users()
{
    $users = User::paginate(10); // paginate with 10 users per page

    $stats = [
        'total_users' => User::count(),
        'active_users' => User::where('role', 'is_active')->count(),
        'inactive_users' => User::where('role', 'is_active')->count(),
    ];

    return view('dashboard.users.index', compact('users', 'stats'));
}


    /**
     * Display a listing of users with search and filter functionality
     */
    public function index(Request $request)
    {
        // Base query
        $query = User::query();

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%");
            });
        }

        // Role filter
        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }

        // Status filter
        if ($request->filled('status')) {
            $isActive = $request->status === 'active';
            $query->where('is_active', $isActive);
        }

        // Get paginated users
        $users = $query->orderBy('created_at', 'desc')->paginate(15);
        
        // Append query parameters to pagination links
        $users->appends($request->query());

        // Calculate statistics
        $stats = [
            'total_users' => User::count(),
            'active_users' => User::where('is_active', true)->count(),
            'inactive_users' => User::where('is_active', false)->count(),
            'admin_users' => User::where('role', 'admin')->count(),
        ];

        return view('dashboard.users.index', compact('stats', 'users'));
    }

    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        $roles = [
            'admin' => 'Administrator',
            'purchase_team' => 'Purchase Team',
            'inventory_manager' => 'Inventory Manager',
            'user' => 'User'
        ];
        
        return view('dashboard.users.create', compact('roles'));
    }

    /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'status' => 'required|in:active,inactive',
            'send_welcome_email' => 'boolean'
        ]);

        if ($validator->fails()) {
            return $this->handleValidationError($validator, $request);
        }

        try {
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => $request->role,
                'is_active' => $request->status === 'active',
            ]);

            // Handle welcome email if requested
            if ($request->send_welcome_email) {
                // Mail::to($user->email)->send(new WelcomeEmail($user, $request->password));
                // Uncomment and create WelcomeEmail mailable
            }

            return $this->handleSuccess('User created successfully.', $request);
            
        } catch (\Exception $e) {
            Log::error('User creation failed: ' . $e->getMessage());
            return $this->handleError('Failed to create user. Please try again.', $request);
        }
    }

    /**
     * Display the specified user
     */
    public function show(User $user)
    {
        return view('dashboard.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user
     */
    public function edit(User $user)
    {
        $roles = [
            'admin' => 'Administrator',
            'purchase_team' => 'Purchase Team',
            'inventory_manager' => 'Inventory Manager',
            'user' => 'User'
        ];
        
        return view('dashboard.users.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified user in storage - ENHANCED WITH DEBUGGING
     */
    public function update(Request $request, User $user)
    {
        // STEP 1: Log initial state
        Log::info('=== UPDATE METHOD CALLED ===');
        Log::info('User ID: ' . $user->id);
        Log::info('Request Method: ' . $request->method());
        Log::info('Request URL: ' . $request->url());
        Log::info('All Request Data: ', $request->all());
        Log::info('User before update: ', $user->toArray());

        // STEP 2: Check database connection
        try {
            DB::connection()->getPdo();
            Log::info('Database connection: OK');
        } catch (\Exception $e) {
            Log::error('Database connection failed: ' . $e->getMessage());
            return $this->handleError('Database connection failed.', $request);
        }

        // STEP 3: Validation
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users')->ignore($user->id)
            ],
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'status' => 'required|in:active,inactive'
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed: ', $validator->errors()->toArray());
            return $this->handleValidationError($validator, $request);
        }

        Log::info('Validation passed successfully');

        try {
            // STEP 4: Prepare update data
            $updateData = [
                'name' => $request->name,
                'email' => $request->email,
                'role' => $request->role,
                'is_active' => $request->status === 'active',
            ];

            // Only update password if provided
            if ($request->filled('password')) {
                $updateData['password'] = Hash::make($request->password);
                Log::info('Password will be updated');
            }

            Log::info('Update data prepared: ', $updateData);

            // STEP 5: Check if user model allows these fields
            $fillableFields = $user->getFillable();
            Log::info('User fillable fields: ', $fillableFields);

            // STEP 6: Try multiple update methods
            
            // METHOD 1: Using update() method
            Log::info('Attempting update using update() method...');
            $updateResult = $user->update($updateData);
            Log::info('Update method result: ' . ($updateResult ? 'SUCCESS' : 'FAILED'));

            // METHOD 2: Alternative approach if update() fails
            if (!$updateResult) {
                Log::info('Trying alternative approach with fill() and save()...');
                $user->fill($updateData);
                $saveResult = $user->save();
                Log::info('Save method result: ' . ($saveResult ? 'SUCCESS' : 'FAILED'));
            }

            // STEP 7: Verify the update worked
            $user->refresh(); // Reload from database
            Log::info('User after update attempt: ', $user->toArray());

            // STEP 8: Check if the data actually changed
            $originalData = $user->getOriginal();
            $currentData = $user->getAttributes();
            
            $hasChanged = false;
            foreach ($updateData as $key => $value) {
                if ($key === 'password') continue; // Skip password comparison
                if (isset($originalData[$key]) && $originalData[$key] != $currentData[$key]) {
                    $hasChanged = true;
                    Log::info("Field '{$key}' changed from '{$originalData[$key]}' to '{$currentData[$key]}'");
                }
            }

            if (!$hasChanged && !$request->filled('password')) {
                Log::warning('No fields were actually updated in the database!');
            }

            // STEP 9: Manual database check
            $dbUser = User::find($user->id);
            Log::info('Direct database query result: ', $dbUser->toArray());

            return $this->handleSuccess('User updated successfully.', $request);
                
        } catch (\Exception $e) {
            Log::error('User update failed with exception: ' . $e->getMessage());
            Log::error('Exception file: ' . $e->getFile() . ' line: ' . $e->getLine());
            Log::error('Stack trace: ' . $e->getTraceAsString());
            return $this->handleError('Failed to update user. Please try again.', $request);
        }
    }

    /**
     * ALTERNATIVE UPDATE METHOD - Use this if the above doesn't work
     */
    public function updateAlternative(Request $request, User $user)
    {
        Log::info('=== ALTERNATIVE UPDATE METHOD ===');
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string', 
                'email',
                'max:255',
                Rule::unique('users')->ignore($user->id)
            ],
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'status' => 'required|in:active,inactive'
        ]);

        if ($validator->fails()) {
            return $this->handleValidationError($validator, $request);
        }

        try {
            // Direct property assignment
            $user->name = $request->name;
            $user->email = $request->email;
            $user->role = $request->role;
            $user->is_active = $request->status === 'active';
            
            if ($request->filled('password')) {
                $user->password = Hash::make($request->password);
            }

            $result = $user->save();
            Log::info('Direct property assignment result: ' . ($result ? 'SUCCESS' : 'FAILED'));

            return $this->handleSuccess('User updated successfully.', $request);

        } catch (\Exception $e) {
            Log::error('Alternative update failed: ' . $e->getMessage());
            return $this->handleError('Failed to update user.', $request);
        }
    }

public function destroy(User $user)
{
    $user->delete();

    return redirect()->route('dashboard.users.index')->with('success', 'User deleted successfully.');
}

    /**
     * Toggle user status (active/inactive)
     */
    public function toggleStatus(Request $request, User $user)
    {
        try {
            $this->authorize('toggleStatus', $user);

            $request->validate([
                'status' => 'required|in:active,inactive'
            ]);

            $newStatus = $request->status === 'active';
            
            $user->update([
                'is_active' => $newStatus
            ]);

            return response()->json([
                'success' => true,
                'status' => $request->status,
                'message' => "User status updated to {$request->status} successfully."
            ]);
            
        } catch (\Illuminate\Auth\Access\AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'error' => 'You are not authorized to change this user\'s status.'
            ], 403);
            
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to update user status.'
            ], 500);
        }
    }

    /**
     * Handle validation errors gracefully for both web and API requests.
     */
    private function handleValidationError($validator, $request)
    {
        if ($request->expectsJson()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        
        return redirect()->back()
            ->withErrors($validator)
            ->withInput();
    }

    /**
     * Handle success responses for both web and API requests.
     */
    private function handleSuccess($message, $request, $redirectRoute = 'dashboard.users.index')
    {
        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => $message
            ]);
        }

        return redirect()->route($redirectRoute)->with('success', $message);
    }

    /**
     * Handle error responses for both web and API requests.
     */
    private function handleError($message, $request)
    {
        if ($request->expectsJson()) {
            return response()->json([
                'success' => false,
                'error' => $message
            ], 500);
        }
        
        return redirect()->back()
            ->with('error', $message)
            ->withInput();
    }

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('can:manage-users');
    }
}