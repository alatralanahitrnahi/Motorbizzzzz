<?php

namespace App\Http\Controllers;

use App\Models\Material;
use Illuminate\Http\Request;

class MaterialController extends Controller
{
    // Display a listing of materials
    public function index()
    {
        $materials = Material::orderBy('created_at', 'desc')->paginate(10);
        return view('materials.index', compact('materials'));
    }

    // Show the form for creating a new material
    public function create()
    {
        return view('materials.create');
    }

   public function store(Request $request)
{
    $validatedData = $request->validate([
        'name' => ['required', 'string', 'max:100'],
        'code' => ['required', 'string', 'max:50', 'alpha_num', 'unique:materials,code'],
        'description' => ['nullable', 'string', 'max:500'],
        'unit' => ['required', 'string', 'max:10'],
        'unit_price' => ['required', 'numeric', 'min:0'],
        'gst_rate' => ['required', 'numeric', 'between:0,100'],
        'category' => ['nullable', 'string', 'max:100'],
        'is_active' => ['required', 'boolean'],
    ]);

    Material::create($validatedData);

    return redirect()->route('materials.index')->with('success', 'Material created successfully.');
}

public function update(Request $request, Material $material)
{
    $validatedData = $request->validate([
        'name' => 'required|string|max:100',
        'code' => 'required|string|max:50|alpha_num|unique:materials,code,' . $material->id,
        'description' => 'nullable|string|max:500',
        'unit' => 'required|string|max:10',
        'unit_price' => 'required|numeric|min:0',
        'gst_rate' => 'required|numeric|between:0,100',
        'category' => 'nullable|string|max:100',
        'is_active' => 'required|boolean',
    ]);

    $material->update($validatedData);

    return redirect()->route('materials.index')->with('success', 'Material updated successfully.');
}

    // Display the specified material
    public function show(Material $material)
    {
        return view('materials.show', compact('material'));
    }

    // Show the form for editing the specified material
    public function edit(Material $material)
    {
        return view('materials.edit', compact('material'));
    }

   

    // Remove the specified material from storage
    public function destroy(Material $material)
    {
        $material->delete();
        return redirect()->route('materials.index')->with('success', 'Material deleted successfully.');
    }
}
