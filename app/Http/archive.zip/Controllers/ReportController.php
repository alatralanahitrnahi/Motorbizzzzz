<?php

namespace App\Http\Controllers;

use App\Models\InventoryTransaction;
use App\Models\Material;
use Illuminate\Http\Request;
use Carbon\Carbon;
use PDF;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\TransactionsExport;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $materials = Material::all();
        $transactions = $this->getFilteredTransactions($request)->paginate(20);
        
        return view('reports.index', compact('transactions', 'materials'));
    }

    public function exportExcel(Request $request)
    {
        try {
            return Excel::download(new TransactionsExport($request), 'inventory_transactions_' . date('Y-m-d') . '.xlsx');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to export Excel file: ' . $e->getMessage());
        }
    }

    public function exportPDF(Request $request)
    {
        try {
            $transactions = $this->getFilteredTransactions($request)->get();
            $filters = $this->getFilterLabels($request);
            
            $pdf = PDF::loadView('reports.pdf', compact('transactions', 'filters'))
                     ->setPaper('a4', 'landscape');
            
            return $pdf->download('inventory_transactions_' . date('Y-m-d') . '.pdf');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to export PDF file: ' . $e->getMessage());
        }
    }

    /**
     * Get filtered transactions query
     */
    private function getFilteredTransactions(Request $request)
    {
        $query = InventoryTransaction::query()->with('batch.material');

        // Date range filter
        if ($request->filled('from_date') && $request->filled('to_date')) {
            try {
                $fromDate = Carbon::parse($request->from_date)->startOfDay();
                $toDate = Carbon::parse($request->to_date)->endOfDay();
                $query->whereBetween('transaction_date', [$fromDate, $toDate]);
            } catch (\Exception $e) {
                // Handle invalid date format
            }
        }

        // Material filter
        if ($request->filled('material_id')) {
            $query->whereHas('batch', function($q) use ($request) {
                $q->where('material_id', $request->material_id);
            });
        }

        // Type filter
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        return $query->latest('transaction_date');
    }

    /**
     * Get filter labels for PDF export
     */
    private function getFilterLabels(Request $request)
    {
        $filters = [];

        if ($request->filled('from_date') && $request->filled('to_date')) {
            $filters['date_range'] = $request->from_date . ' to ' . $request->to_date;
        }

        if ($request->filled('material_id')) {
            $material = Material::find($request->material_id);
            $filters['material'] = $material ? $material->name : 'Unknown';
        }

        if ($request->filled('type')) {
            $filters['type'] = ucfirst($request->type);
        }

        return $filters;
    }
}