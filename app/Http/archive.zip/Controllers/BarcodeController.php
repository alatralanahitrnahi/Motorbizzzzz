<?php

// =============================================================================
// CONTROLLER: app/Http/Controllers/BarcodeController.php
// =============================================================================

namespace App\Http\Controllers;

use App\Models\Barcode;
use App\Models\InventoryBatch;
use App\Models\PurchaseOrder;
use App\Models\Material;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Picqer\Barcode\BarcodeGeneratorPNG;
use Milon\Barcode\DNS1D;
use Illuminate\Validation\Rule;
use Carbon\Carbon;

class BarcodeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $query = Barcode::with(['batch.material', 'batch.purchaseOrder', 'purchaseOrder', 'material']);

        // Apply filters
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('barcode_number', 'like', "%{$search}%")
                  ->orWhere('material_name', 'like', "%{$search}%")
                  ->orWhere('supplier_name', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('material_id')) {
            $query->where('material_id', $request->material_id);
        }

        if ($request->filled('expiry_filter')) {
            if ($request->expiry_filter == 'expired') {
                $query->where('expiry_date', '<', now());
            } elseif ($request->expiry_filter == 'expiring_soon') {
                $query->whereBetween('expiry_date', [now(), now()->addDays(7)]);
            }
        }

        $barcodes = $query->orderBy('created_at', 'desc')->paginate(20);
        $materials = Material::orderBy('name')->get();

        return view('barcode.index', compact('barcodes', 'materials'));
    }

    public function create()
    {
        $batches = InventoryBatch::with(['material', 'purchaseOrder.vendor'])
                                ->where('status', 'active')
                                ->orderBy('created_at', 'desc')
                                ->get();
        
        return view('barcode.create', compact('batches'));
    }

 public function store(Request $request)
{
    try {
    $request->validate([
        'batch_id' => 'required|exists:inventory_batches,id',
        'barcode_type' => 'required|in:standard,qr,both',
        'print_quantity' => 'required|integer|min:1|max:100',
        'notes' => 'nullable|string|max:500',
    ]);

    DB::beginTransaction();

    \Log::info('Fetching batch...');
    $batch = InventoryBatch::with(['material', 'purchaseOrder.vendor', 'supplier'])->findOrFail($request->batch_id);

    \Log::info('Generating barcodes...');
    $barcodes = [];

    for ($i = 0; $i < $request->print_quantity; $i++) {
        $barcodeNumber = Barcode::generateBarcodeNumber();
        \Log::info("Generated barcode number: $barcodeNumber");

        if (empty($barcodeNumber) || strlen($barcodeNumber) < 3) {
            throw new \Exception("Invalid barcode number: $barcodeNumber");
        }

        $barcode = new Barcode([
            'barcode_number'   => $barcodeNumber,
            'batch_id'         => $batch->id,
            'purchase_order_id'=> $batch->purchase_order_id,
            'material_id'      => $batch->material_id,
            'material_name'    => optional($batch->material)->name,
            'material_code'    => optional($batch->material)->code,
            'supplier_name'    => $this->getSupplierName($batch),
            'quantity'         => $batch->current_quantity,
            'weight'           => $batch->current_weight,
            'unit_price'       => $batch->unit_price,
            'expiry_date'      => $batch->expiry_date,
            'storage_location' => $batch->storage_location,
            'quality_grade'    => $batch->quality_grade,
            'barcode_type'     => $request->barcode_type,
            'status'           => 'active',
            'notes'            => $request->notes,
            'created_by'       => Auth::id(),
        ]);

        $barcode->qr_code_data = $barcode->generateQRData();

        if (!$barcode->save()) {
            throw new \Exception("Failed to save barcode number: $barcodeNumber");
        }

        $barcodes[] = $barcode;
    }

    DB::commit();
    \Log::info('Barcodes generated successfully');
    return redirect()->route('barcode.index')->with('success', 'Barcodes generated successfully.');
} catch (\Exception $e) {
    DB::rollBack();
    \Log::error('Barcode generation failed: ' . $e->getMessage());
    return back()
        ->withErrors(['error' => 'Failed to generate barcodes. Please try again.'])
        ->with('error', $e->getMessage()); // Show real error for debugging
}
}
private function getSupplierName($batch)
{
    if ($batch->purchaseOrder && $batch->purchaseOrder->vendor) {
        return $batch->purchaseOrder->vendor->name;
    }

    if ($batch->supplier) {
        return $batch->supplier->name;
    }

    return 'No Supplier';
}

  
     public function show(Barcode $barcode)
    {
        $barcode->load(['batch.material', 'batch.purchaseOrder', 'purchaseOrder', 'material']);
        return view('barcode.show', compact('barcode'));
    }
  
 public function edit(Barcode $barcode)
    {
        $barcode->load(['batch.material', 'batch.purchaseOrder', 'purchaseOrder', 'material']);

        $materials = Material::orderBy('name')->get();
        $batches = InventoryBatch::with(['material', 'purchaseOrder'])
                    ->where('status', 'active')
                    ->orderBy('created_at', 'desc')
                    ->get();

        return view('barcode.edit', compact('barcode', 'materials', 'batches'));
    }

    public function update(Request $request, Barcode $barcode)
    {
        // Enhanced validation for edit functionality
        $request->validate([
            'material_name' => 'nullable|string|max:255',
            'material_code' => 'nullable|string|max:100',
            'supplier_name' => 'nullable|string|max:255',
            'quantity' => 'nullable|numeric|min:0',
            'weight' => 'nullable|numeric|min:0',
            'unit_price' => 'nullable|numeric|min:0',
            'expiry_date' => 'nullable|date',
            'storage_location' => 'required|string|max:100',
            'quality_grade' => 'required|in:A,B,C,D',
            'status' => 'required|in:active,inactive,damaged,expired',
            'notes' => 'nullable|string|max:500'
        ]);

        // Update all editable fields
        $updateData = [
            'storage_location' => $request->storage_location,
            'quality_grade' => $request->quality_grade,
            'status' => $request->status,
            'notes' => $request->notes,
            'updated_by' => Auth::id(),
            'updated_at' => now()
        ];

        // Add optional fields if provided
        if ($request->filled('material_name')) {
            $updateData['material_name'] = $request->material_name;
        }
        
        if ($request->filled('material_code')) {
            $updateData['material_code'] = $request->material_code;
        }
        
        if ($request->filled('supplier_name')) {
            $updateData['supplier_name'] = $request->supplier_name;
        }
        
        if ($request->filled('quantity')) {
            $updateData['quantity'] = $request->quantity;
        }
        
        if ($request->filled('weight')) {
            $updateData['weight'] = $request->weight;
        }
        
        if ($request->filled('unit_price')) {
            $updateData['unit_price'] = $request->unit_price;
        }
        
        if ($request->filled('expiry_date')) {
            $updateData['expiry_date'] = $request->expiry_date;
        }

        try {
            $barcode->update($updateData);
            
            // Regenerate QR code data if material info changed
            if ($request->filled(['material_name', 'material_code', 'supplier_name'])) {
                $barcode->qr_code_data = $barcode->generateQRData();
                $barcode->save();
            }

            return redirect()->route('barcode.show', $barcode)
                            ->with('success', 'Barcode updated successfully!');
        } catch (\Exception $e) {
            return back()->withInput()
                        ->withErrors(['error' => 'Failed to update barcode: ' . $e->getMessage()]);
        }
    }
  
    public function destroy(Barcode $barcode)
    {
        try {
            $barcode->update([
                'status' => 'inactive',
                'updated_by' => Auth::id(),
                'updated_at' => now()
            ]);
            
            return redirect()->route('barcode.index')
                            ->with('success', 'Barcode deactivated successfully!');
        } catch (\Exception $e) {
            \Log::error('Barcode deactivation failed: ' . $e->getMessage());
            return back()->withErrors(['error' => 'Failed to deactivate barcode. Please try again.']);
        }
    }

    public function batchPrint(Request $request)
    {
        // Get the IDs from the query parameter
        $ids = $request->input('ids');
        
        if (empty($ids)) {
            return redirect()->route('barcode.index')->with('error', 'No barcodes selected for printing.');
        }
        
        // Convert comma-separated string to array if needed
        if (is_string($ids)) {
            $ids = explode(',', $ids);
            $ids = array_filter($ids); // Remove empty values
        }
        
        // Validate that IDs are numeric
        $ids = array_filter($ids, 'is_numeric');
        
        if (empty($ids)) {
            return redirect()->route('barcode.index')->with('error', 'Invalid barcode IDs provided.');
        }
        
        // Fetch the barcodes with their related data
        $barcodes = Barcode::with(['batch.material', 'batch.purchaseOrder.vendor', 'material', 'purchaseOrder.vendor'])
                          ->whereIn('id', $ids)
                          ->get();
        
        if ($barcodes->isEmpty()) {
            return redirect()->route('barcode.index')->with('error', 'No valid barcodes found for printing.');
        }
        
        return view('barcode.batch-print', compact('barcodes'));
    }
  public function generateBarcode($number)
    {
        // Generate barcode image
        $generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
        $barcode = $generator->getBarcode($number, $generator::TYPE_CODE_128);
        
        return response($barcode)
            ->header('Content-Type', 'image/png')
            ->header('Cache-Control', 'public, max-age=3600');
    }
    public function generateQR($data)
    {
        try {
            // Validate and decode data
            $qrData = base64_decode($data);
            
            if (empty($qrData)) {
                throw new \Exception('Invalid QR data');
            }

            $qrCode = QrCode::format('png')->size(200)->generate($qrData);

            return response($qrCode)
                ->header('Content-Type', 'image/png')
                ->header('Cache-Control', 'public, max-age=3600');
        } catch (\Exception $e) {
            // Generate error QR code
            $qrCode = QrCode::format('png')->size(200)->generate('QR Code Error');
            return response($qrCode)->header('Content-Type', 'image/png');
        }
    }

    public function scan(Request $request)
    {
        $request->validate([
            'barcode_number' => 'required|string'
        ]);

        $barcode = Barcode::with(['batch.material', 'material', 'purchaseOrder.vendor'])
                         ->where('barcode_number', $request->barcode_number)
                         ->first();

        if (!$barcode) {
            return response()->json([
                'success' => false,
                'message' => 'Barcode not found'
            ], 404);
        }

        // Update last scanned timestamp
        $barcode->update([
            'last_scanned_at' => now(),
            'scan_count' => ($barcode->scan_count ?? 0) + 1
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $barcode->id,
                'barcode_number' => $barcode->barcode_number,
                'material' => $barcode->material_name,
                'material_code' => $barcode->material_code,
                'batch_number' => $barcode->batch ? $barcode->batch->batch_number : 'N/A',
                'supplier' => $barcode->supplier_name,
                'quantity' => $barcode->quantity,
                'weight' => $barcode->weight,
                'unit_price' => $barcode->unit_price,
                'expiry_date' => $barcode->expiry_date ? $barcode->expiry_date->format('d M, Y') : null,
                'storage_location' => $barcode->storage_location,
                'quality_grade' => $barcode->quality_grade,
                'status' => $barcode->status,
                'last_scanned_at' => $barcode->last_scanned_at ? $barcode->last_scanned_at->format('d M, Y H:i') : null,
                'scan_count' => $barcode->scan_count ?? 0
            ]
        ]);
    }

    public function dashboard()
    {
        $stats = [
            'total_barcodes' => Barcode::count(),
            'active_barcodes' => Barcode::where('status', 'active')->count(),
            'expired_items' => Barcode::where('expiry_date', '<', now())->count(),
            'expiring_soon' => Barcode::whereBetween('expiry_date', [now(), now()->addDays(7)])->count(),
            'total_scans' => Barcode::whereNotNull('last_scanned_at')->count(),
            'printed_today' => Barcode::whereDate('created_at', now())->count(),
            'damaged_items' => Barcode::where('status', 'damaged')->count(),
            'inactive_items' => Barcode::where('status', 'inactive')->count()
        ];

        $recentBarcodes = Barcode::with(['material', 'batch.material'])
                                ->orderBy('created_at', 'desc')
                                ->limit(10)
                                ->get();

        $expiringItems = Barcode::with(['material', 'batch.material'])
                               ->where('expiry_date', '>=', now())
                               ->where('expiry_date', '<=', now()->addDays(7))
                               ->orderBy('expiry_date')
                               ->limit(10)
                               ->get();

        $recentScans = Barcode::with(['material', 'batch.material'])
                             ->whereNotNull('last_scanned_at')
                             ->orderBy('last_scanned_at', 'desc')
                             ->limit(10)
                             ->get();

        return view('barcode.dashboard', compact('stats', 'recentBarcodes', 'expiringItems', 'recentScans'));
    }

    public function bulkAction(Request $request)
    {
        $request->validate([
            'action' => 'required|in:activate,deactivate,mark_damaged,delete',
            'barcode_ids' => 'required|array|min:1',
            'barcode_ids.*' => 'exists:barcodes,id'
        ]);

        $count = 0;

        try {
            DB::beginTransaction();

            switch ($request->action) {
                case 'activate':
                    $count = Barcode::whereIn('id', $request->barcode_ids)
                                   ->update([
                                       'status' => 'active',
                                       'updated_by' => Auth::id(),
                                       'updated_at' => now()
                                   ]);
                    break;
                case 'deactivate':
                    $count = Barcode::whereIn('id', $request->barcode_ids)
                                   ->update([
                                       'status' => 'inactive',
                                       'updated_by' => Auth::id(),
                                       'updated_at' => now()
                                   ]);
                    break;
                case 'mark_damaged':
                    $count = Barcode::whereIn('id', $request->barcode_ids)
                                   ->update([
                                       'status' => 'damaged',
                                       'updated_by' => Auth::id(),
                                       'updated_at' => now()
                                   ]);
                    break;
                case 'delete':
                    $count = Barcode::whereIn('id', $request->barcode_ids)->delete();
                    break;
            }

            DB::commit();
            return back()->with('success', "Bulk action completed successfully on {$count} barcodes.");
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Bulk action failed: ' . $e->getMessage());
            return back()->withErrors(['error' => 'Bulk action failed. Please try again.']);
        }
    }

    /**
     * Duplicate a barcode (useful for reprinting)
     */
    public function duplicate(Barcode $barcode)
    {
        try {
            $newBarcode = $barcode->replicate();
            $newBarcode->barcode_number = Barcode::generateBarcodeNumber();
            $newBarcode->qr_code_data = $newBarcode->generateQRData();
            $newBarcode->created_by = Auth::id();
            $newBarcode->created_at = now();
            $newBarcode->updated_at = now();
            $newBarcode->save();

            return redirect()->route('barcode.show', $newBarcode)
                           ->with('success', 'Barcode duplicated successfully!');
        } catch (\Exception $e) {
            \Log::error('Barcode duplication failed: ' . $e->getMessage());
            return back()->withErrors(['error' => 'Failed to duplicate barcode. Please try again.']);
        }
    }

    /**
     * Export barcodes to CSV
     */
    public function export(Request $request)
    {
        $query = Barcode::with(['batch.material', 'material', 'purchaseOrder.vendor']);
        
        // Apply same filters as index
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('material_id')) {
            $query->where('material_id', $request->material_id);
        }

        $barcodes = $query->get();

        $filename = 'barcodes_export_' . now()->format('Y_m_d_H_i_s') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $callback = function() use ($barcodes) {
            $file = fopen('php://output', 'w');
            
            // CSV headers
            fputcsv($file, [
                'Barcode Number', 'Material Name', 'Material Code', 'Supplier', 
                'Quantity', 'Weight', 'Unit Price', 'Expiry Date', 
                'Storage Location', 'Quality Grade', 'Status', 'Created At'
            ]);

            foreach ($barcodes as $barcode) {
                fputcsv($file, [
                    $barcode->barcode_number,
                    $barcode->material_name,
                    $barcode->material_code,
                    $barcode->supplier_name,
                    $barcode->quantity,
                    $barcode->weight,
                    $barcode->unit_price,
                    $barcode->expiry_date ? $barcode->expiry_date->format('Y-m-d') : '',
                    $barcode->storage_location,
                    $barcode->quality_grade,
                    $barcode->status,
                    $barcode->created_at->format('Y-m-d H:i:s')
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}