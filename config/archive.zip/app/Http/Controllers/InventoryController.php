<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;

use App\Models\InventoryBatch;
use App\Models\InventoryTransaction;
use App\Models\Material;
use App\Models\PurchaseOrder;
use App\Models\Barcode;
use App\Models\Vendor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;


class InventoryController extends Controller
{
    // Dashboard
    public function index()
    {
        $batches = InventoryBatch::with(['material', 'purchaseOrder.vendor'])
            ->when(request('status'), function($q) {
                $q->where('status', request('status'));
            })
            ->when(request('material'), function($q) {
                $q->whereHas('material', function($sub) {
                    $sub->where('name', 'like', '%' . request('material') . '%');
                });
            })
            ->when(request('batch_number'), function($q) {
                $q->where('batch_number', 'like', '%' . request('batch_number') . '%');
            })
            ->when(request('storage_location'), function($q) {
                $q->where('storage_location', 'like', '%' . request('storage_location') . '%');
            })
            ->latest('created_at')
            ->paginate(15);

        $materials = Material::where('is_active', true)->orderBy('name')->get();
        $statuses = ['active', 'expired', 'damaged', 'exhausted'];

        // Stats for dashboard cards
        $stats = [
            'total_batches' => InventoryBatch::count(),
            'active_batches' => InventoryBatch::where('status', 'active')->count(),
            'expired_batches' => InventoryBatch::where('status', 'expired')->count(),
            'low_stock_count' => InventoryBatch::where('status', 'active')
                ->where('current_quantity', '<', 10)->count(),
            'total_value' => InventoryBatch::where('status', 'active')
                ->sum(DB::raw('current_quantity * unit_price'))
        ];

        return view('inventory.index', compact('batches', 'materials', 'statuses', 'stats'));
    }
  public function create()
{
    $materials = Material::where('is_active', true)->orderBy('name')->get();
    $purchaseOrders = PurchaseOrder::with('vendor')
        ->whereIn('status', ['approved', 'pending'])
        ->orderBy('po_number', 'desc')
        ->get();
    
    // Generate suggested batch number
    $suggestedBatchNumber = $this->createUniqueBatchNumber();
    
    return view('inventory.create', compact('materials', 'purchaseOrders', 'suggestedBatchNumber'));
}


public function store(Request $request)
{
    $validated = $request->validate([
        'purchase_order_id' => 'nullable|exists:purchase_orders,id',
        'material_id' => 'required|exists:materials,id',
        'batch_number' => 'nullable|string|unique:inventory_batches,batch_number',
        'supplier_batch_number' => 'nullable|string|max:255',
        'initial_weight' => 'required|numeric|min:0.001',
        'initial_quantity' => 'required|integer|min:1',
        'unit_price' => 'required|numeric|min:0.01',
        'quality_grade' => 'nullable|string|in:A,B,C,Premium,Standard',
        'storage_location' => 'required|string|max:255',
        'received_date' => 'required|date',
        'expiry_date' => 'nullable|date|after:received_date',
        'notes' => 'nullable|string|max:1000'
    ]);

    if (empty($validated['batch_number'])) {
        $validated['batch_number'] = $this->createUniqueBatchNumber();
    }

    DB::beginTransaction();

    try {
        $batch = InventoryBatch::create([
            'purchase_order_id' => $validated['purchase_order_id'],
            'material_id' => $validated['material_id'],
            'batch_number' => $validated['batch_number'],
            'supplier_batch_number' => $validated['supplier_batch_number'] ?? null,
            'initial_weight' => $validated['initial_weight'],
            'received_weight' => $validated['initial_weight'],
            'current_weight' => $validated['initial_weight'],
            'initial_quantity' => $validated['initial_quantity'],
            'received_quantity' => $validated['initial_quantity'],
            'current_quantity' => $validated['initial_quantity'],
            'unit_price' => $validated['unit_price'],
            'quality_grade' => $validated['quality_grade'] ?? null,
            'storage_location' => $validated['storage_location'],
            'received_date' => $validated['received_date'],
            'expiry_date' => $validated['expiry_date'],
            'notes' => $validated['notes'],
            'status' => 'active'
        ]);

          // Generate a unique transaction ID using UUID (this prevents duplicates)
        $transactionId = 'TXN-' . Str::uuid()->toString();
\Log::info('Generated transaction ID: ' . 'TXN-' . Str::uuid()->toString());

        InventoryTransaction::create([
            'batch_id' => $batch->id,
            'type' => 'intake',
            'weight' => $request->input('initial_weight'),
            'quantity' => $request->input('initial_quantity'),
            'unit_price' => $request->input('unit_price'),
            'total_value' => $request->input('initial_quantity') * $request->input('unit_price'),
            'reference_number' => $batch->batch_number,
            'transaction_date' => $request->input('received_date'),
            'notes' => 'Initial stock intake',
            'transaction_id' => $transactionId,  // <- Unique transaction ID here
        ]);

        DB::commit();

        return redirect()->route('inventory.index')
            ->with('success', 'Inventory batch created successfully!');

    } catch (\Exception $e) {
        DB::rollBack();

        return back()->withInput()
            ->with('error', 'Error creating inventory batch: ' . $e->getMessage());
    }
}

public function show(InventoryBatch $inventory)
{
    $inventory->load(['material', 'purchaseOrder.vendor', 'transactions']);
    
    $transactions = $inventory->transactions()
        ->latest('transaction_date')
        ->get();

    $summary = [
        'total_intake' => $transactions->where('type', 'intake')->sum('quantity'),
        'total_dispatch' => $transactions->where('type', 'dispatch')->sum('quantity'),
        'total_damage' => $transactions->where('type', 'damage')->sum('quantity'),
        'total_adjustment' => $transactions->where('type', 'adjustment')->sum('quantity')
    ];

$batch = $inventory;
return view('inventory.show', compact('batch', 'transactions', 'summary'));
}
  
public function edit(InventoryBatch $inventory)
{
    if (in_array($inventory->status, ['exhausted'])) {
        return redirect()->route('inventory.index')
            ->with('error', 'Cannot edit exhausted batches.');
    }

    $materials = Material::where('is_active', true)->orderBy('name')->get();
    $purchaseOrders = PurchaseOrder::with('vendor')
        ->whereIn('status', ['approved', 'pending'])
        ->orderBy('po_number')
        ->get();

    $batch = $inventory;
    return view('inventory.edit', compact('batch', 'materials', 'purchaseOrders'));
}



  public function update(Request $request, InventoryBatch $inventory)
{
    $validated = $request->validate([
        'batch_number' => [
            'required',
            'string',
            Rule::unique('inventory_batches', 'batch_number')->ignore($inventory->id)
        ],
        'supplier_batch_number' => 'nullable|string|max:255',
        'quality_grade' => 'nullable|string|in:A,B,C,Premium,Standard',
        'storage_location' => 'nullable|string|max:255',
        'expiry_date' => 'nullable|date',
        'notes' => 'nullable|string|max:1000',
        'unit_price' => 'required|numeric|min:0'
    ]);

    try {
        $inventory->update($validated);

        return redirect()->route('inventory.index')
            ->with('success', 'Inventory batch updated successfully!');

    } catch (\Exception $e) {
        return back()->withInput()
            ->with('error', 'Error updating inventory batch: ' . $e->getMessage());
    }
}
public function destroy(InventoryBatch $inventory)
{
    try {
        DB::beginTransaction();

        // Delete related transactions first
        $inventory->transactions()->delete();

        // Then delete the batch
        $inventory->delete();

        DB::commit();

        return redirect()->route('inventory.index')
            ->with('success', 'Inventory batch deleted successfully!');

    } catch (\Exception $e) {
        DB::rollBack();
        return redirect()->route('inventory.index')
            ->with('error', 'Error deleting inventory batch: ' . $e->getMessage());
    }
}
// Show dispatch form
    public function showDispatch($id)
    {
        $item = Inventory::findOrFail($id);
        return view('inventory.dispatch', compact('item'));
    }

    // Dispatch material (POST)
    public function dispatch(Request $request)
    {
        $validated = $request->validate([
            'batch_id' => 'required|exists:inventory_batches,id',
            'weight' => 'required|numeric|min:0.001',
            'quantity' => 'required|integer|min:1',
            'reference_number' => 'nullable|string|max:255',
            'dispatch_to' => 'required|string|max:255',
            'purpose' => 'nullable|string|max:255',
            'notes' => 'nullable|string|max:500'
        ]);

        $batch = InventoryBatch::findOrFail($validated['batch_id']);

        if ($batch->current_quantity < $validated['quantity']) {
            return back()->with('error', 'Insufficient stock! Available: ' . $batch->current_quantity);
        }

        DB::beginTransaction();

        try {
            InventoryTransaction::create([
                'batch_id' => $batch->id,
                'type' => 'dispatch',
                'weight' => $validated['weight'],
                'quantity' => $validated['quantity'],
                'unit_price' => $batch->unit_price,
                'total_value' => $validated['quantity'] * $batch->unit_price,
                'reference_number' => $validated['reference_number'] ?? 'DISP-' . date('YmdHis'),
                'dispatch_to' => $validated['dispatch_to'],
                'purpose' => $validated['purpose'],
                'notes' => $validated['notes'],
                'transaction_date' => now()
            ]);

            $newQuantity = $batch->current_quantity - $validated['quantity'];
            $newWeight = $batch->current_weight - $validated['weight'];

            $batch->update([
                'current_weight' => max(0, $newWeight),
                'current_quantity' => $newQuantity,
                'status' => $newQuantity <= 0 ? 'exhausted' : 'active'
            ]);

            DB::commit();

            return back()->with('success', 'Material dispatched successfully!');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error dispatching material: ' . $e->getMessage());
        }
    }

    // Mark batch-based damage
    public function markDamaged(Request $request)
    {
        $validated = $request->validate([
            'batch_id' => 'required|exists:inventory_batches,id',
            'weight' => 'required|numeric|min:0.001',
            'quantity' => 'required|integer|min:1',
            'damage_type' => 'required|in:expired,contaminated,physical_damage,other',
            'reason' => 'required|string|max:500'
        ]);

        $batch = InventoryBatch::findOrFail($validated['batch_id']);

        if ($batch->current_quantity < $validated['quantity']) {
            return back()->with('error', 'Damage quantity exceeds available stock!');
        }

        DB::beginTransaction();

        try {
            InventoryTransaction::create([
                'batch_id' => $batch->id,
                'type' => 'damage',
                'weight' => $validated['weight'],
                'quantity' => $validated['quantity'],
                'unit_price' => $batch->unit_price,
                'total_value' => $validated['quantity'] * $batch->unit_price,
                'damage_type' => $validated['damage_type'],
                'reason' => $validated['reason'],
                'transaction_date' => now()
            ]);

            $newQuantity = $batch->current_quantity - $validated['quantity'];
            $newWeight = $batch->current_weight - $validated['weight'];

            $batch->update([
                'current_weight' => max(0, $newWeight),
                'current_quantity' => $newQuantity,
                'status' => $newQuantity <= 0 ? 'damaged' : $batch->status
            ]);

            DB::commit();

            return back()->with('success', 'Damaged stock recorded successfully!');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error recording damage: ' . $e->getMessage());
        }
    }

    // Store item-based damage (not batch)
    public function storeDamage(Request $request)
    {
        $validated = $request->validate([
            'item_id' => 'required|exists:items,id',
            'quantity' => 'required|integer|min:1',
            'reason' => 'required|string|max:255'
        ]);

        Damage::create([
            'item_id' => $validated['item_id'],
            'quantity' => $validated['quantity'],
            'reason' => $validated['reason'],
            'reported_by' => auth()->user()->id,
        ]);

        return redirect()->route('inventory.damage')->with('success', 'Damage recorded successfully.');
    }
}

    /**
     * Create a unique batch number
     */
    private function createUniqueBatchNumber($attempt = 1)
    {
        // Maximum attempts to avoid infinite loop
        if ($attempt > 10) {
            throw new \Exception('Unable to generate unique batch number after multiple attempts');
        }
        
        $prefix = 'BATCH';
        $date = now()->format('Ymd');
        $time = now()->format('His');
        
        // Format: BATCH-YYYYMMDD-HHMMSS
        $batchNumber = "{$prefix}-{$date}-{$time}";
        
        // Check if batch number already exists
        if ($this->batchNumberExists($batchNumber)) {
            // Wait 1 second and try again with new timestamp
            sleep(1);
            return $this->createUniqueBatchNumber($attempt + 1);
        }
        
        return $batchNumber;
    }

    /**
     * Check if batch number already exists
     */
    private function batchNumberExists($batchNumber)
    {
        return InventoryBatch::where('batch_number', $batchNumber)->exists();
    }
}