<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade\Pdf;

use App\Models\PurchaseOrder;
use App\Models\Vendor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Material;
use Illuminate\Validation\Rule;

class PurchaseOrderController extends Controller
{
   public function index(Request $request)
{
    $query = PurchaseOrder::with('vendor');
    
    // Apply filters based on request parameters
    if ($request->filled('po_number')) {
        $query->where('po_number', 'like', '%' . $request->po_number . '%');
    }
    
    if ($request->filled('vendor')) {
        $query->whereHas('vendor', function ($q) use ($request) {
            $q->where('name', 'like', '%' . $request->vendor . '%');
        });
    }
    
    if ($request->filled('status')) {
        $query->where('status', $request->status);
    }
    
    if ($request->filled('date_from')) {
        $query->whereDate('po_date', '>=', $request->date_from);
    }
    
    if ($request->filled('date_to')) {
        $query->whereDate('po_date', '<=', $request->date_to);
    }
    
    // Add your existing withSum clauses
    $orders = $query->withSum('purchaseOrderItems as purchase_order_items_quantity_sum', 'quantity')
        ->withSum('purchaseOrderItems as purchase_order_items_total_price_sum', 'total_price')
        ->withSum('purchaseOrderItems as purchase_order_items_gst_amount_sum', 'gst_amount')
        ->withSum('purchaseOrderItems as purchase_order_items_net_price_sum', 'net_price')
        ->orderBy('created_at', 'desc') // Add ordering for better UX
        ->paginate(10)
        ->appends($request->query()); // This preserves filter parameters in pagination links
    
    return view('purchase_orders.index', compact('orders'));
}


    public function create()
    {
        $vendors = Vendor::orderBy('name')->get();
        $materials = Material::where('is_active', true)->orderBy('name')->get();
        return view('purchase_orders.create', compact('vendors', 'materials'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'po_number' => 'nullable|unique:purchase_orders,po_number',
            'vendor_id' => 'required|exists:vendors,id',
            'po_date' => 'required|date',
            'expected_delivery' => 'nullable|date|after_or_equal:po_date',
            'payment_mode' => 'required|in:cash,bank_transfer,cheque,credit',
            'credit_days' => 'nullable|integer|in:0,15,30,45,60',
            'supplier_contact' => 'nullable|digits:10',
            'shipping_cost' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.item_name' => 'nullable|string|max:255',
            'items.*.description' => 'nullable|string',
            'items.*.quantity' => 'required|numeric|min:0.001',
            'items.*.weight' => 'nullable|numeric|min:0.001',
            'items.*.unit_price' => 'nullable|numeric|min:0',
            'items.*.gst_rate' => 'nullable|numeric|min:0|max:100',
            'items.*.batch_number' => 'nullable|string',
            'items.*.expiry_date' => 'nullable|date|after:today',
        ]);

        DB::beginTransaction();

        try {
           $purchaseOrder = PurchaseOrder::create([
    'po_number' => $request->po_number ?: $this->generatePoNumber(),
    'vendor_id' => $request->vendor_id,
    'po_date' => $request->po_date,
    'expected_delivery' => $request->expected_delivery,
    'payment_mode' => $request->payment_mode,
    'credit_days' => $request->credit_days,
    'shipping_cost' => $request->shipping_cost ?? 0,
    'notes' => $request->notes,
    'supplier_contact' => $request->supplier_contact,  // ✅ Added
    'order_date' => $request->order_date,              // ✅ Added
    'status' => 'pending',
    'total_amount' => 0,
    'gst_amount' => 0,
    'final_amount' => 0,
]);


            $totalAmount = 0;
            $totalGst = 0;

            foreach ($request->items as $item) {
                $material = Material::find($item['material_id']);
                $quantity = floatval($item['quantity']);
                $unitPrice = isset($item['unit_price']) && $item['unit_price'] !== ''
                    ? floatval($item['unit_price'])
                    : ($material->unit_price ?? 0);
                $weight = isset($item['weight']) ? floatval($item['weight']) : 1;
                $subtotal = $weight * $quantity * $unitPrice;
                $gstRate = isset($item['gst_rate']) ? floatval($item['gst_rate']) : $material->gst_rate;
                $gstAmount = ($subtotal * $gstRate) / 100;
                $total = $subtotal + $gstAmount;

                DB::table('purchase_order_items')->insert([
                    'purchase_order_id' => $purchaseOrder->id,
                    'material_id' => $item['material_id'],
                    'item_name' => $item['item_name'] ?? $material->name ?? '',
                    'description' => $item['description'] ?? '',
                    'quantity' => $quantity,
                    'weight' => $weight,
                    'unit_price' => $unitPrice,
                    'subtotal' => $subtotal,
                    'gst_rate' => $gstRate,
                    'gst_amount' => $gstAmount,
                    'total' => $total,
                    'total_price' => $total,
                    'net_price' => $total,
                    'batch_number' => $item['batch_number'] ?? null,
                    'expiry_date' => $item['expiry_date'] ?? null,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                $totalAmount += $subtotal;
                $totalGst += $gstAmount;
            }

            $purchaseOrder->update([
                'total_amount' => $totalAmount,
                'gst_amount' => $totalGst,
                'final_amount' => $totalAmount + $totalGst + ($request->shipping_cost ?? 0),
            ]);

            DB::commit();

            return redirect()->route('purchase-orders.index')
                ->with('success', 'Purchase Order created successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()
                ->with('error', 'Error creating purchase order: ' . $e->getMessage());
        }
    }

    public function show(PurchaseOrder $purchaseOrder)
    {
        $purchaseOrder->load(['vendor', 'purchaseOrderItems.material']);
        return view('purchase_orders.show', compact('purchaseOrder'));
    }

public function edit(PurchaseOrder $purchaseOrder)
{
    $purchaseOrder->load(['vendor', 'purchaseOrderItems.material']);
    $vendors = Vendor::orderBy('name')->get();
    $materials = Material::where('is_active', true)->orderBy('name')->get();

    if (in_array($purchaseOrder->status, ['received', 'cancelled'])) {
        return redirect()->route('purchase-orders.index')
            ->with('error', 'Cannot edit purchase orders that are received or cancelled.');
    }

    // Pass the correct variable name to the view
    return view('purchase_orders.edit', [
        'order' => $purchaseOrder,
        'vendors' => $vendors,
        'materials' => $materials
    ]);
}



    public function update(Request $request, PurchaseOrder $purchaseOrder)
    {
        $validated = $request->validate([
            'po_number' => [
                'required',
                'string',
                'max:255',
                Rule::unique('purchase_orders', 'po_number')->ignore($purchaseOrder->id)
            ],
            'vendor_id' => 'required|exists:vendors,id',
            'po_date' => 'required|date',
            'expected_delivery' => 'nullable|date|after_or_equal:po_date',
            'payment_mode' => 'required|in:cash,bank_transfer,cheque,credit',
            'credit_days' => 'nullable|integer|in:0,15,30,45,60',
            'shipping_cost' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.material_id' => 'required|exists:materials,id',
            'items.*.item_name' => 'nullable|string|max:255',
            'items.*.description' => 'nullable|string',
            'items.*.quantity' => 'required|numeric|min:0.001',
            'items.*.weight' => 'nullable|numeric|min:0.001',
            'items.*.unit_price' => 'nullable|numeric|min:0',
            'items.*.gst_rate' => 'nullable|numeric|min:0|max:100',
            'items.*.batch_number' => 'nullable|string',
            'items.*.expiry_date' => 'nullable|date|after:today',
        ]);

        DB::beginTransaction();

        try {
            $totalAmount = 0;
            $totalGst = 0;

            // Calculate totals first
            foreach ($validated['items'] as $item) {
                $material = Material::find($item['material_id']);
                $quantity = floatval($item['quantity']);
                $unitPrice = isset($item['unit_price']) && $item['unit_price'] !== ''
                    ? floatval($item['unit_price'])
                    : ($material->unit_price ?? 0);
                $weight = isset($item['weight']) ? floatval($item['weight']) : 1;
                $subtotal = $weight * $quantity * $unitPrice;
                $gstRate = isset($item['gst_rate']) ? floatval($item['gst_rate']) : $material->gst_rate;
                $gstAmount = ($subtotal * $gstRate) / 100;

                $totalAmount += $subtotal;
                $totalGst += $gstAmount;
            }

            // Update purchase order
            $purchaseOrder->update([
                'po_number' => $validated['po_number'],
                'vendor_id' => $validated['vendor_id'],
                'po_date' => $validated['po_date'],
                'expected_delivery' => $validated['expected_delivery'],
                'payment_mode' => $validated['payment_mode'],
                'credit_days' => $validated['credit_days'],
                'shipping_cost' => $validated['shipping_cost'] ?? 0,
                'notes' => $validated['notes'],
                'total_amount' => $totalAmount,
                'gst_amount' => $totalGst,
                'final_amount' => $totalAmount + $totalGst + ($validated['shipping_cost'] ?? 0),
            ]);

            // Delete existing items
            $purchaseOrder->purchaseOrderItems()->delete();

            // Create new items
            foreach ($validated['items'] as $item) {
                $material = Material::find($item['material_id']);
                $quantity = floatval($item['quantity']);
                $unitPrice = isset($item['unit_price']) && $item['unit_price'] !== ''
                    ? floatval($item['unit_price'])
                    : ($material->unit_price ?? 0);
                $weight = isset($item['weight']) ? floatval($item['weight']) : 1;
              
        // formula for  purchase orders 
                $subtotal = $weight * $quantity * $unitPrice;
                $gstRate = isset($item['gst_rate']) ? floatval($item['gst_rate']) : $material->gst_rate;
                $gstAmount = ($subtotal * $gstRate) / 100;
                $total = $subtotal + $gstAmount;

                $purchaseOrder->purchaseOrderItems()->create([
                    'material_id' => $item['material_id'],
                    'item_name' => $item['item_name'] ?? $material->name ?? '',
                    'description' => $item['description'] ?? '',
                    'quantity' => $quantity,
                    'weight' => $weight,
                    'unit_price' => $unitPrice,
                    'subtotal' => $subtotal,
                    'gst_rate' => $gstRate,
                    'gst_amount' => $gstAmount,
                    'total' => $total,
                    'total_price' => $total,
                    'net_price' => $total,
                    'batch_number' => $item['batch_number'] ?? null,
                    'expiry_date' => $item['expiry_date'] ?? null,
                ]);
            }

            DB::commit();

            return redirect()->route('purchase-orders.index')
                ->with('success', 'Purchase Order updated successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()
                ->with('error', 'Error updating purchase order: ' . $e->getMessage());
        }
    }

    // Helper function to generate PO number (optional)
    private function generatePoNumber()
    {
        $last = PurchaseOrder::latest('id')->first();
        $lastNumber = $last ? intval(preg_replace('/[^0-9]/', '', $last->po_number)) : 0;
        return 'PO' . str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);
    }

    public function destroy($id)
    {
        $purchaseOrder = PurchaseOrder::find($id);
        if (!$purchaseOrder) {
            $message = 'Purchase order not found.';
            return redirect()->route('purchase-orders.index')->with('error', $message);
        } else {
            $purchaseOrder->delete();
            $message = 'Purchase order deleted successfully.';
            return redirect()->route('purchase-orders.index')->with('success', $message);
        }
    }
    
public function generatePdf(PurchaseOrder $purchaseOrder)
{
    $purchaseOrder->load(['vendor', 'purchaseOrderItems.material']);

    $pdf = Pdf::loadView('purchase_orders.pdf', compact('purchaseOrder'));

    $filename = 'purchase-order-' . $purchaseOrder->po_number . '.pdf';

    return $pdf->download($filename);
}
  
}