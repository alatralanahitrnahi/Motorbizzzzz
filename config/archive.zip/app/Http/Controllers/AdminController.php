<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
  
   /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        $roles = [
            'admin' => 'Administrator',
            'purchase_team' => 'Purchase Team',
            'inventory_manager' => 'Inventory Manager',
            'user' => 'User'
        ];
        
        return view('dashboard.users.create', compact('roles'));
    }
  
public function index()
{
          $users = User::orderBy('created_at', 'desc')->paginate(15);

    $stats = [
        'total_users' => User::count(),
        'active_users' => User::where('is_active', true)->count(),
'inactive_users' => User::where('is_active', false)->count(),
        'admin_users' => User::where('role', 'admin')->count(),
        'recent_users' => User::latest()->limit(5)->get()
    ];

    return view('dashboard.users', compact('stats','users'));
}


  public function adminDashboard()
    {
        return $this->dashboard();
    }
    /**
     * Display a listing of users with search and filter functionality
     */
    public function users(Request $request)
    {
        // Base query
        $query = User::query();

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                  ->orWhere('email', 'LIKE', "%{$search}%");
            });
        }

        // Role filter
        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }

        // Status filter
        if ($request->filled('status')) {
            $isActive = $request->status === 'active';
            $query->where('is_active', $isActive);
        }

        // Get paginated users
        $users = $query->orderBy('created_at', 'desc')->paginate(10);
        
        // Append query parameters to pagination links
        $users->appends($request->query());

        // Calculate statistics
        $stats = [
            'total_users' => User::count(),
            'active_users' => User::where('is_active', true)->count(),
            'inactive_users' => User::where('is_active', false)->count(),
        ];

        return view('dashboard.users', compact('stats', 'users'));
    }

      /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'is_active' => 'boolean'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'is_active' => $request->has('is_active'),
        ]);

        return redirect()->route('dashboard.users.index')
            ->with('success', 'User created successfully.');
    }


    /**
     * Display the specified user
     */
    public function show(User $user)
    {
        return view('dashboard.users.show', compact('user'));
    }
    /**
     * Show the form for editing the specified user
     */
      public function edit(User $user)
    {
        $roles = [
            'admin' => 'Administrator',
            'purchase_team' => 'Purchase Team',
            'inventory_manager' => 'Inventory Manager',
            'user' => 'User'
        ];
        
        return view('dashboard.users.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified user
     */
public function update(Request $request, User $user)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,purchase_team,inventory_manager,user',
            'is_active' => 'boolean'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $updateData = [
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'is_active' => $request->has('is_active'),
        ];

        // Only update password if provided
        if ($request->filled('password')) {
            $updateData['password'] = Hash::make($request->password);
        }

        $user->update($updateData);

        return redirect()->route('dashboard.users.index')
            ->with('success', 'User updated successfully.');
    }

    /**
     * Toggle user status
     */
    public function toggleStatus(Request $request, $userId)
    {
        try {
            $user = User::findOrFail($userId);
            
            // Prevent users from deactivating themselves
            if ($user->id === auth()->id()) {
                return response()->json([
                    'success' => false,
                    'error' => 'You cannot change your own status.'
                ], 403);
            }

            $request->validate([
                'status' => 'required|in:active,inactive'
            ]);

            $newStatus = $request->status === 'active';
            
            $user->update([
                'is_active' => $newStatus
            ]);

            return response()->json([
                'success' => true,
                'status' => $request->status,
                'message' => "User status updated to {$request->status} successfully."
            ]);
            
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to update user status.'
            ], 500);
        }
    }

    public function destroy(User $user)
    {
        // Prevent admin from deleting themselves
        if ($user->id === auth()->id()) {
            return redirect()->back()
                ->with('error', 'You cannot delete your own account.');
        }

        $user->delete();

        return redirect()->route('dashboard.users.index')
            ->with('success', 'User deleted successfully.');
    }
}