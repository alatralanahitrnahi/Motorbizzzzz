<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use App\Models\User;

class AuthController extends Controller
{
    /**
     * Show the login form
     */
    public function showLoginForm()
    {
        // Redirect if already authenticated
        if (Auth::check()) {
            return $this->redirectToDashboard();
        }
        
        return view('auth.login');
    }

    /**
     * Handle login request
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);

        $credentials = $request->only('email', 'password');
        
        // Find user by email
        $user = User::where('email', $credentials['email'])->first();
        
        if (!$user) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Invalid credentials.'
                ], 401);
            }
            
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        // Check if user is active
        if (!$user->is_active) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Your account has been deactivated. Please contact administrator.'
                ], 401);
            }
            
            throw ValidationException::withMessages([
                'email' => ['Your account has been deactivated. Please contact administrator.'],
            ]);
        }

        // Verify password
        if (!Hash::check($credentials['password'], $user->password)) {
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Invalid credentials.'
                ], 401);
            }
            
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        // Login the user
        Auth::login($user, $request->boolean('remember'));

        $request->session()->regenerate();

        // Handle JSON response for AJAX requests
        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Login successful.',
                'redirect' => $this->getRedirectUrl($user)
            ]);
        }

        // Redirect based on user role
        return $this->redirectToDashboard($user);
    }

    /**
     * Handle logout request
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Logged out successfully.',
                'redirect' => route('login')
            ]);
        }

        return redirect()->route('login')->with('success', 'You have been logged out successfully.');
    }

    /**
     * Get redirect URL based on user role
     */
    private function getRedirectUrl($user = null)
    {
        $user = $user ?? Auth::user();
        
        if (!$user) {
            return route('login');
        }

        // Redirect based on user role
        switch ($user->role) {
            case 'admin':
                return route('dashboard.users'); // Admin goes to user management
            case 'purchase_team':
                return route('dashboard') . '?tab=purchases'; // Purchase team
            case 'inventory_manager':
                return route('dashboard') . '?tab=inventory'; // Inventory manager
            case 'user':
            default:
                return route('dashboard'); // Regular users go to main dashboard
        }
    }

    /**
     * Redirect to appropriate dashboard
     */
    private function redirectToDashboard($user = null)
    {
        $redirectUrl = $this->getRedirectUrl($user);
        return redirect($redirectUrl);
    }
}