<?php

// app/Services/NotificationService.php

namespace App\Services;

use App\Models\PurchaseOrder;
use App\Models\User;
use App\Notifications\PurchaseOrderApproved;
use App\Notifications\LowStockAlert;
use Illuminate\Support\Facades\Notification;

class NotificationService
{
    /**
     * Notify inventory team when a purchase order is approved.
     *
     * @param PurchaseOrder $purchaseOrder
     */
    public static function notifyInventoryTeam(PurchaseOrder $purchaseOrder)
    {
        // Get inventory team users (adjust role or permission as needed)
        $inventoryUsers = User::where('role', 'inventory')->get();

        // Send notification
        Notification::send($inventoryUsers, new PurchaseOrderApproved($purchaseOrder));
    }

    /**
     * Send an alert if stock of a material is low.
     *
     * @param string $material
     * @param int $currentStock
     */
    public static function sendLowStockAlert(string $material, int $currentStock)
    {
        // Get users who should receive low stock alerts
        $managers = User::where('role', 'manager')->get();

        // Send low stock alert
        Notification::send($managers, new LowStockAlert($material, $currentStock));
    }
}
