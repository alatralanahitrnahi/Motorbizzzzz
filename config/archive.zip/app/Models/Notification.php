<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Notification extends Model
{
    protected $fillable = [
        'type',
        'notifiable_type',
        'notifiable_id',
        'data',
        'read_at',
    ];

    protected $casts = [
        'data' => 'array',         // Automatically cast JSON to array
        'read_at' => 'datetime',  // Cast timestamp to Carbon instance
    ];

    /**
     * Get the parent notifiable model (e.g., User, Vendor).
     */
    public function notifiable(): MorphTo
    {
        return $this->morphTo();
    }
}
