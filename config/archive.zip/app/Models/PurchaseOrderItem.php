<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrderItem extends Model
{
    protected $fillable = [
        'purchase_order_id',
        'material_id', 
        'item_name',
        'description',
        'quantity',
        'weight',
        'unit_price',
        'subtotal',
        'gst_rate',
        'gst_amount',
        'total',
        'total_price',
        'batch_number',
        'expiry_date',
    ];

    protected $casts = [
        'quantity' => 'decimal:3',
        'weight' => 'decimal:3',
        'unit_price' => 'decimal:2',
        'subtotal' => 'decimal:2',
        'gst_rate' => 'decimal:2',
        'gst_amount' => 'decimal:2',
        'total' => 'decimal:2',
        'order_date' => 'date',
        'expected_delivery' => 'date',
        'expiry_date' => 'date',
    ];

    public function purchaseOrder()
    {
        return $this->belongsTo(PurchaseOrder::class);
    }

    public function material()
    {
        return $this->belongsTo(Material::class);
    }

    // Auto-calculate totals when model is saving
    protected static function boot()
    {
        parent::boot();

        static::saving(function ($model) {
            if ($model->isDirty(['quantity', 'weight', 'unit_price', 'gst_rate'])) {
                $weight = $model->weight ?: 1;
                $model->subtotal = $model->quantity * $weight * $model->unit_price;
                $model->gst_amount = ($model->subtotal * $model->gst_rate) / 100;
                $model->total = $model->subtotal + $model->gst_amount;
            }
        });
    }

    public function getFormattedTotalAttribute()
    {
        return number_format($this->total, 2);
    }

    public function items()
    {
        return $this->hasMany(PurchaseOrderItem::class);
    }
}
