<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// InventoryTransaction.php
class InventoryTransaction extends Model
{
    protected $fillable = [
        'transaction_id', 'batch_id', 'type', 'weight', 'quantity',
        'reference_number', 'reason', 'metadata', 'transaction_date'
    ];

    protected $casts = [
        'weight' => 'decimal:3',
        'metadata' => 'array',
        'transaction_date' => 'datetime'
    ];

    public function batch()
    {
        return $this->belongsTo(InventoryBatch::class, 'batch_id');
    }

    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($model) {
            $model->transaction_id = 'TXN' . date('Ymd') . str_pad(static::whereDate('created_at', today())->count() + 1, 6, '0', STR_PAD_LEFT);
        });
    }
}