<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryBatch extends Model
{
  protected $table = 'inventory_batches';

    protected $fillable = [
        'purchase_order_id',
        'material_id', 
        'batch_number',
        'received_weight',
        'received_quantity',
        'current_weight', 
        'current_quantity',
        'unit_price',              // Make sure this is here!
        'storage_location',
        'received_date',
        'expiry_date',
        'supplier_batch_number',
        'quality_grade',
        'notes',
        'status'
    ];

    protected $casts = [
        'received_date' => 'date',
        'expiry_date' => 'date',
        'received_weight' => 'decimal:3',
        'current_weight' => 'decimal:3',
        'unit_price' => 'decimal:2',      // Cast unit_price as decimal
        'received_quantity' => 'integer',
        'current_quantity' => 'integer',
    ];

    // Relationships
    public function material()
    {
        return $this->belongsTo(Material::class);
    }

    public function purchaseOrder()
    {
        return $this->belongsTo(PurchaseOrder::class);
    }

    public function transactions()
    {
        return $this->hasMany(InventoryTransaction::class, 'batch_id');
    }
  public function getInitialQuantityAttribute()
{
    return $this->received_quantity;
}

public function getInitialWeightAttribute()
{
    return $this->received_weight;
}
// In InventoryBatch.php
public function supplier()
{
    return $this->belongsTo(Supplier::class); // Make sure Supplier model exists
}

}