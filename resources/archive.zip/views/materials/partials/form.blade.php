<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Create Materials</h2>
        <a href="{{ route('materials.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Details
        </a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('materials.store') }}" method="POST">
        @csrf

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label">Material Name *</label>
                <input type="text" name="name" class="form-control" value="{{ old('name', $material->name ?? '') }}" required>
            </div>

           <div class="col-md-6 mb-3">
    <label for="code" class="form-label">Code *</label>
    <input type="text" name="code" id="code" class="form-control" value="{{ old('code', $material->code ?? '') }}" readonly required>
    <div class="invalid-feedback" id="codeError"></div>
</div>


            <div class="col-md-12 mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3">{{ old('description', $material->description ?? '') }}</textarea>
            </div>

        <div class="col-md-6 mb-3">
    <label for="unit" class="form-label">Unit *</label>
    <select name="unit" class="form-select" required>
        <option value="">Select Unit</option>
        <option value="kg" {{ old('unit', $material->unit ?? '') == 'kg' ? 'selected' : '' }}>Kilogram</option>
        <option value="ton" {{ old('unit', $material->unit ?? '') == 'ton' ? 'selected' : '' }}>Ton</option>
        <option value="gram" {{ old('unit', $material->unit ?? '') == 'gram' ? 'selected' : '' }}>Gram</option>
        <option value="liter" {{ old('unit', $material->unit ?? '') == 'liter' ? 'selected' : '' }}>Liter</option>
        <option value="milliliter" {{ old('unit', $material->unit ?? '') == 'milliliter' ? 'selected' : '' }}>Milliliter</option>
        <option value="meter" {{ old('unit', $material->unit ?? '') == 'meter' ? 'selected' : '' }}>Meter</option>
        <option value="centimeter" {{ old('unit', $material->unit ?? '') == 'centimeter' ? 'selected' : '' }}>Centimeter</option>
        <option value="millimeter" {{ old('unit', $material->unit ?? '') == 'millimeter' ? 'selected' : '' }}>Millimeter</option>
        <option value="piece" {{ old('unit', $material->unit ?? '') == 'piece' ? 'selected' : '' }}>Piece</option>
        <option value="bag" {{ old('unit', $material->unit ?? '') == 'bag' ? 'selected' : '' }}>Bag</option>
        <option value="bucket" {{ old('unit', $material->unit ?? '') == 'bucket' ? 'selected' : '' }}>Bucket</option>
        <option value="box" {{ old('unit', $material->unit ?? '') == 'box' ? 'selected' : '' }}>Box</option>
        <option value="roll" {{ old('unit', $material->unit ?? '') == 'roll' ? 'selected' : '' }}>Roll</option>
        <option value="pack" {{ old('unit', $material->unit ?? '') == 'pack' ? 'selected' : '' }}>Pack</option>
        <option value="set" {{ old('unit', $material->unit ?? '') == 'set' ? 'selected' : '' }}>Set</option>
        <option value="carton" {{ old('unit', $material->unit ?? '') == 'carton' ? 'selected' : '' }}>Carton</option>
        <option value="drum" {{ old('unit', $material->unit ?? '') == 'drum' ? 'selected' : '' }}>Drum</option>
        <option value="pallet" {{ old('unit', $material->unit ?? '') == 'pallet' ? 'selected' : '' }}>Pallet</option>
    </select>
    <div class="invalid-feedback" id="unitError"></div>
</div>


            <div class="col-md-6 mb-3">
                <label for="unit_price" class="form-label">Unit Price (₹) *</label>
                <input type="number" step="0.01" name="unit_price" class="form-control" value="{{ old('unit_price', $material->unit_price ?? '') }}" required>
            </div>

            <div class="col-md-6 mb-3">
                <label for="gst_rate" class="form-label">GST Rate (%) *</label>
                <input type="number" step="0.01" name="gst_rate" class="form-control" value="{{ old('gst_rate', $material->gst_rate ?? 18.00) }}" required>
            </div>

            <div class="col-md-6 mb-3">
                <label for="category" class="form-label">Category</label>
                <input type="text" name="category" class="form-control" value="{{ old('category', $material->category ?? '') }}">
            </div>

            <div class="col-md-6 mb-3">
                <label for="is_active" class="form-label">Is Active</label>
                <select name="is_active" class="form-select">
                    <option value="1" {{ old('is_active', $material->is_active ?? 1) == 1 ? 'selected' : '' }}>Yes</option>
                    <option value="0" {{ old('is_active', $material->is_active ?? 1) == 0 ? 'selected' : '' }}>No</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Save Material
        </button><br><br>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    function generateCode(name) {
        if (!name) return '';
        const prefix = name.trim().substring(0, 3).toUpperCase();
        const randomNum = Math.floor(1000 + Math.random() * 9000);
        return prefix + randomNum;
    }

    const nameInput = document.querySelector('input[name="name"]');
    const codeInput = document.getElementById('code');

    if (nameInput && codeInput) {
        if (!codeInput.value) {
            codeInput.value = generateCode(nameInput.value);
        }

        nameInput.addEventListener('input', function () {
            codeInput.value = generateCode(nameInput.value);
        });
    }

    const form = document.getElementById('materialForm');

    const validations = {
        name: {
            required: true,
            maxLength: 100,
        },
        code: {
            required: true,
            maxLength: 50,
            pattern: /^[A-Za-z0-9]+$/,
        },
        // Add other validations as needed
    };

    function validateField(fieldName, value) {
        const rules = validations[fieldName];
        let error = '';

        if (rules.required && !value.trim()) {
            error = 'This field is required.';
        } else if (rules.maxLength && value.length > rules.maxLength) {
            error = `Maximum length is ${rules.maxLength} characters.`;
        } else if (rules.pattern && !rules.pattern.test(value)) {
            error = 'Invalid characters entered.';
        }

        return error;
    }

    function handleInput(event) {
        const input = event.target;
        const fieldName = input.name;
        const value = input.value;
        const error = validateField(fieldName, value);
        const errorDiv = document.getElementById(fieldName + 'Error');

        if (error) {
            input.classList.add('is-invalid');
            if (errorDiv) errorDiv.textContent = error;
        } else {
            input.classList.remove('is-invalid');
            if (errorDiv) errorDiv.textContent = '';
        }
    }

    Object.keys(validations).forEach(fieldName => {
        const input = form.querySelector(`[name="${fieldName}"]`);
        if (input) {
            input.addEventListener('input', handleInput);
        }
    });

    form.addEventListener('submit', function (e) {
        let hasError = false;
        Object.keys(validations).forEach(fieldName => {
            const input = form.querySelector(`[name="${fieldName}"]`);
            if (input) {
                const error = validateField(fieldName, input.value);
                const errorDiv = document.getElementById(fieldName + 'Error');
                if (error) {
                    hasError = true;
                    input.classList.add('is-invalid');
                    if (errorDiv) errorDiv.textContent = error;
                } else {
                    input.classList.remove('is-invalid');
                    if (errorDiv) errorDiv.textContent = '';
                }
            }
        });

        if (hasError) {
            e.preventDefault();
            e.stopPropagation();
        }
    });
});
</script>