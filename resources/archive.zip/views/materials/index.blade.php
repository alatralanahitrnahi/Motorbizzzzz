@extends('layouts.app')
@section('title', 'Materials List')
@section('content')
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Materials</h3>
            <a href="{{ route('materials.create') }}" class="btn btn-primary">Add New Material</a>
        </div>
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Unit</th>
                        <th>Unit Price</th>
                        <th>GST Rate (%)</th>
                        <th>Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($materials as $material)
                        <tr>
                            <td>{{ $material->name }}</td>
                            <td>{{ $material->code }}</td>
                            <td>{{ $material->unit }}</td>
                            <td>${{ number_format($material->unit_price, 2) }}</td>
                            <td>{{ $material->gst_rate }}%</td>
                            <td>
                                <span class="badge bg-{{ $material->is_active ? 'success' : 'secondary' }}">
                                    {{ $material->is_active ? 'Yes' : 'No' }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('materials.show', $material) }}" class="btn btn-sm btn-info">View</a>
                                <a href="{{ route('materials.edit', $material) }}" class="btn btn-sm btn-warning">Edit</a>
                                <form action="{{ route('materials.destroy', $material) }}" method="POST" class="d-inline"
                                      onsubmit="return confirm('Are you sure?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center">No materials found.</td></tr>
                    @endforelse
                </tbody>
            </table>

            {{ $materials->links() }}
        </div>
    </div>
</div>
@endsection
