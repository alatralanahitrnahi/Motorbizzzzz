@extends('layouts.app')
@section('title', 'Create New User')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Create New User</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="{{ route('dashboard.users.index') }}" class="btn btn-outline-secondary me-2">
            <i class="fas fa-arrow-left"></i> Back to Users
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5>User Information</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('dashboard.users.store') }}" id="createUserForm">
                    @csrf
                    
                    <div class="row mb-3">
                        <label for="name" class="col-md-3 col-form-label">Full Name <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" value="{{ old('name') }}" required 
                                   placeholder="Enter full name">
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="email" class="col-md-3 col-form-label">Email Address <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                   id="email" name="email" value="{{ old('email') }}" required 
                                   placeholder="Enter email address">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="role" class="col-md-3 col-form-label">Role <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            <select class="form-select @error('role') is-invalid @enderror" id="role" name="role" required>
                                <option value="">Select Role</option>
                                <option value="admin" {{ old('role') == 'admin' ? 'selected' : '' }}>
                                    Administrator
                                </option>
                                <option value="purchase_team" {{ old('role') == 'purchase_team' ? 'selected' : '' }}>
                                    Purchase Team
                                </option>
                                <option value="inventory_manager" {{ old('role') == 'inventory_manager' ? 'selected' : '' }}>
                                    Inventory Manager
                                </option>
                                <option value="user" {{ old('role') == 'user' ? 'selected' : '' }}>
                                    User
                                </option>
                            </select>
                            @error('role')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle"></i> 
                                    Role determines user permissions and access levels.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="is_active" class="col-md-3 col-form-label">Status</label>
                        <div class="col-md-9">
                            <div class="form-check form-switch">
                              <select class="form-select @error('status') is-invalid @enderror" id="status" name="status" required>
    <option value="active" {{ old('status', 'active') == 'active' ? 'selected' : '' }}>Active</option>
    <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
</select>
                            </div>
                            <div class="form-text">
                                <small class="text-muted">
                                    Inactive users cannot log in to the system.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h6 class="mb-3">Password Setup <span class="text-danger">*</span></h6>
                    
                    <div class="row mb-3">
                        <label for="password" class="col-md-3 col-form-label">Password <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                   id="password" name="password" required 
                                   placeholder="Enter password (minimum 8 characters)">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                <small class="text-muted">
                                    Password must be at least 8 characters long and contain a mix of letters, numbers, and symbols.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <label for="password_confirmation" class="col-md-3 col-form-label">Confirm Password <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            <input type="password" class="form-control" id="password_confirmation" 
                                   name="password_confirmation" required 
                                   placeholder="Re-enter password">
                            <div class="form-text">
                                <small class="text-muted">
                                    Re-enter the password to confirm.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-9 offset-md-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="send_welcome_email" 
                                       name="send_welcome_email" value="1" {{ old('send_welcome_email', 1) ? 'checked' : '' }}>
                                <label class="form-check-label" for="send_welcome_email">
                                    Send welcome email with login credentials
                                </label>
                            </div>
                            <div class="form-text">
                                <small class="text-muted">
                                    The user will receive an email with their login details and instructions.
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-9 offset-md-3">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-plus"></i> Create User
                            </button>
                            <a href="{{ route('dashboard.users.index') }}" class="btn btn-secondary me-2">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="reset" class="btn btn-outline-secondary">
                                <i class="fas fa-undo"></i> Reset Form
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>Preview</h5>
            </div>
            <div class="card-body text-center">
                <div class="avatar-lg mb-3">
                    <div class="bg-secondary text-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                         style="width: 100px; height: 100px; font-size: 2rem;" id="userAvatar">
                        <i class="fas fa-user"></i>
                    </div>
                </div>
                <h5 id="previewName">New User</h5>
                <p class="text-muted" id="previewEmail">user@example.com</p>
                <span class="badge bg-secondary mb-2" id="previewRole">Select Role</span>
                <br>
                <span class="badge bg-success" id="previewStatus">Active</span>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5>Role Permissions</h5>
            </div>
            <div class="card-body">
                <div id="rolePermissions">
                    <p class="text-muted mb-0">Select a role to see permissions</p>
                </div>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5>Quick Tips</h5>
            </div>
            <div class="card-body">
                <div class="d-flex align-items-start mb-2">
                    <i class="fas fa-lightbulb text-warning me-2 mt-1"></i>
                    <small class="text-muted">
                        <strong>Email:</strong> Must be unique and will be used for login.
                    </small>
                </div>
                <div class="d-flex align-items-start mb-2">
                    <i class="fas fa-lightbulb text-warning me-2 mt-1"></i>
                    <small class="text-muted">
                        <strong>Password:</strong> User can change this after first login.
                    </small>
                </div>
                <div class="d-flex align-items-start mb-2">
                    <i class="fas fa-lightbulb text-warning me-2 mt-1"></i>
                    <small class="text-muted">
                        <strong>Role:</strong> Can be changed later if needed.
                    </small>
                </div>
                <div class="d-flex align-items-start">
                    <i class="fas fa-lightbulb text-warning me-2 mt-1"></i>
                    <small class="text-muted">
                        <strong>Status:</strong> Inactive users cannot access the system.
                    </small>
                </div>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <h5>Security Requirements</h5>
            </div>
            <div class="card-body">
                <ul class="list-unstyled mb-0">
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <small>Minimum 8 characters</small>
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-muted me-2" id="uppercaseCheck"></i>
                        <small>At least one uppercase letter</small>
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-muted me-2" id="lowercaseCheck"></i>
                        <small>At least one lowercase letter</small>
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-check-circle text-muted me-2" id="numberCheck"></i>
                        <small>At least one number</small>
                    </li>
                    <li>
                        <i class="fas fa-check-circle text-muted me-2" id="specialCheck"></i>
                        <small>At least one special character</small>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
// Role permissions mapping
const rolePermissions = {
    'admin': [
        'Full system access',
        'User management',
        'System configuration',
        'All reports and analytics'
    ],
    'purchase_team': [
        'Purchase order management',
        'Supplier management',
        'Inventory requests',
        'Purchase reports'
    ],
    'inventory_manager': [
        'Inventory management',
        'Stock level monitoring',
        'Asset tracking',
        'Inventory reports'
    ],
    'user': [
        'Basic system access',
        'View assigned data',
        'Create basic requests',
        'Personal profile management'
    ]
};

// Role badge colors
const roleBadgeColors = {
    'admin': 'danger',
    'purchase_team': 'primary',
    'inventory_manager': 'info',
    'user': 'secondary'
};

// Role display names
const roleDisplayNames = {
    'admin': 'Administrator',
    'purchase_team': 'Purchase Team',
    'inventory_manager': 'Inventory Manager',
    'user': 'User'
};

// Update role permissions display
function updateRolePermissions(role) {
    const permissionsDiv = document.getElementById('rolePermissions');
    if (role && rolePermissions[role]) {
        const permissions = rolePermissions[role];
        let html = '<ul class="list-unstyled mb-0">';
        permissions.forEach(permission => {
            html += `<li class="mb-1"><i class="fas fa-check text-success me-2"></i><small>${permission}</small></li>`;
        });
        html += '</ul>';
        permissionsDiv.innerHTML = html;
    } else {
        permissionsDiv.innerHTML = '<p class="text-muted mb-0"><small>Select a role to see permissions</small></p>';
    }
}

// Update preview card
function updatePreview() {
    const name = document.getElementById('name').value || 'New User';
    const email = document.getElementById('email').value || 'user@example.com';
    const role = document.getElementById('role').value;
    const isActive = document.getElementById('is_active').checked;
    
    // Update preview elements
    document.getElementById('previewName').textContent = name;
    document.getElementById('previewEmail').textContent = email;
    
    // Update avatar
    const avatar = document.getElementById('userAvatar');
    if (name && name !== 'New User') {
        const initials = name.split(' ').map(word => word.charAt(0).toUpperCase()).join('').substring(0, 2);
        avatar.innerHTML = initials;
        avatar.className = avatar.className.replace('bg-secondary', 'bg-primary');
    } else {
        avatar.innerHTML = '<i class="fas fa-user"></i>';
        avatar.className = avatar.className.replace('bg-primary', 'bg-secondary');
    }
    
    // Update role badge
    const roleElement = document.getElementById('previewRole');
    if (role) {
        roleElement.textContent = roleDisplayNames[role];
        roleElement.className = `badge bg-${roleBadgeColors[role]} mb-2`;
    } else {
        roleElement.textContent = 'Select Role';
        roleElement.className = 'badge bg-secondary mb-2';
    }
    
    // Update status badge
    const statusElement = document.getElementById('previewStatus');
    statusElement.textContent = isActive ? 'Active' : 'Inactive';
    statusElement.className = `badge bg-${isActive ? 'success' : 'secondary'}`;
}
  document.getElementById('is_active').addEventListener('change', function() {
    // Change this to work with select instead of checkbox
    updatePreview();
});

// Password strength validation
function validatePassword(password) {
    const checks = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };
    
    // Update visual indicators
    document.getElementById('uppercaseCheck').className = `fas fa-check-circle me-2 ${checks.uppercase ? 'text-success' : 'text-muted'}`;
    document.getElementById('lowercaseCheck').className = `fas fa-check-circle me-2 ${checks.lowercase ? 'text-success' : 'text-muted'}`;
    document.getElementById('numberCheck').className = `fas fa-check-circle me-2 ${checks.number ? 'text-success' : 'text-muted'}`;
    document.getElementById('specialCheck').className = `fas fa-check-circle me-2 ${checks.special ? 'text-success' : 'text-muted'}`;
    
    return checks;
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const roleSelect = document.getElementById('role');
    const statusCheck = document.getElementById('is_active');
    const passwordInput = document.getElementById('password');
    
    // Update preview on input changes
    nameInput.addEventListener('input', updatePreview);
    emailInput.addEventListener('input', updatePreview);
    roleSelect.addEventListener('change', function() {
        updatePreview();
        updateRolePermissions(this.value);
    });
    statusCheck.addEventListener('change', updatePreview);
    
    // Password validation
    passwordInput.addEventListener('input', function() {
        validatePassword(this.value);
    });
    
    // Initial preview update
    updatePreview();
});

// Form validation
document.getElementById('createUserForm').addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;
    const passwordConfirmation = document.getElementById('password_confirmation').value;
    
    if (password !== passwordConfirmation) {
        e.preventDefault();
        showToast('Error', 'Password confirmation does not match', 'error');
        return false;
    }
    
    const checks = validatePassword(password);
    if (!checks.length || !checks.uppercase || !checks.lowercase || !checks.number || !checks.special) {
        e.preventDefault();
        showToast('Error', 'Password does not meet security requirements', 'error');
        return false;
    }
    
    // Show loading state
    const submitBtn = this.querySelector('button[type="submit"]');
    const origText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating User...';
    submitBtn.disabled = true;
    
    // Reset if form submission fails (will be handled by server-side validation)
    setTimeout(() => {
        submitBtn.innerHTML = origText;
        submitBtn.disabled = false;
    }, 5000);
});

// Toast notification function
function showToast(title, message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'success' ? 'success' : (type === 'error' ? 'danger' : 'info')} alert-dismissible fade show position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.innerHTML = `
        <strong>${title}</strong> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 5000);
}

// Reset form function
document.querySelector('button[type="reset"]').addEventListener('click', function() {
    setTimeout(() => {
        updatePreview();
        updateRolePermissions('');
        validatePassword('');
    }, 100);
});
</script>
@endsection