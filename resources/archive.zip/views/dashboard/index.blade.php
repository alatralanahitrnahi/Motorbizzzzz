@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<!-- Welcome Section -->
<div class="welcome-section">
    <div class="welcome-content text-center">
        <h1 class="welcome-title">
            <i class="fas fa-hand-wave me-3"></i>
            Welcome back, {{ Auth::user()->name }}!
        </h1>
        <p class="welcome-subtitle">
            Ready to manage your inventory efficiently? Your {{ Auth::user()->getRoleDisplayName() }} dashboard is at your service.
        </p>
    </div>
</div>

@if(isset($user))
    <!-- Dashboard Stats -->
    <div class="row g-4 mb-4">
        @if($user->isAdmin())
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card users">
                    <div class="stats-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_users'] ?? $totalUsers ?? 0 }}</div>
                    <div class="stats-label">Total Users</div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card vendors">
                    <div class="stats-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_vendors'] ?? $totalVendors ?? 0 }}</div>
                    <div class="stats-label">Total Vendors</div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card inventory">
                    <div class="stats-icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_items'] ?? $totalItems ?? 0 }}</div>
                    <div class="stats-label">Inventory Items</div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card orders">
                    <div class="stats-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_orders'] ?? $totalOrders ?? 0 }}</div>
                    <div class="stats-label">Purchase Orders</div>
                </div>
            </div>
        @elseif($user->isPurchaseTeam())
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card vendors">
                    <div class="stats-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_vendors'] ?? $totalVendors ?? 0 }}</div>
                    <div class="stats-label">Total Vendors</div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card orders">
                    <div class="stats-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_orders'] ?? $totalOrders ?? 0 }}</div>
                    <div class="stats-label">Purchase Orders</div>
                </div>
            </div>
        @elseif($user->isInventoryManager())
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card vendors">
                    <div class="stats-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_vendors'] ?? $totalVendors ?? 0 }}</div>
                    <div class="stats-label">Total Vendors</div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="stats-card inventory">
                    <div class="stats-icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stats-number">{{ $stats['total_items'] ?? $totalItems ?? 0 }}</div>
                    <div class="stats-label">Inventory Items</div>
                </div>
            </div>
        @else
            <div class="col-12">
                <div class="alert alert-warning">
                    <p>No specific dashboard content available for your role.</p>
                </div>
            </div>
        @endif
    </div>

    <!-- Quick Actions -->
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        @if(Auth::user()->isAdmin())
                        <div class="col-md-6">
                            <a href="{{ route('admin.users') }}" class="btn btn-primary w-100">
                                <i class="fas fa-user-plus me-2"></i>Manage Users
                            </a>
                        </div>
                        @endif
                        
                        @if(Auth::user()->isAdmin() || Auth::user()->isPurchaseTeam())
                        <div class="col-md-6">
                            <a href="{{ route('purchase-orders.index') }}" class="btn btn-outline-primary w-100">
                                <i class="fas fa-plus me-2"></i>Create Purchase Order
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="{{ route('vendors.index') }}" class="btn btn-outline-primary w-100">
                                <i class="fas fa-truck me-2"></i>Add Vendor
                            </a>
                        </div>
                        @endif
                        
                        @if(Auth::user()->isAdmin() || Auth::user()->isInventoryManager())
                        <div class="col-md-6">
                            <a href="{{ route('inventory.items.index') }}" class="btn btn-outline-primary w-100">
                                <i class="fas fa-box me-2"></i>Add Inventory Item
                            </a>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
      
   <div class="card">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Notifications</h5>
    </div>
    <div class="card-body">
        @php
            $notifications = Auth::user()->unreadNotifications()->take(10)->get();
        @endphp

        @if($notifications->isEmpty())
            <div class="text-center text-muted">
                <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                <p>No new notifications.</p>
            </div>
        @else
            <ul class="list-group">
                @foreach($notifications as $notification)
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong>{{ $notification->data['title'] ?? 'Notification' }}</strong><br>
                            {{ $notification->data['message'] ?? '' }}
                            <div class="small text-muted">
                                {{ $notification->created_at->diffForHumans() }}
                            </div>
                        </div>
                        <a href="{{ $notification->data['url'] ?? '#' }}" class="btn btn-sm btn-outline-primary">
                            View
                        </a>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
</div>


@else
    <div class="alert alert-danger">
        <p>User information not available. Please log in again.</p>
    </div>
@endif
@endsection