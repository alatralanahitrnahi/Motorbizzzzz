@extends('layouts.app')

@section('title', 'Edit Inventory Batch')

@section('content')
<div class="container-fluid">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-md-8">
            <h2 class="mb-0">
                <i class="fas fa-edit text-primary"></i>
                Edit Inventory Batch
            </h2>
            <p class="text-muted">Update inventory batch information for {{ $batch->batch_number }}</p>
        </div>
        <div class="col-md-4 text-end">
<a href="{{ route('inventory.show', $batch) }}" class="btn btn-info me-2">
                <i class="fas fa-eye"></i> View Details
            </a>
            <a href="{{ route('inventory.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Inventory
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-info-circle"></i> Batch Information
                    </h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('inventory.update', $batch->id) }}" method="POST" id="inventoryForm">
                        @csrf
                        @method('PUT')
                        
                        <!-- Basic Information -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="batch_number" class="form-label">Batch Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" 
                                           id="batch_number"
                                           name="batch_number" 
                                           class="form-control @error('batch_number') is-invalid @enderror" 
                                           value="{{ old('batch_number', $batch->batch_number) }}" 
                                           readonly>
                                    <button type="button" class="btn btn-outline-secondary" id="editBatchBtn" title="Edit manually">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </div>
                                @error('batch_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="form-text text-muted">Unique identifier for this batch. Click 'Edit' to modify manually.</small>
                            </div>
                          <!--  <div class="col-md-6">
                                <label for="supplier_batch_number" class="form-label">Supplier Batch Number</label>
                                <input type="text" 
                                       id="supplier_batch_number"
                                       name="supplier_batch_number" 
                                       class="form-control @error('supplier_batch_number') is-invalid @enderror" 
                                       value="{{ old('supplier_batch_number', $batch->supplier_batch_number) }}">
                                @error('supplier_batch_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div> --->

                        <!-- Material and PO Selection -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="material_id" class="form-label">Material <span class="text-danger">*</span></label>
                                <select id="material_id" 
                                        name="material_id" 
                                        class="form-select @error('material_id') is-invalid @enderror" 
                                        required>
                                    <option value="">Select Material</option>
                                    @foreach($materials as $material)
                                        <option value="{{ $material->id }}" 
                                                {{ old('material_id', $batch->material_id) == $material->id ? 'selected' : '' }}>
                                            {{ $material->name }} ({{ $material->code ?? 'N/A' }})
                                        </option>
                                    @endforeach
                                </select>
                                @error('material_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="purchase_order_id" class="form-label">Purchase Order</label>
                                <select id="purchase_order_id" 
                                        name="purchase_order_id" 
                                        class="form-select @error('purchase_order_id') is-invalid @enderror">
                                    <option value="">Select PO (Optional)</option>
                                    @foreach($purchaseOrders as $po)
                                        <option value="{{ $po->id }}" 
                                                {{ old('purchase_order_id', $batch->purchase_order_id) == $po->id ? 'selected' : '' }}>
                                            {{ $po->po_number }} - {{ optional($po->vendor)->name ?? 'N/A' }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('purchase_order_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Quantity and Weight -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <label for="initial_quantity" class="form-label">Initial Quantity <span class="text-danger">*</span></label>
                                <input type="number" 
                                       id="initial_quantity"
                                       name="initial_quantity" 
                                       class="form-control @error('initial_quantity') is-invalid @enderror" 
                                       value="{{ old('initial_quantity', $batch->initial_quantity) }}" 
                                       min="1" 
                                       step="1"
                                       required>
                                @error('initial_quantity')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="form-text text-muted">Current: {{ $batch->current_quantity }}</small>
                            </div>
                            <div class="col-md-4">
                                <label for="initial_weight" class="form-label">Initial Weight (kg) <span class="text-danger">*</span></label>
                                <input type="number" 
                                       id="initial_weight"
                                       name="initial_weight" 
                                       class="form-control @error('initial_weight') is-invalid @enderror" 
                                       value="{{ old('initial_weight', $batch->initial_weight) }}" 
                                       step="0.001" 
                                       min="0.001" 
                                       required>
                                @error('initial_weight')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="form-text text-muted">Current: {{ number_format($batch->current_weight, 3) }} kg</small>
                            </div>
                            <div class="col-md-4">
                                <label for="unit_price" class="form-label">Unit Price (₹) <span class="text-danger">*</span></label>
                                <input type="number" 
                                       id="unit_price"
                                       name="unit_price" 
                                       class="form-control @error('unit_price') is-invalid @enderror" 
                                       value="{{ old('unit_price', $batch->unit_price) }}" 
                                       step="0.01" 
                                       min="0.01" 
                                       required>
                                @error('unit_price')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Quality and Storage -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="quality_grade" class="form-label">Quality Grade</label>
                                <select id="quality_grade" 
                                        name="quality_grade" 
                                        class="form-select @error('quality_grade') is-invalid @enderror">
                                    <option value="">Select Grade (Optional)</option>
                                    <option value="A" {{ old('quality_grade', $batch->quality_grade) == 'A' ? 'selected' : '' }}>Grade A</option>
                                    <option value="B" {{ old('quality_grade', $batch->quality_grade) == 'B' ? 'selected' : '' }}>Grade B</option>
                                    <option value="C" {{ old('quality_grade', $batch->quality_grade) == 'C' ? 'selected' : '' }}>Grade C</option>
                                    <option value="Premium" {{ old('quality_grade', $batch->quality_grade) == 'Premium' ? 'selected' : '' }}>Premium</option>
                                    <option value="Standard" {{ old('quality_grade', $batch->quality_grade) == 'Standard' ? 'selected' : '' }}>Standard</option>
                                </select>
                                @error('quality_grade')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="storage_location" class="form-label">Storage Location <span class="text-danger">*</span></label>
                                <input type="text" 
                                       id="storage_location"
                                       name="storage_location" 
                                       class="form-control @error('storage_location') is-invalid @enderror" 
                                       value="{{ old('storage_location', $batch->storage_location) }}" 
                                       placeholder="e.g., Warehouse A - Rack 1"
                                       required>
                                @error('storage_location')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Dates -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="received_date" class="form-label">Received Date <span class="text-danger">*</span></label>
                                <input type="date" 
                                       id="received_date"
                                       name="received_date" 
                                       class="form-control @error('received_date') is-invalid @enderror" 
                                       value="{{ old('received_date', $batch->received_date ? $batch->received_date->format('Y-m-d') : '') }}" 
                                       max="{{ date('Y-m-d') }}"
                                       required>
                                @error('received_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="expiry_date" class="form-label">Expiry Date</label>
                                <input type="date" 
                                       id="expiry_date"
                                       name="expiry_date" 
                                       class="form-control @error('expiry_date') is-invalid @enderror" 
                                       value="{{ old('expiry_date', $batch->expiry_date ? $batch->expiry_date->format('Y-m-d') : '') }}">
                                @error('expiry_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="form-text text-muted">Leave blank if no expiry date</small>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                <select id="status" 
                                        name="status" 
                                        class="form-select @error('status') is-invalid @enderror" 
                                        required>
                                    <option value="active" {{ old('status', $batch->status) == 'active' ? 'selected' : '' }}>Active</option>
                                    <option value="inactive" {{ old('status', $batch->status) == 'inactive' ? 'selected' : '' }}>Inactive</option>
                                    <option value="depleted" {{ old('status', $batch->status) == 'depleted' ? 'selected' : '' }}>Depleted</option>
                                    <option value="expired" {{ old('status', $batch->status) == 'expired' ? 'selected' : '' }}>Expired</option>
                                </select>
                                @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Additional Information -->
                        <div class="mb-4">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea id="notes"
                                      name="notes" 
                                      class="form-control @error('notes') is-invalid @enderror" 
                                      rows="3" 
                                      maxlength="1000" 
                                      placeholder="Additional notes about this batch...">{{ old('notes', $batch->notes) }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="form-text text-muted">Maximum 1000 characters</small>
                        </div>
                        
                        <!-- Submit Buttons -->
                        <div class="d-flex gap-2 flex-wrap">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Batch
                            </button>
                            <a href="{{ route('inventory.show', $batch->id) }}" class="btn btn-info">
                                <i class="fas fa-eye"></i> View Details
                            </a>
                            <a href="{{ route('inventory.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Summary Card -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-calculator"></i> Batch Summary
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Initial Quantity:</span>
                            <strong id="summary-quantity">{{ number_format($batch->initial_quantity) }}</strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Current Quantity:</span>
                            <strong class="text-info">{{ number_format($batch->current_quantity) }}</strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Initial Weight:</span>
                            <strong id="summary-weight">{{ number_format($batch->initial_weight, 3) }} kg</strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Current Weight:</span>
                            <strong class="text-info">{{ number_format($batch->current_weight, 3) }} kg</strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span>Unit Price:</span>
                            <strong id="summary-price">₹{{ number_format($batch->unit_price, 2) }}</strong>
                        </div>
                    </div>
                    <hr>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span><strong>Total Value:</strong></span>
                            <strong class="text-primary" id="summary-total">₹{{ number_format($batch->initial_quantity * $batch->unit_price, 2) }}</strong>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span><strong>Current Value:</strong></span>
                            <strong class="text-success">₹{{ number_format($batch->current_quantity * $batch->unit_price, 2) }}</strong>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Note:</strong> Changing initial quantities will affect calculations. Current quantities remain unchanged.
                    </div>
                </div>
            </div>
            
            <!-- Batch Status Card -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-info-circle"></i> Batch Status
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <strong>Current Status:</strong>
                        <span class="badge bg-{{ $batch->status == 'active' ? 'success' : ($batch->status == 'inactive' ? 'secondary' : ($batch->status == 'depleted' ? 'warning' : 'danger')) }}">
                            {{ ucfirst($batch->status) }}
                        </span>
                    </div>
                    <div class="mb-2">
                        <strong>Created:</strong> {{ $batch->created_at->format('M d, Y H:i') }}
                    </div>
                    <div class="mb-2">
                        <strong>Last Updated:</strong> {{ $batch->updated_at->format('M d, Y H:i') }}
                    </div>
                    @if($batch->expiry_date)
                        <div class="mb-2">
                            <strong>Days to Expiry:</strong>
                            @php
                                $daysToExpiry = $batch->expiry_date->diffInDays(now(), false);
                            @endphp
                            <span class="badge bg-{{ $daysToExpiry > 30 ? 'success' : ($daysToExpiry > 7 ? 'warning' : 'danger') }}">
                                {{ $daysToExpiry > 0 ? 'Expired ' . $daysToExpiry . ' days ago' : abs($daysToExpiry) . ' days' }}
                            </span>
                        </div>
                    @endif
                </div>
            </div>
            
            <!-- Guidelines Card -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-lightbulb text-warning"></i> Update Guidelines
                    </h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i>
                            Verify batch number uniqueness
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i>
                            Confirm material selection
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-check text-success"></i>
                            Update storage location if moved
                        </li>
                        <li class="mb-0">
                            <i class="fas fa-check text-success"></i>
                            Set appropriate status
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing edit form...');
    
    // Get form elements with correct IDs
    const quantityInput = document.getElementById('initial_quantity');
    const weightInput = document.getElementById('initial_weight');
    const priceInput = document.getElementById('unit_price');
    const receivedDateInput = document.getElementById('received_date');
    const expiryDateInput = document.getElementById('expiry_date');
    const batchNumberInput = document.getElementById('batch_number');
    const editBatchBtn = document.getElementById('editBatchBtn');
    
    // Get summary elements
    const summaryQuantity = document.getElementById('summary-quantity');
    const summaryWeight = document.getElementById('summary-weight');
    const summaryPrice = document.getElementById('summary-price');
    const summaryTotal = document.getElementById('summary-total');
    
    console.log('Form elements found:', {
        quantityInput: !!quantityInput,
        weightInput: !!weightInput,
        priceInput: !!priceInput,
        summaryElements: !!(summaryQuantity && summaryWeight && summaryPrice && summaryTotal)
    });
    
    // Batch number edit functionality
    if (editBatchBtn) {
        editBatchBtn.addEventListener('click', function() {
            if (batchNumberInput.readOnly) {
                batchNumberInput.readOnly = false;
                batchNumberInput.focus();
                editBatchBtn.innerHTML = '<i class="fas fa-lock"></i>';
                editBatchBtn.title = 'Lock field';
                editBatchBtn.classList.remove('btn-outline-secondary');
                editBatchBtn.classList.add('btn-outline-warning');
            } else {
                batchNumberInput.readOnly = true;
                editBatchBtn.innerHTML = '<i class="fas fa-edit"></i>';
                editBatchBtn.title = 'Edit manually';
                editBatchBtn.classList.remove('btn-outline-warning');
                editBatchBtn.classList.add('btn-outline-secondary');
            }
        });
    }
    
    // Summary update function
    function updateSummary() {
        console.log('Updating summary...');
        
        const quantity = parseFloat(quantityInput?.value) || 0;
        const weight = parseFloat(weightInput?.value) || 0;
        const price = parseFloat(priceInput?.value) || 0;
        const total = quantity * price;
        
        console.log('Values:', { quantity, weight, price, total });
        
        if (summaryQuantity) {
            summaryQuantity.textContent = quantity > 0 ? quantity.toLocaleString() : '-';
        }
        
        if (summaryWeight) {
            summaryWeight.textContent = weight > 0 ? weight.toFixed(3) + ' kg' : '-';
        }
        
        if (summaryPrice) {
            summaryPrice.textContent = price > 0 ? '₹' + price.toLocaleString('en-IN', {minimumFractionDigits: 2}) : '₹-';
        }
        
        if (summaryTotal) {
            summaryTotal.textContent = total > 0 ? '₹' + total.toLocaleString('en-IN', {minimumFractionDigits: 2}) : '₹-';
        }
        
        console.log('Summary updated');
    }
    
    // Add event listeners for summary updates
    const inputsToWatch = [quantityInput, weightInput, priceInput].filter(Boolean);
    
    inputsToWatch.forEach(input => {
        input.addEventListener('input', updateSummary);
        input.addEventListener('change', updateSummary);
        input.addEventListener('keyup', updateSummary);
    });
    
    console.log('Event listeners added to', inputsToWatch.length, 'inputs');
    
    // Date validation for expiry date
    if (receivedDateInput && expiryDateInput) {
        receivedDateInput.addEventListener('change', function() {
            const receivedDate = this.value;
            if (receivedDate) {
                // Set minimum expiry date to the day after received date
                const minExpiryDate = new Date(receivedDate);
                minExpiryDate.setDate(minExpiryDate.getDate() + 1);
                expiryDateInput.min = minExpiryDate.toISOString().split('T')[0];
                
                // Clear expiry date if it's before received date
                if (expiryDateInput.value && new Date(expiryDateInput.value) <= new Date(receivedDate)) {
                    expiryDateInput.value = '';
                }
            }
        });
        
        expiryDateInput.addEventListener('change', function() {
            const expiryDate = this.value;
            const receivedDate = receivedDateInput.value;
            
            if (expiryDate && receivedDate && new Date(expiryDate) <= new Date(receivedDate)) {
                alert('Expiry date must be after received date');
                this.value = '';
            }
        });
    }
    
    // Form validation
    const form = document.getElementById('inventoryForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const expiryDate = expiryDateInput?.value;
            const receivedDate = receivedDateInput?.value;
            
            // Validate expiry date is after received date
            if (expiryDate && receivedDate && new Date(expiryDate) <= new Date(receivedDate)) {
                alert('Expiry date must be after received date');
                e.preventDefault();
                return false;
            }
            
            // Validate received date is not in the future
            if (receivedDate && new Date(receivedDate) > new Date()) {
                alert('Received date cannot be in the future');
                e.preventDefault();
                return false;
            }
            
            // Validate required fields
            const requiredFields = ['material_id', 'initial_quantity', 'initial_weight', 'unit_price', 'storage_location', 'status'];
            for (let fieldName of requiredFields) {
                const field = document.getElementById(fieldName);
                if (field && !field.value.trim()) {
                    alert(`Please fill in the ${fieldName.replace('_', ' ')} field`);
                    field.focus();
                    e.preventDefault();
                    return false;
                }
            }
            
            // Confirm before submission
            const quantity = quantityInput?.value || 0;
            const price = priceInput?.value || 0;
            const total = quantity * price;
            
            if (!confirm(`Are you sure you want to update this inventory batch?\n\nQuantity: ${quantity}\nTotal Value: ₹${total.toLocaleString('en-IN', {minimumFractionDigits: 2})}`)) {
                e.preventDefault();
                return false;
            }
        });
    }
    
    // Initial calculation
    console.log('Performing initial summary calculation...');
    updateSummary();
    
    // Debug: Log current values
    console.log('Initial values:', {
        quantity: quantityInput?.value,
        weight: weightInput?.value,
        price: priceInput?.value
    });
});
</script>

@endsection