@extends('layouts.app')
@section('title', 'Edit Purchase Order')

@section('content')
<div class="container-fluid">
    {{-- Success/Error Messages --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    {{-- Page Header --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0">Edit Purchase Order</h2>
            <small class="text-muted">Update purchase order details</small>
        </div>
        <div>
            <a href="{{ route('purchase-orders.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
<a href="{{ route('purchase-orders.show', ['purchaseOrder' => $order->id]) }}" class="btn btn-outline-info">
    <i class="fas fa-eye"></i> View Order
</a>
        </div>
    </div>

    <form action="{{ route('purchase-orders.update', $order) }}" method="POST" id="editPurchaseOrderForm">
        @csrf
        @method('PUT')
        
        <div class="row">
            {{-- Left Column --}}
            <div class="col-lg-8">
                {{-- Basic Information --}}
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle"></i> Basic Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="po_number" class="form-label">PO Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('po_number') is-invalid @enderror" 
                                           id="po_number" name="po_number" 
                                           value="{{ old('po_number', $order->po_number ?? '') }}" 
                                           placeholder="Enter PO Number" required>
                                    @error('po_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="vendor_id" class="form-label">Vendor <span class="text-danger">*</span></label>
                                    <select class="form-select @error('vendor_id') is-invalid @enderror" 
                                            id="vendor_id" name="vendor_id" required>
                                        <option value="">Select Vendor</option>
                                        @foreach($vendors ?? [] as $vendor)
                                            <option value="{{ $vendor->id }}" 
                                                    {{ old('vendor_id', $order->vendor_id ?? '') == $vendor->id ? 'selected' : '' }}>
                                                {{ $vendor->name }} - {{ $vendor->phone ?? 'No Phone' }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('vendor_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="po_date" class="form-label">PO Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control @error('po_date') is-invalid @enderror" 
                                           id="po_date" name="po_date" 
                                           value="{{ old('po_date', isset($order->po_date) ? \Carbon\Carbon::parse($order->po_date)->format('Y-m-d') : '') }}" 
                                           required>
                                    @error('po_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="expected_delivery" class="form-label">Expected Delivery Date</label>
                                    <input type="date" class="form-control @error('expected_delivery') is-invalid @enderror" 
                                           id="expected_delivery" name="expected_delivery" 
                                           value="{{ old('expected_delivery', isset($order->expected_delivery) ? \Carbon\Carbon::parse($order->expected_delivery)->format('Y-m-d') : '') }}">
                                    @error('expected_delivery')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="payment_mode" class="form-label">Payment Mode <span class="text-danger">*</span></label>
                                    <select class="form-select @error('payment_mode') is-invalid @enderror" 
                                            id="payment_mode" name="payment_mode" required>
                                        <option value="cash" {{ old('payment_mode', $order->payment_mode ?? '') == 'cash' ? 'selected' : '' }}>Cash</option>
                                        <option value="bank_transfer" {{ old('payment_mode', $order->payment_mode ?? '') == 'bank_transfer' ? 'selected' : '' }}>Bank Transfer</option>
                                        <option value="cheque" {{ old('payment_mode', $order->payment_mode ?? '') == 'cheque' ? 'selected' : '' }}>Cheque</option>
                                        <option value="credit" {{ old('payment_mode', $order->payment_mode ?? '') == 'credit' ? 'selected' : '' }}>Credit</option>
                                    </select>
                                    @error('payment_mode')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="credit_days" class="form-label">Credit Days</label>
                                    <select class="form-select @error('credit_days') is-invalid @enderror" 
                                            id="credit_days" name="credit_days">
                                        <option value="">Select Credit Days</option>
                                        <option value="0" {{ old('credit_days', $order->credit_days ?? '') == '0' ? 'selected' : '' }}>0 Days</option>
                                        <option value="15" {{ old('credit_days', $order->credit_days ?? '') == '15' ? 'selected' : '' }}>15 Days</option>
                                        <option value="30" {{ old('credit_days', $order->credit_days ?? '') == '30' ? 'selected' : '' }}>30 Days</option>
                                        <option value="45" {{ old('credit_days', $order->credit_days ?? '') == '45' ? 'selected' : '' }}>45 Days</option>
                                        <option value="60" {{ old('credit_days', $order->credit_days ?? '') == '60' ? 'selected' : '' }}>60 Days</option>
                                    </select>
                                    @error('credit_days')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="shipping_cost" class="form-label">Shipping Cost</label>
                                    <input type="number" class="form-control @error('shipping_cost') is-invalid @enderror" 
                                           id="shipping_cost" name="shipping_cost" 
                                           value="{{ old('shipping_cost', $order->shipping_cost ?? 0) }}" 
                                           min="0" step="0.01" placeholder="0.00">
                                    @error('shipping_cost')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select @error('status') is-invalid @enderror" 
                                            id="status" name="status">
                                        <option value="pending" {{ old('status', $order->status ?? 'pending') == 'pending' ? 'selected' : '' }}>Pending</option>
                                        <option value="approved" {{ old('status', $order->status ?? 'pending') == 'approved' ? 'selected' : '' }}>Approved</option>
                                        <option value="ordered" {{ old('status', $order->status ?? 'pending') == 'ordered' ? 'selected' : '' }}>Ordered</option>
                                        <option value="received" {{ old('status', $order->status ?? 'pending') == 'received' ? 'selected' : '' }}>Received</option>
                                        <option value="cancelled" {{ old('status', $order->status ?? 'pending') == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                                    </select>
                                    @error('status')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea class="form-control @error('notes') is-invalid @enderror" 
                                      id="notes" name="notes" rows="3" 
                                      placeholder="Additional notes or instructions">{{ old('notes', $order->notes) }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                {{-- Purchase Order Items --}}
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list"></i> Order Items
                        </h5>
                        <button type="button" class="btn btn-sm btn-primary" id="addItemBtn">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    <div class="card-body">
                        <div id="itemsContainer">
                            @forelse($order->purchaseOrderItems ?? [] as $index => $item)
                                <div class="item-row border-bottom pb-3 mb-3" data-index="{{ $index }}">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-label">Material <span class="text-danger">*</span></label>
                                            <select class="form-select material-select" name="items[{{ $index }}][material_id]" required>
                                                <option value="">Select Material</option>
                                                @foreach($materials ?? [] as $material)
                                                    <option value="{{ $material->id }}" 
                                                            data-price="{{ $material->unit_price ?? 0 }}"
                                                            data-gst="{{ $material->gst_rate ?? 0 }}"
                                                            {{ old('items.'.$index.'.material_id', $item->material_id) == $material->id ? 'selected' : '' }}>
                                                        {{ $material->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Item Name</label>
                                            <input type="text" class="form-control" 
                                                   name="items[{{ $index }}][item_name]" 
                                                   value="{{ old('items.'.$index.'.item_name', $item->item_name) }}" 
                                                   placeholder="Item name">
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Quantity <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control item-quantity" 
                                                   name="items[{{ $index }}][quantity]" 
                                                   value="{{ old('items.'.$index.'.quantity', $item->quantity) }}" 
                                                   min="0.001" step="0.001" placeholder="1" required>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Weight</label>
                                            <input type="number" class="form-control item-weight" 
                                                   name="items[{{ $index }}][weight]" 
                                                   value="{{ old('items.'.$index.'.weight', $item->weight ?? 1) }}" 
                                                   min="0.001" step="0.001" placeholder="1">
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Unit Price</label>
                                            <input type="number" class="form-control item-price" 
                                                   name="items[{{ $index }}][unit_price]" 
                                                   value="{{ old('items.'.$index.'.unit_price', $item->unit_price) }}" 
                                                   min="0" step="0.01" placeholder="0.00">
                                        </div>
                                        <div class="col-md-1">
                                            <label class="form-label">&nbsp;</label>
                                            <div>
                                                <button type="button" class="btn btn-sm btn-outline-danger remove-item-btn">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label class="form-label">Description</label>
                                            <textarea class="form-control" 
                                                      name="items[{{ $index }}][description]" rows="2" 
                                                      placeholder="Item description">{{ old('items.'.$index.'.description', $item->description) }}</textarea>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">GST Rate (%)</label>
                                            <input type="number" class="form-control item-gst" 
                                                   name="items[{{ $index }}][gst_rate]" 
                                                   value="{{ old('items.'.$index.'.gst_rate', $item->gst_rate ?? 0) }}" 
                                                   min="0" max="100" step="0.01" placeholder="0">
                                        </div>
                                       
                                        <div class="col-md-2">
                                            <label class="form-label">Expiry Date</label>
                                            <input type="date" class="form-control" 
                                                   name="items[{{ $index }}][expiry_date]" 
                                                   value="{{ old('items.'.$index.'.expiry_date', isset($item->expiry_date) ? \Carbon\Carbon::parse($item->expiry_date)->format('Y-m-d') : '') }}">
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <div class="p-2 bg-light rounded">
                                                <small>
                                                    <strong>Subtotal:</strong> $<span class="item-subtotal">{{ number_format($item->subtotal ?? 0, 2) }}</span> |
                                                    <strong>GST:</strong> $<span class="item-gst-amount">{{ number_format($item->gst_amount ?? 0, 2) }}</span> |
                                                    <strong>Total:</strong> $<span class="item-total">{{ number_format($item->total ?? 0, 2) }}</span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="item-row border-bottom pb-3 mb-3" data-index="0">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-label">Material <span class="text-danger">*</span></label>
                                            <select class="form-select material-select" name="items[0][material_id]" required>
                                                <option value="">Select Material</option>
                                                @foreach($materials ?? [] as $material)
                                                    <option value="{{ $material->id }}" 
                                                            data-price="{{ $material->unit_price ?? 0 }}"
                                                            data-gst="{{ $material->gst_rate ?? 0 }}">
                                                        {{ $material->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Item Name</label>
                                            <input type="text" class="form-control" 
                                                   name="items[0][item_name]" 
                                                   placeholder="Item name">
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Quantity <span class="text-danger">*</span></label>
                                            <input type="number" class="form-control item-quantity" 
                                                   name="items[0][quantity]" 
                                                   value="1" min="0.001" step="0.001" placeholder="1" required>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Weight</label>
                                            <input type="number" class="form-control item-weight" 
                                                   name="items[0][weight]" 
                                                   value="1" min="0.001" step="0.001" placeholder="1">
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">Unit Price</label>
                                            <input type="number" class="form-control item-price" 
                                                   name="items[0][unit_price]" 
                                                   min="0" step="0.01" placeholder="0.00">
                                        </div>
                                        <div class="col-md-1">
                                            <label class="form-label">&nbsp;</label>
                                            <div>
                                                <button type="button" class="btn btn-sm btn-outline-danger remove-item-btn">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label class="form-label">Description</label>
                                            <textarea class="form-control" 
                                                      name="items[0][description]" rows="2" 
                                                      placeholder="Item description"></textarea>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label">GST Rate (%)</label>
                                            <input type="number" class="form-control item-gst" 
                                                   name="items[0][gst_rate]" 
                                                   min="0" max="100" step="0.01" placeholder="0">
                                        </div>
                                       
                                        <div class="col-md-2">
                                            <label class="form-label">Expiry Date</label>
                                            <input type="date" class="form-control" 
                                                   name="items[0][expiry_date]">
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <div class="p-2 bg-light rounded">
                                                <small>
                                                    <strong>Subtotal:</strong> $<span class="item-subtotal">0.00</span> |
                                                    <strong>GST:</strong> $<span class="item-gst-amount">0.00</span> |
                                                    <strong>Total:</strong> $<span class="item-total">0.00</span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforelse
                        </div>
                        
                        @if($errors->has('items'))
                            <div class="alert alert-danger mt-3">
                                {{ $errors->first('items') }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            {{-- Right Column - Summary --}}
            <div class="col-lg-4">
                {{-- Order Summary --}}
                <div class="card mb-4 sticky-top" style="top: 20px;">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-calculator"></i> Order Summary
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <span id="subtotalDisplay">${{ number_format($order->total_amount ?? 0, 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>GST Amount:</span>
                            <span id="gstAmountDisplay">${{ number_format($order->gst_amount ?? 0, 2) }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Shipping Cost:</span>
                            <span id="shippingCostDisplay">${{ number_format($order->shipping_cost ?? 0, 2) }}</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Final Amount:</strong>
                            <strong id="finalAmountDisplay" class="text-success">
                                ${{ number_format($order->final_amount ?? 0, 2) }}
                            </strong>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Purchase Order
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="window.history.back()">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        </div>
                    </div>
                </div>

                {{-- Current Status Info --}}
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-info-circle"></i> Current Status
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-2">
                            <small class="text-muted">Current Status:</small><br>
                            <span class="badge bg-{{ match($order->status) {
                                'approved' => 'success',
                                'pending' => 'warning',
                                'received' => 'info',
                                'ordered' => 'primary',
                                'cancelled' => 'danger',
                                default => 'secondary'
                            } }}">
                                {{ ucfirst($order->status ?? 'Unknown') }}
                            </span>
                        </div>
                        
                        @if($order->po_date)
                            <div class="mb-2">
                                <small class="text-muted">Created:</small><br>
                                <small>{{ \Carbon\Carbon::parse($order->po_date)->format('M d, Y') }}</small>
                            </div>
                        @endif
                        
                        @if($order->expected_delivery)
                            <div class="mb-2">
                                <small class="text-muted">Expected Delivery:</small><br>
                                <small class="{{ \Carbon\Carbon::parse($order->expected_delivery)->isPast() && $order->status !== 'received' ? 'text-danger' : '' }}">
                                    {{ \Carbon\Carbon::parse($order->expected_delivery)->format('M d, Y') }}
                                    @if(\Carbon\Carbon::parse($order->expected_delivery)->isPast() && $order->status !== 'received')
                                        <i class="fas fa-exclamation-triangle"></i> Overdue
                                    @endif
                                </small>
                            </div>
                        @endif
                        
                        @if($order->vendor)
                            <div class="mb-2">
                                <small class="text-muted">Vendor:</small><br>
                                <small>{{ $order->vendor->name }}</small>
                                @if($order->vendor->phone)
                                    <br><small class="text-muted">{{ $order->vendor->phone }}</small>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

{{-- Hidden Item Template --}}
<template id="itemTemplate">
    <div class="item-row border-bottom pb-3 mb-3" data-index="">
        <div class="row">
            <div class="col-md-3">
                <label class="form-label">Material <span class="text-danger">*</span></label>
                <select class="form-select material-select" name="items[][material_id]" required>
                    <option value="">Select Material</option>
                    @foreach($materials ?? [] as $material)
                        <option value="{{ $material->id }}" 
                                data-price="{{ $material->unit_price ?? 0 }}"
                                data-gst="{{ $material->gst_rate ?? 0 }}">
                            {{ $material->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Item Name</label>
                <input type="text" class="form-control" name="items[][item_name]" placeholder="Item name">
            </div>
            <div class="col-md-2">
                <label class="form-label">Quantity <span class="text-danger">*</span></label>
                <input type="number" class="form-control item-quantity" name="items[][quantity]" value="1" min="0.001" step="0.001" placeholder="1" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Weight</label>
                <input type="number" class="form-control item-weight" name="items[][weight]" value="1" min="0.001" step="0.001" placeholder="1">
            </div>
            <div class="col-md-2">
                <label class="form-label">Unit Price</label>
                <input type="number" class="form-control item-price" name="items[][unit_price]" min="0" step="0.01" placeholder="0.00">
            </div>
            <div class="col-md-1">
                <label class="form-label">&nbsp;</label>
                <div>
                    <button type="button" class="btn btn-sm btn-outline-danger remove-item-btn">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-md-6">
                <label class="form-label">Description</label>
                <textarea class="form-control" name="items[][description]" rows="2" placeholder="Item description"></textarea>
            </div>
            <div class="col-md-2">
                <label class="form-label">GST Rate (%)</label>
                <input type="number" class="form-control item-gst" name="items[][gst_rate]" min="0" max="100" step="0.01" placeholder="0">
            </div>
        </div>
    </div>
</template>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    let itemIndex = {{ count($order->purchaseOrderItems ?? []) > 0 ? count($order->purchaseOrderItems) : 1 }};
    
    // Add Item functionality
    document.getElementById('addItemBtn').addEventListener('click', function() {
        const template = document.getElementById('itemTemplate');
        const clone = template.content.cloneNode(true);
        
        // Update the data-index and name attributes
        const itemRow = clone.querySelector('.item-row');
        itemRow.setAttribute('data-index', itemIndex);
        
        // Update all input names with the correct index
        clone.querySelectorAll('input, textarea').forEach(function(input) {
            const name = input.getAttribute('name');
            if (name) {
                input.setAttribute('name', name.replace('[]', '[' + itemIndex + ']'));
            }
        });
        
        document.getElementById('itemsContainer').appendChild(clone);
        itemIndex++;
        
        // Add event listeners to new item
        bindItemEvents();
        calculateTotals();
    });
    
    // Remove item functionality
    function bindItemEvents() {
        document.querySelectorAll('.remove-item-btn').forEach(function(btn) {
            btn.replaceWith(btn.cloneNode(true)); // Remove existing listeners
        });
        
        document.querySelectorAll('.remove-item-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                if (document.querySelectorAll('.item-row').length > 1) {
                    this.closest('.item-row').remove();
                    calculateTotals();
                } else {
                    alert('At least one item is required.');
                }
            });
        });
        
        // Bind calculation events
        document.querySelectorAll('.item-quantity, .item-price').forEach(function(input) {
            input.replaceWith(input.cloneNode(true)); // Remove existing listeners
        });
        
        document.querySelectorAll('.item-quantity, .item-price').forEach(function(input) {
            input.addEventListener('input', function() {
                calculateItemTotal(this);
                calculateTotals();
            });
        });
    }
    
    // Calculate individual item total
    function calculateItemTotal(input) {
        const row = input.closest('.item-row');
        const quantity = parseFloat(row.querySelector('.item-quantity').value) || 0;
        const price = parseFloat(row.querySelector('.item-price').value) || 0;
        const total = quantity * price;
        
        row.querySelector('.item-total').value = '$' + total.toFixed(2);
    }
    
    // Calculate overall totals
    function calculateTotals() {
        let subtotal = 0;
        
        document.querySelectorAll('.item-row').forEach(function(row) {
            const quantity = parseFloat(row.querySelector('.item-quantity').value) || 0;
            const price = parseFloat(row.querySelector('.item-price').value) || 0;
            subtotal += quantity * price;
        });
        
        const gstRate = parseFloat(document.getElementById('gst_rate').value) || 0;
        const gstAmount = subtotal * (gstRate / 100);
        const totalAmount = subtotal + gstAmount;
        
        document.getElementById('subtotalDisplay').textContent = '$' + subtotal.toFixed(2);
        document.getElementById('gstRateDisplay').textContent = gstRate.toFixed(2);
        document.getElementById('gstAmountDisplay').textContent = '$' + gstAmount.toFixed(2);
        document.getElementById('totalAmountDisplay').textContent = '$' + totalAmount.toFixed(2);
    }
    
    // GST rate change
    document.getElementById('gst_rate').addEventListener('input', calculateTotals);
    
    // Initial binding and calculation
    bindItemEvents();
    
    // Calculate initial item totals
    document.querySelectorAll('.item-row').forEach(function(row) {
        calculateItemTotal(row.querySelector('.item-quantity'));
    });
    
    calculateTotals();
    
    // Form submission validation
    document.getElementById('editPurchaseOrderForm').addEventListener('submit', function(e) {
        let hasItems = false;
        document.querySelectorAll('.item-row').forEach(function(row) {
            const productName = row.querySelector('input[name*="[product_name]"]').value.trim();
            const quantity = row.querySelector('.item-quantity').value;
            const price = row.querySelector('.item-price').value;
            
            if (productName && quantity && price) {
                hasItems = true;
            }
        });
        
        if (!hasItems) {
            e.preventDefault();
            alert('Please add at least one item with complete information.');
        }
    });
});
</script>
@endpush
@endsection