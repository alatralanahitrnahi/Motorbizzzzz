@extends('layouts.app')
@section('title', 'Purchase Order Details')

@section('content')
<div class="container">
    {{-- Success Message --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    {{-- Page Header --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Purchase Order Details</h1>
        <div>
            <a href="{{ route('purchase-orders.edit', $purchaseOrder) }}" class="btn btn-warning">
                <i class="fas fa-edit"></i> Edit
            </a>
            <a href="{{ route('purchase-orders.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>

    {{-- Purchase Order Details Card --}}
    <div class="card mb-4">
        <div class="card-header"><h5>Order Information</h5></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr><th>PO Number</th><td>{{ $purchaseOrder->po_number ?? 'N/A' }}</td></tr>
                    <tr><th>Supplier Name</th><td>{{ $purchaseOrder->vendor?->name ?? 'N/A' }}</td></tr>
                    <tr><th>Supplier Contact</th><td>{{ $purchaseOrder->vendor?->phone ?? 'N/A' }}</td></tr>
                    <tr><th>Order Date</th><td>{{ optional($purchaseOrder->po_date)->format('M d, Y') ?? 'N/A' }}</td></tr>
                    <tr><th>Expected Delivery</th><td>{{ optional($purchaseOrder->expected_delivery)->format('M d, Y') ?? 'N/A' }}</td></tr>
                    <tr><th>Payment Mode</th><td>{{ ucfirst($purchaseOrder->payment_mode ?? 'N/A') }}</td></tr>
                    <tr><th>Credit Days</th><td>{{ $purchaseOrder->credit_days ?? 0 }} days</td></tr>
                    <tr><th>Shipping Cost</th><td>${{ number_format($purchaseOrder->shipping_cost ?? 0, 2) }}</td></tr>
                    <tr><th>Total Amount</th><td>${{ number_format($purchaseOrder->total_amount ?? 0, 2) }}</td></tr>
                    <tr><th>GST Amount</th><td>${{ number_format($purchaseOrder->gst_amount ?? 0, 2) }}</td></tr>
                    <tr><th>Final Amount</th><td><strong>${{ number_format($purchaseOrder->final_amount ?? 0, 2) }}</strong></td></tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <span class="badge bg-{{ match($purchaseOrder->status) {
                                'approved' => 'success',
                                'pending' => 'warning',
                                'received' => 'info',
                                'cancelled' => 'danger',
                                'ordered' => 'primary',
                                default => 'secondary'
                            } }}">
                                {{ ucfirst($purchaseOrder->status ?? 'Unknown') }}
                            </span>
                        </td>
                    </tr>
                    @if($purchaseOrder->notes)
                        <tr><th>Notes</th><td>{{ $purchaseOrder->notes }}</td></tr>
                    @endif
                    <tr><th>Created At</th><td>{{ $purchaseOrder->created_at?->format('M d, Y h:i A') ?? 'N/A' }}</td></tr>
                    <tr><th>Updated At</th><td>{{ $purchaseOrder->updated_at?->format('M d, Y h:i A') ?? 'N/A' }}</td></tr>
                </table>
            </div>
        </div>
    </div>

    {{-- Purchase Order Items --}}
    @if($purchaseOrder->items && $purchaseOrder->items->count())
        <div class="card">
            <div class="card-header"><h5>Order Items</h5></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Item Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Weight</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                                <th>GST Rate</th>
                                <th>GST Amount</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($purchaseOrder->items as $item)
                                <tr>
                                    <td>{{ $item->item_name ?? $item->material?->name ?? 'N/A' }}</td>
                                    <td>{{ $item->description ?? '-' }}</td>
                                    <td>{{ number_format($item->quantity ?? 0, 3) }}</td>
                                    <td>{{ number_format($item->weight ?? 0, 3) }}</td>
                                    <td>${{ number_format($item->unit_price ?? 0, 2) }}</td>
                                    <td>${{ number_format($item->subtotal ?? 0, 2) }}</td>
                                    <td>{{ number_format($item->gst_rate ?? 0, 2) }}%</td>
                                    <td>${{ number_format($item->gst_amount ?? 0, 2) }}</td>
                                    <td>${{ number_format($item->total ?? 0, 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <th colspan="5">Total</th>
                                <th>${{ number_format($purchaseOrder->total_amount ?? 0, 2) }}</th>
                                <th></th>
                                <th>${{ number_format($purchaseOrder->gst_amount ?? 0, 2) }}</th>
                                <th>${{ number_format($purchaseOrder->final_amount ?? 0, 2) }}</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    @endif

    {{-- Action Buttons --}}
    <div class="mt-4 d-flex gap-2">
        <a href="{{ route('purchase-orders.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        <a href="{{ route('purchase-orders.edit', $purchaseOrder) }}" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit Order
        </a>
        @if(in_array($purchaseOrder->status, ['pending', 'cancelled']))
            <form action="{{ route('purchase-orders.destroy', $purchaseOrder) }}" method="POST" 
                  onsubmit="return confirm('Are you sure you want to delete this purchase order?');" 
                  style="display:inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </form>
        @endif
        <a href="{{ route('purchase_orders.generate_pdf', $purchaseOrder) }}" class="btn btn-info">
            <i class="fas fa-file-pdf"></i> Generate PDF
        </a>
    </div>
</div>


<!-- Purchase Order Show Page Update (add to your existing show.blade.php) -->
<!----   @if($purchaseOrder->status === 'pending' && auth()->user()->can('approve', $purchaseOrder))
<div class="card mt-3">
    <div class="card-header bg-warning">
        <h5 class="mb-0 text-dark">Approval Required</h5>
    </div>
    <div class="card-body">
        <p>This purchase order is pending approval.</p>
        
        <form method="POST" action="{{ route('purchase-orders.approve', $purchaseOrder) }}" class="d-inline">
            @csrf
            <div class="form-group">
                <label for="approval_notes">Approval Notes (Optional)</label>
                <textarea name="approval_notes" id="approval_notes" class="form-control" rows="3" placeholder="Add any approval notes..."></textarea>
            </div>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-check"></i> Approve
            </button>
        </form>
        
        <button type="button" class="btn btn-danger ml-2" data-toggle="modal" data-target="#rejectModal">
            <i class="fas fa-times"></i> Reject
        </button>
    </div>
</div>  

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" action="{{ route('purchase-orders.reject', $purchaseOrder) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Reject Purchase Order</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rejection_notes">Reason for Rejection *</label>
                        <textarea name="approval_notes" id="rejection_notes" class="form-control" rows="4" required placeholder="Please provide a reason for rejection..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Purchase Order</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif

@php
    $status = $purchaseOrder->status;
    $approvedBy = $purchaseOrder->approvedBy->name ?? 'System';
    $approvedAt = $purchaseOrder->approved_at?->format('d M Y, h:i A') ?? 'Unknown Date';
    $updatedAt = $purchaseOrder->updated_at?->format('d M Y, h:i A') ?? 'Unknown Date';
    $approvalNotes = $purchaseOrder->approval_notes;
@endphp

@if($status === 'approved')
<div class="alert alert-success">
    <strong>Approved</strong> by {{ $approvedBy }} on {{ $approvedAt }}
    @if($approvalNotes)
        <br><em>Notes: {{ $approvalNotes }}</em>
    @endif
</div>
@endif

@if($status === 'rejected')
<div class="alert alert-danger">
    <strong>Rejected</strong> by {{ $approvedBy }} on {{ $approvedAt }}
    @if($approvalNotes)
        <br><em>Reason: {{ $approvalNotes }}</em>
    @endif
</div>
@endif  ----->

@endsection
