<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Purchase Order PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            padding: 8px;
            border: 1px solid #333;
            text-align: left;
        }
        .badge {
            padding: 5px 10px;
            color: #fff;
            border-radius: 4px;
            font-size: 10px;
        }
        .bg-success { background-color: #28a745; }
        .bg-warning { background-color: #ffc107; }
        .bg-info { background-color: #17a2b8; }
        .bg-danger { background-color: #dc3545; }
        .bg-primary { background-color: #007bff; }
        .bg-secondary { background-color: #6c757d; }
    </style>
</head>
<body>

    <h2>Purchase Order</h2>

    <table class="table">
        <tr><th>PO Number</th><td>{{ $purchaseOrder->po_number ?? 'N/A' }}</td></tr>
        <tr><th>Supplier Name</th><td>{{ $purchaseOrder->vendor?->name ?? 'N/A' }}</td></tr>
        <tr><th>Supplier Contact</th><td>{{ $purchaseOrder->vendor?->phone ?? 'N/A' }}</td></tr>
        <tr><th>Order Date</th><td>{{ optional($purchaseOrder->po_date)->format('M d, Y') ?? 'N/A' }}</td></tr>
        <tr><th>Expected Delivery</th><td>{{ optional($purchaseOrder->expected_delivery)->format('M d, Y') ?? 'N/A' }}</td></tr>
        <tr><th>Payment Mode</th><td>{{ ucfirst($purchaseOrder->payment_mode ?? 'N/A') }}</td></tr>
        <tr><th>Credit Days</th><td>{{ $purchaseOrder->credit_days ?? 0 }} days</td></tr>
        <tr><th>Shipping Cost</th><td>${{ number_format($purchaseOrder->shipping_cost ?? 0, 2) }}</td></tr>
        <tr><th>Total Amount</th><td>${{ number_format($purchaseOrder->total_amount ?? 0, 2) }}</td></tr>
        <tr><th>GST Amount</th><td>${{ number_format($purchaseOrder->gst_amount ?? 0, 2) }}</td></tr>
        <tr><th>Final Amount</th><td><strong>${{ number_format($purchaseOrder->final_amount ?? 0, 2) }}</strong></td></tr>
        <tr>
            <th>Status</th>
            <td>
                <span class="badge bg-{{ match($purchaseOrder->status) {
                    'approved' => 'success',
                    'pending' => 'warning',
                    'received' => 'info',
                    'cancelled' => 'danger',
                    'ordered' => 'primary',
                    default => 'secondary'
                } }}">
                    {{ ucfirst($purchaseOrder->status ?? 'Unknown') }}
                </span>
            </td>
        </tr>
        @if($purchaseOrder->notes)
            <tr><th>Notes</th><td>{{ $purchaseOrder->notes }}</td></tr>
        @endif
        <tr><th>Created At</th><td>{{ $purchaseOrder->created_at?->format('M d, Y h:i A') ?? 'N/A' }}</td></tr>
        <tr><th>Updated At</th><td>{{ $purchaseOrder->updated_at?->format('M d, Y h:i A') ?? 'N/A' }}</td></tr>
    </table>

    <h3>Items</h3>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Material</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>GST Rate (%)</th>
                <th>GST Amount</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($purchaseOrder->purchaseOrderItems as $index => $item)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $item->item_name ?? $item->material->name ?? 'N/A' }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td>${{ number_format($item->unit_price, 2) }}</td>
                    <td>{{ number_format($item->gst_rate, 2) }}</td>
                    <td>${{ number_format($item->gst_amount, 2) }}</td>
                    <td>${{ number_format($item->total, 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="7">No items found.</td></tr>
            @endforelse
        </tbody>
    </table>

</body>
</html>
