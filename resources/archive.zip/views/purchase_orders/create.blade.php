@extends('layouts.app')
@section('title', 'Create Purchase Order')
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Create Purchase Order</h2>
        <a href="{{ route('purchase-orders.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Details
        </a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif

    <form action="{{ route('purchase-orders.store') }}" method="POST" id="purchaseOrderForm">
        @csrf

        <div class="card mb-4">
            <div class="card-header">Purchase Order Details</div>
            <div class="card-body row">
               <!-- <div class="col-md-6 mb-3">
                    <label for="supplier_name" class="form-label">Supplier Name *</label>
                    <input type="text" name="supplier_name" id="supplier_name" class="form-control" value="{{ old('supplier_name') }}" required>
                </div>  -->
              
                <div class="col-md-6 mb-3">
                    <label for="po_date" class="form-label">PO Date *</label>
                    <input type="date" name="po_date" id="po_date" class="form-control" value="{{ old('po_date', \Carbon\Carbon::today()->format('Y-m-d')) }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="supplier_contact" class="form-label">Supplier Contact</label>
                    <div class="input-group">
                        <span class="input-group-text">+91</span>
                        <input type="text" name="supplier_contact" id="supplier_contact" class="form-control" value="{{ old('supplier_contact') }}" maxlength="10" pattern="\d{10}" title="Enter 10 digit mobile number">
                    </div>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="vendor_id" class="form-label">Vendor *</label>
                    <select name="vendor_id" id="vendor_id" class="form-select @error('vendor_id') is-invalid @enderror" required>
                        <option value="">Select Vendor</option>
                        @foreach($vendors as $vendor)
                            <option value="{{ $vendor->id }}" {{ old('vendor_id') == $vendor->id ? 'selected' : '' }}>{{ $vendor->name }}</option>
                        @endforeach
                    </select>
                    @error('vendor_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-6 mb-3">
                    <label for="order_date" class="form-label">Order Date *</label>
                    <input type="date" name="order_date" id="order_date" class="form-control" value="{{ old('order_date', date('Y-m-d')) }}" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="expected_delivery" class="form-label">Expected Delivery</label>
                    <input type="date" name="expected_delivery" id="expected_delivery" class="form-control" value="{{ old('expected_delivery') }}">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="payment_mode" class="form-label">Payment Mode *</label>
                    <select name="payment_mode" id="payment_mode" class="form-select" required>
                        <option value="">Select Payment Mode</option>
                        @foreach(['cash', 'bank_transfer', 'cheque', 'credit'] as $mode)
                            <option value="{{ $mode }}" {{ old('payment_mode') == $mode ? 'selected' : '' }}>{{ ucfirst(str_replace('_', ' ', $mode)) }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="credit_days" class="form-label">Credit Days</label>
                    <select name="credit_days" id="credit_days" class="form-select">
                        <option value="">Choose</option>
                        @foreach([0, 15, 30, 45, 60] as $day)
                            <option value="{{ $day }}" {{ old('credit_days') == $day ? 'selected' : '' }}>{{ $day }} Days{{ $day == 0 ? ' (Cash)' : '' }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label for="status" class="form-label">Status *</label>
                    <select name="status" id="status" class="form-select" required>
                        @foreach(['pending', 'approved', 'received', 'completed'] as $status)
                            <option value="{{ $status }}" {{ old('status', 'pending') == $status ? 'selected' : '' }}>{{ ucfirst($status) }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-12 mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea name="notes" id="notes" class="form-control" rows="3">{{ old('notes') }}</textarea>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>Order Items</h5>
                <button type="button" class="btn btn-success btn-sm" onclick="addItem()">+ Add Item</button>
            </div>
            <div class="card-body" id="items-container">
                @php
                    $oldItems = old('items', [['material_id' => '', 'weight' => '', 'quantity' => '', 'rate' => '']]);
                @endphp

                @foreach ($oldItems as $index => $item)
                    <div class="item-row border rounded p-3 mb-3" data-index="{{ $index }}">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label">Material *</label>
                                <select name="items[{{ $index }}][material_id]" class="form-select material-select" required>
                                    <option value="">Select Material</option>
                                    @foreach($materials as $material)
                                        <option value="{{ $material->id }}" {{ $item['material_id'] == $material->id ? 'selected' : '' }}>{{ $material->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Weight (kg) *</label>
                                <input type="number" step="0.001" min="0" name="items[{{ $index }}][weight]" class="form-control weight-input" value="{{ $item['weight'] }}" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Quantity *</label>
                                <input type="number" min="1" name="items[{{ $index }}][quantity]" class="form-control quantity-input" value="{{ $item['quantity'] }}" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Rate (₹) *</label>
                                <input type="number" step="0.01" min="0" name="items[{{ $index }}][rate]" class="form-control rate-input" value="{{ $item['rate'] }}" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Subtotal (₹)</label>
                                <input type="text" class="form-control subtotal-output" readonly>
                            </div>
                            <div class="col-md-3 mt-2">
                                <label class="form-label">GST Amount (₹)</label>
                                <input type="text" class="form-control gst-output" readonly>
                            </div>
                            <div class="col-md-3 mt-2">
                                <label class="form-label">Total (₹)</label>
                                <input type="text" class="form-control total-output" readonly>
                            </div>
                            <div class="col-md-1 mt-2">
                                <button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">Remove</button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-md-4">
                        <label>Total Amount</label>
                        <input type="text" id="total_amount_display" class="form-control" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>GST Amount</label>
                        <input type="text" id="gst_amount_display" class="form-control" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>Final Amount</label>
                        <input type="text" id="final_amount_display" class="form-control" readonly>
                    </div>
                </div>
                <input type="hidden" id="total_amount" name="total_amount">
                <input type="hidden" id="gst_amount" name="gst_amount">
                <input type="hidden" id="final_amount" name="final_amount">
            </div>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Purchase Order</button>
    </form>
</div>

<script>
    let itemIndex = {{ count($oldItems) }};

    function addItem() {
        const container = document.getElementById('items-container');
        const materialsOptions = `@foreach($materials as $material)
            <option value="{{ $material->id }}">{{ $material->name }}</option>
        @endforeach`;

        const html = `
        <div class="item-row border rounded p-3 mb-3" data-index="${itemIndex}">
            <div class="row g-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Material *</label>
                    <select name="items[${itemIndex}][material_id]" class="form-select material-select" required>
                        <option value="">Select Material</option>
                        ${materialsOptions}
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Weight (kg) *</label>
                    <input type="number" step="0.001" min="0" name="items[${itemIndex}][weight]" class="form-control weight-input" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Quantity *</label>
                    <input type="number" min="1" name="items[${itemIndex}][quantity]" class="form-control quantity-input" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Rate (₹) *</label>
                    <input type="number" step="0.01" min="0" name="items[${itemIndex}][rate]" class="form-control rate-input" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Subtotal (₹)</label>
                    <input type="text" class="form-control subtotal-output" readonly>
                </div>
                <div class="col-md-3 mt-2">
                    <label class="form-label">GST Amount (₹)</label>
                    <input type="text" class="form-control gst-output" readonly>
                </div>
                <div class="col-md-3 mt-2">
                    <label class="form-label">Total (₹)</label>
                    <input type="text" class="form-control total-output" readonly>
                </div>
                <div class="col-md-1 mt-2">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeItem(this)">Remove</button>
                </div>
            </div>
        </div>`;
        container.insertAdjacentHTML('beforeend', html);
        itemIndex++;
        attachListeners();
    }

    function removeItem(button) {
        button.closest('.item-row').remove();
        calculateSummary();
    }

    function attachListeners() {
        document.querySelectorAll('.weight-input, .quantity-input, .rate-input').forEach(input => {
            input.removeEventListener('input', calculateRow);
            input.addEventListener('input', calculateRow);
        });
    }

    function calculateRow(event) {
        const row = event.target.closest('.item-row');
        const weight = parseFloat(row.querySelector('.weight-input').value) || 0;
        const quantity = parseInt(row.querySelector('.quantity-input').value) || 0;
        const rate = parseFloat(row.querySelector('.rate-input').value) || 0;

        const subtotal = weight * quantity * rate;
        const gst = subtotal * 0.18;
        const total = subtotal + gst;

        row.querySelector('.subtotal-output').value = subtotal.toFixed(2);
        row.querySelector('.gst-output').value = gst.toFixed(2);
        row.querySelector('.total-output').value = total.toFixed(2);

        calculateSummary();
    }

    function calculateSummary() {
        let totalAmount = 0;
        let gstAmount = 0;

        document.querySelectorAll('.item-row').forEach(row => {
            totalAmount += parseFloat(row.querySelector('.subtotal-output').value) || 0;
            gstAmount += parseFloat(row.querySelector('.gst-output').value) || 0;
        });

        const finalAmount = totalAmount + gstAmount;

        document.getElementById('total_amount_display').value = totalAmount.toFixed(2);
        document.getElementById('gst_amount_display').value = gstAmount.toFixed(2);
        document.getElementById('final_amount_display').value = finalAmount.toFixed(2);

        document.getElementById('total_amount').value = totalAmount.toFixed(2);
        document.getElementById('gst_amount').value = gstAmount.toFixed(2);
        document.getElementById('final_amount').value = finalAmount.toFixed(2);
    }

    document.addEventListener('DOMContentLoaded', () => {
        attachListeners();
        calculateSummary();
    });
</script>
@endsection
