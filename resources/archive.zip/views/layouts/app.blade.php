<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') - Inventory Pro</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* CSS Custom Properties - Centralized Design System */
        :root {
            /* Brand Colors */
            --primary-blue: #4A90E2;
            --light-blue: #E8F4FD;
            --medium-blue: #B3D9F7;
            --dark-blue: #1976D2;
            --accent-blue: #64B5F6;
            
            /* Neutral Colors */
            --text-dark: #2C3E50;
            --text-light: #6C757D;
            --white: #FFFFFF;
            --light-gray: #F5F7FA;
            --border-light: #E9ECEF;
            
            /* Status Colors */
            --success: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            
            /* Gradients */
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-blue: linear-gradient(135deg, var(--primary-blue) 0%, var(--dark-blue) 100%);
            --gradient-bg: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            
            /* Shadows */
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 15px rgba(74, 144, 226, 0.1);
            --shadow-lg: 0 8px 25px rgba(74, 144, 226, 0.15);
            --shadow-hover: 0 6px 20px rgba(74, 144, 226, 0.4);
            
            /* Spacing & Sizing */
            --border-radius: 12px;
            --border-radius-lg: 16px;
            --border-radius-xl: 20px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --transition-fast: all 0.3s ease;
        }

        /* Base Styles */
        *,
        *::before,
        *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--gradient-bg);
            color: var(--text-dark);
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            min-height: 100vh;
            font-size: 14px;
        }

        /* Glass Morphism Utility */
        .glass-effect {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* Navigation Bar */
        .navbar {
            background: var(--gradient-blue) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 20px rgba(74, 144, 226, 0.3);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--white) !important;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
        }

        .navbar-brand:hover {
            transform: scale(1.05);
        }

        .navbar-brand i {
            color: var(--light-blue);
            margin-right: 10px;
            font-size: 1.3rem;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            transition: var(--transition-fast);
            padding: 8px 16px !important;
            border-radius: 6px;
        }

        .nav-link:hover {
            color: var(--white) !important;
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }

        /* Dropdown Improvements */
        .dropdown-menu {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(74, 144, 226, 0.2);
            box-shadow: var(--shadow-lg);
            border-radius: var(--border-radius);
            padding: 8px 0;
            margin-top: 8px;
        }

        .dropdown-item {
            color: var(--text-dark);
            transition: var(--transition-fast);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 8px;
        }

        .dropdown-item:hover {
            background: var(--light-blue);
            color: var(--dark-blue);
            transform: translateX(4px);
        }

        /* Sidebar Optimization */
        .sidebar {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1px solid var(--border-light);
            min-height: calc(100vh - 70px);
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 70px;
        }

        .sidebar .nav-link {
            color: var(--text-dark) !important;
            padding: 14px 20px;
            margin: 6px 16px;
            border-radius: var(--border-radius);
            font-weight: 500;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        /* Hover Effect with Pseudo Element */
        .sidebar .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: var(--gradient-blue);
            transition: left 0.3s ease;
            z-index: -1;
        }

        .sidebar .nav-link:hover::before,
        .sidebar .nav-link.active::before {
            left: 0;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: var(--white) !important;
            transform: translateX(8px);
            box-shadow: var(--shadow-md);
        }

        .sidebar .nav-link i {
            width: 24px;
            margin-right: 12px;
            color: var(--primary-blue);
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        .sidebar .nav-link:hover i,
        .sidebar .nav-link.active i {
            color: var(--white);
        }

        /* Welcome Section */
        .welcome-section {
            background: var(--gradient-primary);
            color: var(--white);
            padding: 40px 30px;
            border-radius: var(--border-radius-xl);
            position: relative;
            overflow: hidden;
            margin-bottom: 30px;
        }

        .welcome-section::before {
            content: '';
            position: absolute;
            inset: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 20"><defs><radialGradient id="a" cx="50%" cy="0%" r="100%"><stop offset="0%" stop-color="rgba(255,255,255,.1)"/><stop offset="100%" stop-color="rgba(255,255,255,0)"/></radialGradient></defs><rect width="100" height="20" fill="url(%23a)"/></svg>');
            opacity: 0.3;
        }

        .welcome-content {
            position: relative;
            z-index: 2;
        }

        .welcome-title {
            font-size: clamp(1.5rem, 4vw, 2.2rem);
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .welcome-subtitle {
            font-size: 1.1rem;
            font-weight: 400;
            opacity: 0.9;
            margin-bottom: 0;
        }

        /* Stats Cards with Enhanced Performance */
        .stats-card {
            background: var(--white);
            border-radius: var(--border-radius-lg);
            padding: 24px;
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            will-change: transform;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stats-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-blue);
        }

        /* Stats Card Variants */
        .stats-card.users::before { background: linear-gradient(135deg, #3B82F6 0%, #1E40AF 100%); }
        .stats-card.vendors::before { background: linear-gradient(135deg, #10B981 0%, #047857 100%); }
        .stats-card.inventory::before { background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%); }
        .stats-card.orders::before { background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); }

        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 8px;
            line-height: 1;
        }

        .stats-label {
            font-size: 1rem;
            font-weight: 500;
            color: var(--text-light);
            margin-bottom: 0;
        }

        .stats-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 2rem;
            opacity: 0.3;
        }

        .stats-card.users .stats-icon { color: #3B82F6; }
        .stats-card.vendors .stats-icon { color: #10B981; }
        .stats-card.inventory .stats-icon { color: #F59E0B; }
        .stats-card.orders .stats-icon { color: #EF4444; }

        /* Main Content */
        main {
            background: transparent;
            min-height: calc(100vh - 70px);
            padding: 20px;
        }

        /* Card Components */
        .card {
            border: none;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            overflow: hidden;
            will-change: transform;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--medium-blue) 100%);
            border-bottom: 2px solid var(--primary-blue);
            color: var(--text-dark);
            font-weight: 600;
            padding: 20px;
            position: relative;
        }

        .card-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--gradient-blue);
        }

        .card-body {
            padding: 24px;
        }

        /* Button System */
        .btn {
            border-radius: 10px;
            font-weight: 500;
            transition: var(--transition);
            border: none;
            padding: 10px 20px;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn:hover::before {
            width: 300px;
            height: 300px;
        }

        .btn-primary {
            background: var(--gradient-blue);
            color: var(--white);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }

        .btn-outline-primary {
            color: var(--primary-blue);
            border: 2px solid var(--primary-blue);
            background: transparent;
        }

        .btn-outline-primary:hover {
            background: var(--primary-blue);
            color: var(--white);
            transform: translateY(-2px);
        }

        /* Alert System */
        .alert {
            border: none;
            border-radius: var(--border-radius);
            padding: 16px 20px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }

        .alert-info {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-blue);
            border-left: 4px solid var(--primary-blue);
        }

        /* Table System */
        .table {
            background: rgba(255, 255, 255, 0.95);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow-md);
            border: none;
        }

        .table thead th {
            background: var(--gradient-blue);
            color: var(--white);
            border: none;
            font-weight: 600;
            padding: 16px;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }

        .table tbody tr {
            transition: var(--transition-fast);
            border: none;
        }

        .table tbody tr:hover {
            background: var(--light-blue);
            transform: scale(1.01);
        }

        .table tbody td {
            padding: 16px;
            border: none;
            border-bottom: 1px solid var(--border-light);
        }

        /* Form Controls */
        .form-control,
        .form-select {
            border: 2px solid var(--border-light);
            border-radius: 10px;
            padding: 12px 16px;
            transition: var(--transition-fast);
            background: rgba(255, 255, 255, 0.9);
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.15);
            background: var(--white);
        }

        /* Badge System */
        .badge {
            border-radius: 20px;
            padding: 6px 12px;
            font-weight: 500;
            font-size: 0.75rem;
        }

        /* Animation Classes */
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        .slide-in-left {
            animation: slideInLeft 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* Utility Classes */
        .text-gradient {
            background: var(--gradient-blue);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                background: rgba(255, 255, 255, 0.95);
                position: relative;
                top: 0;
                min-height: auto;
            }
            
            main {
                padding: 15px 10px;
            }

            .card,
            .stats-card {
                margin-bottom: 20px;
            }
        }

        @media (max-width: 576px) {
            .navbar-brand {
                font-size: 1.3rem;
            }
            
            .sidebar .nav-link {
                padding: 12px 16px;
                margin: 4px 12px;
            }
        }

        /* Performance Optimizations */
        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        /* Dark mode support preparation */
        @media (prefers-color-scheme: dark) {
            /* Future dark mode styles can be added here */
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ route('dashboard') }}">
                <i class="fas fa-cubes"></i> Inventory Pro
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> {{ Auth::user()->name }} <span class="badge bg-light text-dark ms-1">{{ Auth::user()->getRoleDisplayName() }}</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="{{ route('profile.edit') }}">
                                <i class="fas fa-user-edit me-2"></i>My Profile
                            </a></li>
                            <li><a class="dropdown-item" href="#">
                                <i class="fas fa-cog me-2"></i>Settings
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                               <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </button>
                            </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 d-md-block sidebar slide-in-left">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="{{ route('dashboard') }}">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        
                        @if(Auth::user()->isAdmin())
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('admin.users') }}">
                                    <i class="fas fa-users-cog"></i> User Management
                                </a>
                            </li>
                        @endif 
                        
                        @if(Auth::user()->isAdmin() || Auth::user()->isPurchaseTeam())
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('materials.index') }}">
                                    <i class="fas fa-cube"></i> Materials
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('vendors.index') }}">
                                    <i class="fas fa-truck"></i> Vendor Management
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('purchase-orders.index') }}">
                                    <i class="fas fa-shopping-cart"></i> Purchase Orders
                                </a>
                            </li>
                        @endif
                        
                        @if(Auth::user()->isAdmin() || Auth::user()->isInventoryManager())
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('inventory.index') }}">
                                    <i class="fas fa-boxes"></i> Inventory Control
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('barcode.dashboard') }}">
                                   🎯 Barcode Management
                                </a>
                            </li>
                        @endif
                        
                        <li class="nav-item">
                             <a class="nav-link" href="{{ route('reports.index') }}">
                                <i class="fas fa-file-alt"></i> Reports &amp; Analytics
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 fade-in-up">
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
                
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>{{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif
                
                @yield('content')
                
                <!-- Default Dashboard Content (when no specific content is provided) -->
                @if(!trim($__env->yieldContent('content')))
                <!-- Welcome Section -->
                <div class="welcome-section">
                    <div class="welcome-content text-center">
                        <h1 class="welcome-title">
                            <i class="fas fa-hand-wave me-3"></i>
                            Welcome back, {{ Auth::user()->name }}!
                        </h1>
                        <p class="welcome-subtitle">
                            Ready to manage your inventory efficiently? Your {{ Auth::user()->getRoleDisplayName() }} dashboard is at your service.
                        </p>
                    </div>
                </div>

                <!-- Dashboard Stats -->
                <div class="row g-4 mb-4">
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <div class="stats-card users">
                            <div class="stats-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stats-number">{{ $totalUsers ?? 0 }}</div>
                            <div class="stats-label">Total Users</div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <div class="stats-card vendors">
                            <div class="stats-icon">
                                <i class="fas fa-truck"></i>
                            </div>
                            <div class="stats-number">{{ $totalVendors ?? 0 }}</div>
                            <div class="stats-label">Total Vendors</div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <div class="stats-card inventory">
                            <div class="stats-icon">
                                <i class="fas fa-boxes"></i>
                            </div>
                            <div class="stats-number">{{ $totalItems ?? 0 }}</div>
                            <div class="stats-label">Inventory Items</div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <div class="stats-card orders">
                            <div class="stats-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="stats-number">{{ $totalOrders ?? 0 }}</div>
                            <div class="stats-label">Purchase Orders</div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    @if(Auth::user()->isAdmin())
                                    <div class="col-md-6">
                                        <a href="{{ route('admin.users') }}" class="btn btn-primary w-100">
                                            <i class="fas fa-user-plus me-2"></i>Manage Users
                                        </a>
                                    </div>
                                    @endif
                                    
                                    @if(Auth::user()->isAdmin() || Auth::user()->isPurchaseTeam())
                                    <div class="col-md-6">
                                        <a href="{{ route('purchase-orders.index') }}" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-plus me-2"></i>Create Purchase Order
                                        </a>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="{{ route('vendors.index') }}" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-truck me-2"></i>Add Vendor
                                        </a>
                                    </div>
                                    @endif
                                    
                                    @if(Auth::user()->isAdmin() || Auth::user()->isInventoryManager())
                                    <div class="col-md-6">
                                        <a href="{{ route('inventory.items.index') }}" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-box me-2"></i>Add Inventory Item
                                        </a>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Recent Activity</h5>
                            </div>
                            <div class="card-body">
                                <div class="text-center text-muted">
                                    <i class="fas fa-chart-line fa-3x mb-3 opacity-25"></i>
                                    <p>Recent activities will appear here</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </main>
        </div>
    </div>
   
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Tailwind CSS CDN (Play CDN - development use only) -->
<!--<script src="https://cdn.tailwindcss.com"></script> -->
    <script>
        // Enhanced navigation active state management
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname;
            const navLinks = document.querySelectorAll('.sidebar .nav-link');
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                const href = link.getAttribute('href');
                if (href && (href === currentPath || currentPath.startsWith(href + '/'))) {
                    link.classList.add('active');
                }
            });
        });
        
        // Enhanced alert auto-hide with fade effect
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert-dismissible');
            alerts.forEach(alert => {
                if (alert) {
                    alert.style.transition = 'opacity 0.5s ease-out';
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        const bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    }, 500);
                }
            });
        }, 5000);

        // Add smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

       document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submitBtn && submitBtn.tagName === 'BUTTON') {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
        } else if (submitBtn && submitBtn.tagName === 'INPUT') {
            submitBtn.value = 'Processing...';
        }
        submitBtn.disabled = true;
    });

        });
    </script>
</body>
</html>