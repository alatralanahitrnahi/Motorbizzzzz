@extends('layouts.app')
@section('title', 'Purchase Order Details')
@section('content')
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Purchase Order Details</h3>
        </div>
        <div class="card-body">
            <p><strong>Purchase ID:</strong> {{ $purchaseOrder->purchase_id }}</p>
            <p><strong>Supplier Name:</strong> {{ $purchaseOrder->supplier_name }}</p>
            <p><strong>Supplier Contact:</strong> {{ $purchaseOrder->supplier_contact ?? 'N/A' }}</p>
            <p><strong>Order Date:</strong> {{ \Carbon\Carbon::parse($purchaseOrder->order_date)->format('M d, Y') }}</p>
            <p><strong>Expected Delivery:</strong> 
                {{ $purchaseOrder->expected_delivery ? \Carbon\Carbon::parse($purchaseOrder->expected_delivery)->format('M d, Y') : 'N/A' }}
            </p>
            <p><strong>Payment Mode:</strong> {{ ucfirst($purchaseOrder->payment_mode) }}</p>
            <p><strong>Credit Days:</strong> {{ $purchaseOrder->credit_days ?? 'N/A' }}</p>
            <p><strong>Total Amount:</strong> ${{ number_format($purchaseOrder->total_amount, 2) }}</p>
            <p><strong>GST Amount:</strong> ${{ number_format($purchaseOrder->gst_amount, 2) }}</p>
            <p><strong>Final Amount:</strong> ${{ number_format($purchaseOrder->final_amount, 2) }}</p>
            <p><strong>Status:</strong> 
                <span class="badge bg-{{ 
                    $purchaseOrder->status == 'approved' ? 'success' :
                    ($purchaseOrder->status == 'pending' ? 'warning' :
                    ($purchaseOrder->status == 'received' ? 'info' : 'primary')) 
                }}">{{ ucfirst($purchaseOrder->status) }}</span>
            </p>
            @if($purchaseOrder->notes)
                <p><strong>Notes:</strong><br>{{ $purchaseOrder->notes }}</p>
            @endif
            <p><strong>Created At:</strong> {{ $purchaseOrder->created_at->format('M d, Y h:i A') }}</p>
            <p><strong>Updated At:</strong> {{ $purchaseOrder->updated_at->format('M d, Y h:i A') }}</p>
        </div>
    </div>
</div>
@endsection
