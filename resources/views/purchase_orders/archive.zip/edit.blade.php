@extends('layouts.app')
@section('title', 'Edit Purchase Order')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Edit Purchase Order</h2>
        <a href="{{ route('purchase-orders.show', $purchaseOrder) }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Details
        </a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <form action="{{ route('purchase-orders.update', $purchaseOrder) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="card">
                    <div class="card-header">
                        <h5>Purchase Order Details</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>PO Number *</label>
                                <input type="text" name="po_number" class="form-control" value="{{ old('po_number', $purchaseOrder->po_number) }}" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Primary Vendor *</label>
                                <select name="vendor_id" class="form-control vendor-select" required>
                                    <option value="">Select Vendor</option>
                                    @foreach($vendors as $vendor)
                                        <option value="{{ $vendor->id }}" {{ old('vendor_id', $purchaseOrder->vendor_id) == $vendor->id ? 'selected' : '' }}>
                                            {{ $vendor->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="pending" {{ old('status', $purchaseOrder->status) == 'pending' ? 'selected' : '' }}>Pending</option>
                                    <option value="approved" {{ old('status', $purchaseOrder->status) == 'approved' ? 'selected' : '' }}>Approved</option>
                                    <option value="ordered" {{ old('status', $purchaseOrder->status) == 'ordered' ? 'selected' : '' }}>Ordered</option>
                                    <option value="received" {{ old('status', $purchaseOrder->status) == 'received' ? 'selected' : '' }}>Received</option>
                                    <option value="cancelled" {{ old('status', $purchaseOrder->status) == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                                </select>
                            </div>
                        </div>

                        <!-- New Fields: Delivery Date and Shipping Cost -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Delivery Date</label>
                                <input type="date" name="delivery_date" class="form-control" value="{{ old('delivery_date', optional($purchaseOrder->delivery_date)->format('Y-m-d')) }}">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Shipping Cost ($)</label>
                                <input type="number" name="shipping_cost" class="form-control" step="0.01" min="0" value="{{ old('shipping_cost', $purchaseOrder->shipping_cost ?? 0) }}">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label>Notes</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="Add any additional notes or comments...">{{ old('notes', $purchaseOrder->notes) }}</textarea>
                        </div>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Items</h5>
                        <small class="text-muted">{{ count($purchaseOrder->purchaseOrderItems) }} item(s)</small>
                    </div>
                    <div class="card-body">
                        @foreach ($purchaseOrder->purchaseOrderItems as $i => $item)
                            <div class="border p-3 mb-3 item-row">
                                <input type="hidden" name="items[{{ $i }}][id]" value="{{ $item->id }}">

                                <div class="row">
                                    <div class="col-md-8 mb-2">
                                        <label>Item Name *</label>
                                        <input type="text" name="items[{{ $i }}][item_name]" class="form-control item-name" value="{{ old("items.$i.item_name", $item->item_name) }}" required>
                                    </div>
                                </div>

                                <div class="mb-2">
                                    <label>Description</label>
                                    <input type="text" name="items[{{ $i }}][description]" class="form-control" value="{{ old("items.$i.description", $item->description) }}" placeholder="Additional item details...">
                                </div>

                                <div class="row">
                                    <div class="col-md-4 mb-2">
                                        <label>Quantity *</label>
                                        <input type="number" name="items[{{ $i }}][quantity]" class="form-control quantity" value="{{ old("items.$i.quantity", $item->quantity) }}" required min="1">
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <label>Unit Price *</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">$</span>
                                            </div>
                                            <input type="number" step="0.01" name="items[{{ $i }}][unit_price]" class="form-control unit-price" value="{{ old("items.$i.unit_price", $item->unit_price) }}" required min="0.01">
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <label>Subtotal</label>
                                        <div class="form-control-plaintext">
                                            <strong>$<span class="subtotal">{{ number_format($item->quantity * $item->unit_price, 2) }}</span></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                        <div class="border-top pt-3 mt-3">
                            <div class="row">
                                <div class="col-md-8"></div>
                                <div class="col-md-4">
                                    <div class="bg-primary text-white p-3 rounded text-center">
                                        <h6 class="mb-1">Total Price</h6>
                                        <h4 class="mb-0">$<span id="total-amount">{{ number_format($purchaseOrder->purchaseOrderItems->sum(function($item) { return $item->quantity * $item->unit_price; }), 2) }}</span></h4>
                                        <p class="mt-2">+ Shipping: $<span id="shipping-cost">{{ number_format($purchaseOrder->shipping_cost ?? 0, 2) }}</span></p>
                                        <h5 class="mt-3">Grand Total: $<span id="grand-total"></span></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="{{ route('purchase-orders.show', $purchaseOrder) }}" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Update Purchase Order
                    </button>
                </div>
            </form>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5>Current Vendor</h5>
                </div>
                <div class="card-body" id="vendor-preview">
                    <p><strong>Name:</strong> {{ $purchaseOrder->vendor->name }}</p>
                    @if($purchaseOrder->vendor->email)
                        <p><strong>Email:</strong> {{ $purchaseOrder->vendor->email }}</p>
                    @endif
                    @if($purchaseOrder->vendor->phone)
                        <p><strong>Phone:</strong> {{ $purchaseOrder->vendor->phone }}</p>
                    @endif
                    @if($purchaseOrder->vendor->address)
                        <p><strong>Address:</strong><br>{{ $purchaseOrder->vendor->address }}</p>
                    @endif
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">
                    <h5>PO Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>PO #:</strong> {{ $purchaseOrder->po_number }}</p>
                    <p><strong>Status:</strong> 
                        <span class="badge badge-{{ $purchaseOrder->status == 'approved' ? 'success' : ($purchaseOrder->status == 'pending' ? 'warning' : 'secondary') }}">
                            {{ ucfirst($purchaseOrder->status) }}
                        </span>
                    </p>
                    <p><strong>Items:</strong> {{ count($purchaseOrder->purchaseOrderItems) }}</p>
                </div>
            </div>

            <div class="card mt-3 border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0">Danger Zone</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted small">Once you delete a purchase order, there is no going back. Please be certain.</p>
                    <form action="{{ route('purchase-orders.destroy', $purchaseOrder) }}" method="POST"
                        onsubmit="return confirm('Are you sure you want to delete this purchase order? This action cannot be undone.');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-trash"></i> Delete Purchase Order
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    function calculateTotal() {
        let total = 0;
        document.querySelectorAll('.item-row').forEach(function(row) {
            const quantity = parseFloat(row.querySelector('.quantity').value) || 0;
            const unitPrice = parseFloat(row.querySelector('.unit-price').value) || 0;
            const subtotal = quantity * unitPrice;

            row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
            total += subtotal;
        });

        const shippingInput = document.querySelector('input[name="shipping_cost"]');
        const shipping = parseFloat(shippingInput?.value) || 0;

        document.getElementById('total-amount').textContent = total.toFixed(2);
        document.getElementById('shipping-cost').textContent = shipping.toFixed(2);
        document.getElementById('grand-total').textContent = (total + shipping).toFixed(2);
    }

    document.querySelectorAll('.quantity, .unit-price').forEach(input => {
        input.addEventListener('input', calculateTotal);
    });

    const shippingInput = document.querySelector('input[name="shipping_cost"]');
    if(shippingInput) {
        shippingInput.addEventListener('input', calculateTotal);
    }

    calculateTotal();
});
</script>
@endsection
