@extends('layouts.app')
@section('title', 'Create Purchase Order')
@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Create Purchase Order</h2>
        <a href="{{ route('purchase_orders.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form action="{{ route('purchase_orders.store') }}" method="POST" id="poForm">
        @csrf
        <div class="row">
            <div class="col-md-8">
                <!-- PO Details -->
                <div class="card mb-3">
                    <div class="card-header">
                        <h5>Purchase Order Details</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
           
                            <div class="col-md-6">
                                <label for="vendor_id" class="form-label">Vendor *</label>
                                <select name="vendor_id" id="vendor_id" class="form-select @error('vendor_id') is-invalid @enderror" required>
                                    <option value="">Select Vendor</option>
                                    @foreach($vendors as $vendor)
                                        <option value="{{ $vendor->id }}" {{ old('vendor_id') == $vendor->id ? 'selected' : '' }}>
                                            {{ $vendor->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('vendor_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="po_date" class="form-label">PO Date *</label>
                                <input type="date" name="po_date" id="po_date" class="form-control @error('po_date') is-invalid @enderror" value="{{ old('po_date', date('Y-m-d')) }}" required>
                                @error('po_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="mt-3">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea name="notes" id="notes" class="form-control @error('notes') is-invalid @enderror" rows="3">{{ old('notes') }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Items Section -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Items</h5>
                        <button type="button" class="btn btn-sm btn-success" onclick="addItem()">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    <div class="card-body" id="items-container">
                        <!-- First item row and old input restoration (same as your original logic) -->
                        @php $itemIndex = 0; @endphp
                        @foreach(old('items', [['item_name' => '', 'description' => '', 'quantity' => '', 'unit_price' => '']]) as $index => $item)
                            <div class="item-row border rounded p-3 mb-3">
                                <div class="row">
                                    <div class="col-md-3">
                                        <label class="form-label">Item Name *</label>
                                        <input type="text" name="items[{{ $index }}][item_name]" class="form-control" value="{{ $item['item_name'] }}" required>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Description</label>
                                        <input type="text" name="items[{{ $index }}][description]" class="form-control" value="{{ $item['description'] }}">
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Quantity *</label>
                                        <input type="number" name="items[{{ $index }}][quantity]" class="form-control quantity" min="1" value="{{ $item['quantity'] }}" required>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Unit Price *</label>
                                        <input type="number" name="items[{{ $index }}][unit_price]" class="form-control unit-price" step="0.01" min="0" value="{{ $item['unit_price'] }}" required>
                                    </div>
           
        <div class="col-md-2">
            <label class="form-label">Net Price</label>
            <input type="text" class="form-control net-price" readonly>
        </div>
                                    <div class="col-md-2">
                                        <label class="form-label">Total</label>
                                        <input type="text" class="form-control item-total" readonly>
                                        <button type="button" class="btn btn-sm btn-danger mt-1" onclick="removeItem(this)">Remove</button>
                                    </div>
                                </div>
                            </div>
                            @php $itemIndex = $index + 1; @endphp
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Summary Section -->
                <div class="card">
                    <div class="card-header">
                        <h5>Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <strong>Total Amount:</strong>
                            <strong id="grand-total">$0.00</strong>
                        </div>
                        <input type="hidden" name="total_quantity" id="total-quantity" value="0">
                        <input type="hidden" name="total_amount" id="total-amount" value="0.00">
                        <hr>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> Create Purchase Order
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
let itemIndex = {{ $itemIndex }};

function addItem() {
    const container = document.getElementById('items-container');
    const newItem = `
        <div class="item-row border rounded p-3 mb-3">
            <div class="row gy-2">
                <div class="col-md-3">
                    <label class="form-label">Item Name *</label>
                    <input type="text" name="items[${itemIndex}][item_name]" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Description</label>
                    <input type="text" name="items[${itemIndex}][description]" class="form-control">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Quantity *</label>
                    <input type="number" name="items[${itemIndex}][quantity]" class="form-control quantity" min="1" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Unit Price *</label>
                    <input type="number" name="items[${itemIndex}][unit_price]" class="form-control unit-price" step="0.01" min="0" required>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Total</label>
                    <input type="text" class="form-control item-total" readonly>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Net Price</label>
                    <input type="text" class="form-control net-price" readonly>
                    <button type="button" class="btn btn-sm btn-danger mt-1" onclick="removeItem(this)">Remove</button>
                </div>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', newItem);
    itemIndex++;
    calculateTotal();
}


function removeItem(button) {
    if (document.querySelectorAll('.item-row').length > 1) {
        button.closest('.item-row').remove();
        calculateTotal();
    } else {
        alert('At least one item is required.');
    }
}

function calculateTotal() {
    let grandTotal = 0;
    let grandQuantity = 0;

    document.querySelectorAll('.item-row').forEach(row => {
        const quantity = parseFloat(row.querySelector('.quantity')?.value) || 0;
        const unitPrice = parseFloat(row.querySelector('.unit-price')?.value) || 0;
        const gstPercent = parseFloat(row.querySelector('.gst')?.value) || 0;

        const itemSubtotal = quantity * unitPrice;
        const gstAmount = (itemSubtotal * gstPercent) / 100;
        const netPrice = itemSubtotal + gstAmount;

        // Update calculated fields
        const totalField = row.querySelector('.item-total');
        if (totalField) totalField.value = itemSubtotal.toFixed(2);

        const netField = row.querySelector('.net-price');
        if (netField) netField.value = netPrice.toFixed(2);

        grandTotal += netPrice;
        grandQuantity += quantity;
    });

    document.getElementById('grand-total').textContent = '₹' + grandTotal.toFixed(2);
    document.getElementById('total-amount').value = grandTotal.toFixed(2);
    document.getElementById('total-quantity').value = grandQuantity;
}

document.addEventListener('DOMContentLoaded', function () {
    calculateTotal();

    // Trigger calculation when any related input changes
    document.addEventListener('input', function (e) {
        if (
            e.target.classList.contains('quantity') ||
            e.target.classList.contains('unit-price') ||
            e.target.classList.contains('gst')
        ) {
            calculateTotal();
        }
    });

    // Prevent submitting invalid totals
    document.getElementById('poForm').addEventListener('submit', function (e) {
        const totalQty = parseFloat(document.getElementById('total-quantity').value);
        const totalAmt = parseFloat(document.getElementById('total-amount').value);
        if (totalQty <= 0 || totalAmt <= 0) {
            e.preventDefault();
            alert('Total quantity and amount must be greater than zero.');
        }
    });
});

</script>
@endsection
