@extends('layouts.app')
@section('title', 'Purchase Orders')

@section('content')
<div class="container-fluid">
    {{-- ✅ Success Message --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    {{-- ✅ Page Header --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Purchase Orders</h2>
        <a href="{{ route('purchase-orders.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i> Create PO
        </a>
    </div>

    {{-- ✅ Purchase Orders Table --}}
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>PO Number</th>
                            <th>Vendor</th>
                            <th>Date</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>GST</th> {{-- New --}}
                            <th>Net Total</th> {{-- New --}}
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($orders as $order)
                            <tr>
                                <td>{{ $order->po_number ?? 'N/A' }}</td>
                                <td>{{ $order->vendor->name ?? 'Unknown' }}</td>
                                <td>{{ $order->po_date?->format('M d, Y') ?? 'N/A' }}</td>
                           <td>{{ $order->purchase_order_items_quantity_sum ?? 0 }}</td>
<td>${{ number_format($order->purchase_order_items_total_price_sum ?? 0, 2) }}</td>
<td>${{ number_format($order->purchase_order_items_gst_amount_sum ?? 0, 2) }}</td>
<td>${{ number_format($order->purchase_order_items_net_price_sum ?? 0, 2) }}</td>


                                <td>
                                    <span class="badge bg-{{ match($order->status) {
                                        'approved' => 'success',
                                        'pending' => 'warning',
                                        'received' => 'info',
                                        'cancelled' => 'danger',
                                        default => 'secondary'
                                    } }}">
                                        {{ ucfirst($order->status) }}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('purchase-orders.show', $order) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('purchase-orders.edit', $order) }}" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="{{ route('purchase-orders.destroy', $order) }}" method="POST" onsubmit="return confirm('Delete this PO?');" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="text-center">No purchase orders found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- ✅ Pagination --}}
            <div class="d-flex justify-content-center">
                {{ $orders->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
