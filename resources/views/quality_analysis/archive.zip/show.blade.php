@extends('layouts.app')

@section('title', 'Quality Analysis Details - INVENTORY PRO')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Quality Analysis Details</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('quality-analysis.index') }}">Quality Analysis</a></li>
                    <li class="breadcrumb-item active">Details</li>
                </ol>
            </nav>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('quality-analysis.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
            @if($analysis->quality_status == 'pending')
                <a href="{{ route('quality-analysis.edit', $analysis->id) }}" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit
                </a>
            @endif
            @if($analysis->quality_status == 'approved' && $analysis->barcode)
                <button type="button" class="btn btn-info" onclick="printBarcode()">
                    <i class="fas fa-print"></i> Print Barcode
                </button>
            @endif
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <!-- Main Details Card -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Product Analysis Details</h5>
                    <span class="badge bg-{{ $analysis->status_badge }} fs-6">
                        {{ ucfirst($analysis->quality_status) }}
                    </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">Product Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold">Product Name:</td>
                                    <td>{{ $analysis->product_name }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Category:</td>
                                    <td>{{ $analysis->product_category }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Quantity Received:</td>
                                    <td>{{ $analysis->quantity_received }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Batch Number:</td>
                                    <td>{{ $analysis->batch_number ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Manufacturing Date:</td>
                                    <td>{{ $analysis->manufacturing_date ? $analysis->manufacturing_date->format('M d, Y') : 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Expiry Date:</td>
                                    <td>{{ $analysis->expiry_date ? $analysis->expiry_date->format('M d, Y') : 'N/A' }}</td>
                                </tr>
                                @if($analysis->sku_id)
                                <tr>
                                    <td class="fw-bold">SKU ID:</td>
                                    <td><code>{{ $analysis->sku_id }}</code></td>
                                </tr>
                                @endif
                                @if($analysis->barcode)
                                <tr>
                                    <td class="fw-bold">Barcode:</td>
                                    <td><code>{{ $analysis->barcode }}</code></td>
                                </tr>
                                @endif
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-success mb-3">Quality Parameters</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold">Expected Volumetric Data:</td>
                                    <td>{{ $analysis->expected_volumetric_data }}%</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Actual Volumetric Data:</td>
                                    <td>
                                        @if($analysis->actual_volumetric_data)
                                            {{ $analysis->actual_volumetric_data }}%
                                            @if($analysis->actual_volumetric_data != $analysis->expected_volumetric_data)
                                                <span class="badge bg-warning ms-2">Variance</span>
                                            @else
                                                <span class="badge bg-success ms-2">Match</span>
                                            @endif
                                        @else
                                            <span class="text-muted">Not tested</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Expected Weight:</td>
                                    <td>{{ $analysis->expected_weight }}g</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Actual Weight:</td>
                                    <td>
                                        @if($analysis->actual_weight)
                                            {{ $analysis->actual_weight }}g
                                            @if($analysis->actual_weight != $analysis->expected_weight)
                                                <span class="badge bg-warning ms-2">Variance</span>
                                            @else
                                                <span class="badge bg-success ms-2">Match</span>
                                            @endif
                                        @else
                                            <span class="text-muted">Not tested</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Variance Percentage:</td>
                                    <td>
                                        @if($analysis->actual_weight && $analysis->expected_weight)
                                            @php
                                                $variance = (($analysis->actual_weight - $analysis->expected_weight) / $analysis->expected_weight) * 100;
                                            @endphp
                                            <span class="badge bg-{{ abs($variance) > 5 ? 'danger' : (abs($variance) > 2 ? 'warning' : 'success') }}">
                                                {{ number_format($variance, 2) }}%
                                            </span>
                                        @else
                                            <span class="text-muted">N/A</span>
                                        @endif
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    @if($analysis->other_analysis_parameters)
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="text-info mb-3">Other Analysis Parameters</h6>
                            <div class="bg-light p-3 rounded">
                                {{ $analysis->other_analysis_parameters }}
                            </div>
                        </div>
                    </div>
                    @endif

                    @if($analysis->remarks)
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="text-secondary mb-3">Remarks</h6>
                            <div class="bg-light p-3 rounded">
                                {{ $analysis->remarks }}
                            </div>
                        </div>
                    </div>
                    @endif

                    @if($analysis->quality_status == 'rejected' && $analysis->rejected_reason)
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="text-danger mb-3">Rejection Reason</h6>
                            <div class="bg-danger bg-opacity-10 p-3 rounded border border-danger">
                                {{ $analysis->rejected_reason }}
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Purchase Order Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Purchase Order Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold">PO Number:</td>
                                    <td>
                                        <a href="{{ route('purchase-orders.show', $analysis->purchaseOrder->id) }}" class="text-decoration-none">
                                            {{ $analysis->purchaseOrder->po_number }}
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Vendor:</td>
                                    <td>
                                        {{ $analysis->purchaseOrder->vendor->name ?? 'N/A' }}
                                        @if($analysis->purchaseOrder->vendor->business_name)
                                            <br><small class="text-muted">({{ $analysis->purchaseOrder->vendor->business_name }})</small>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">PO Date:</td>
                                    <td>{{ $analysis->purchaseOrder->created_at->format('M d, Y') }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold">Item Name:</td>
                                    <td>{{ $analysis->purchaseOrderItem->item_name ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Ordered Quantity:</td>
                                    <td>{{ $analysis->purchaseOrderItem->quantity ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Unit Price:</td>
                                    <td>₹{{ number_format($analysis->purchaseOrderItem->unit_price ?? 0, 2) }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Status Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Status Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Current Status</label>
                        <div>
                            <span class="badge bg-{{ $analysis->status_badge }} fs-6">
                                {{ ucfirst($analysis->quality_status) }}
                            </span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Created By</label>
                        <div>{{ $analysis->createdBy->name ?? 'System' }}</div>
                        <small class="text-muted">{{ $analysis->created_at->format('M d, Y \a\t g:i A') }}</small>
                    </div>

                    @if($analysis->approved_by)
                    <div class="mb-3">
                        <label class="form-label">
                            {{ $analysis->quality_status == 'approved' ? 'Approved By' : 'Reviewed By' }}
                        </label>
                        <div>{{ $analysis->approvedBy->name ?? 'N/A' }}</div>
                        <small class="text-muted">{{ $analysis->approved_at ? $analysis->approved_at->format('M d, Y \a\t g:i A') : 'N/A' }}</small>
                    </div>
                    @endif

                    @if($analysis->quality_status == 'pending')
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#approveModal">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                            <i class="fas fa-times"></i> Reject
                        </button>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Barcode Card -->
            @if($analysis->barcode)
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Barcode Information</h5>
                </div>
                <div class="card-body text-center">
                    <div id="barcode-container" class="mb-3">
                        <!-- Barcode will be generated here -->
                    </div>
                    <div class="mt-2">
                        <code>{{ $analysis->barcode }}</code>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="printBarcode()">
                        <i class="fas fa-print"></i> Print Barcode
                    </button>
                </div>
            </div>
            @endif

            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="{{ route('quality-analysis.index') }}" class="btn btn-outline-secondary">
                            <i class="fas fa-list"></i> View All Analysis
                        </a>
                        @if($analysis->quality_status == 'pending')
                        <a href="{{ route('quality-analysis.edit', $analysis->id) }}" class="btn btn-outline-primary">
                            <i class="fas fa-edit"></i> Edit Analysis
                        </a>
                        @endif
                        <a href="{{ route('purchase-orders.show', $analysis->purchaseOrder->id) }}" class="btn btn-outline-info">
                            <i class="fas fa-file-alt"></i> View Purchase Order
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Approve Modal -->
@if($analysis->quality_status == 'pending')
<div class="modal fade" id="approveModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('quality-analysis.approve', $analysis->id) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Approve Quality Analysis</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        Are you sure you want to approve this quality analysis? This action will generate SKU and barcode for the product.
                    </div>
                    <div class="mb-3">
                        <label for="remarks" class="form-label">Approval Remarks (Optional)</label>
                        <textarea name="remarks" id="remarks" class="form-control" rows="3" placeholder="Enter any additional remarks..."></textarea>
                    </div>
                    <input type="hidden" name="approved_items[]" value="{{ $analysis->id }}">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check"></i> Approve
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('quality-analysis.reject', $analysis->id) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Reject Quality Analysis</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        Are you sure you want to reject this quality analysis? Please provide a reason for rejection.
                    </div>
                    <div class="mb-3">
                        <label for="rejected_reason" class="form-label">Rejection Reason <span class="text-danger">*</span></label>
                        <textarea name="rejected_reason" id="rejected_reason" class="form-control" rows="3" placeholder="Enter reason for rejection..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-times"></i> Reject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif

@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>

<script>
$(document).ready(function() {
    // Generate barcode if exists
    @if($analysis->barcode)
    generateBarcode('{{ $analysis->barcode }}');
    @endif
});

function generateBarcode(code) {
    try {
        JsBarcode("#barcode-container", code, {
            format: "CODE128",
            width: 2,
            height: 50,
            displayValue: false,
            margin: 10
        });
    } catch (e) {
        console.error('Error generating barcode:', e);
        $('#barcode-container').html('<div class="text-muted">Unable to generate barcode</div>');
    }
}

function printBarcode() {
    const printContent = `
        <html>
        <head>
            <title>Barcode - {{ $analysis->barcode }}</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    text-align: center; 
                    margin: 20px;
                }
                .barcode-info {
                    margin: 20px 0;
                }
                .product-info {
                    margin: 10px 0;
                    font-size: 14px;
                }
                @media print {
                    body { margin: 0; }
                }
            </style>
            <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
        </head>
        <body>
            <div class="barcode-info">
                <h3>{{ $analysis->product_name }}</h3>
                <div class="product-info">
                    <div>Category: {{ $analysis->product_category }}</div>
                    <div>Batch: {{ $analysis->batch_number ?? 'N/A' }}</div>
                    <div>SKU: {{ $analysis->sku_id ?? 'N/A' }}</div>
                </div>
                <div id="print-barcode"></div>
                <div style="margin-top: 10px;">
                    <code>{{ $analysis->barcode }}</code>
                </div>
            </div>
            <script>
                JsBarcode("#print-barcode", "{{ $analysis->barcode }}", {
                    format: "CODE128",
                    width: 2,
                    height: 60,
                    displayValue: false,
                    margin: 10
                });
                window.onload = function() {
                    window.print();
                    window.onafterprint = function() {
                        window.close();
                    };
                };
            </script>
        </body>
        </html>
    `;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
}
</script>
@endsection