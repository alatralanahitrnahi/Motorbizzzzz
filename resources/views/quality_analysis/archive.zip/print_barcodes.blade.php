@extends('layouts.app')

@section('title', 'Print Barcodes')

@section('content')
<div class="container mt-4">

    @foreach($analyses as $analysis)
        <div class="text-center mb-5 page-break">
            <h2>{{ $analysis->product_name ?? 'Product' }}</h2>
            <p>Category: {{ $analysis->product_category ?? 'N/A' }}</p>
            <p>Batch: {{ $analysis->batch_number ?? 'N/A' }}</p>
            <p>SKU: {{ $analysis->sku_id ?? 'N/A' }}</p>

            <svg class="barcode" data-code="{{ $analysis->barcode }}"></svg>

            <div class="mt-2">
                <code>{{ $analysis->barcode ?? 'N/A' }}</code>
            </div>
        </div>
    @endforeach

</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.barcode').forEach(function (el) {
            const code = el.dataset.code;
            if (code) {
                JsBarcode(el, code, {
                    format: "CODE128",
                    width: 2,
                    height: 60,
                    displayValue: false,
                    margin: 10
                });
            }
        });

        window.print();
        window.onafterprint = function () {
            window.close();
        };
    });
</script>

<style>
    .page-break {
        page-break-after: always;
    }
</style>
@endsection
