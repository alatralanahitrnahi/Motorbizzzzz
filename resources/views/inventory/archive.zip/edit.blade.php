@extends('layouts.app')

@section('title', 'Edit Item')

@section('content')
<div class="container py-4">
    <h2 class="mb-4">Edit Inventory Item</h2>

    <form action="{{ route('inventory.items.update', $item->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" value="{{ $item->name }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Quantity</label>
            <input type="number" name="quantity" value="{{ $item->quantity }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <input type="text" name="category" value="{{ $item->category }}" class="form-control" required>
        </div>

        <button class="btn btn-primary">Update Item</button>
        <a href="{{ route('inventory.items.index') }}" class="btn btn-secondary">Back</a>
    </form>
</div>
@endsection
