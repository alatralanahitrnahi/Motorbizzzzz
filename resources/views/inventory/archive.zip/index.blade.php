@extends('layouts.app')

@section('title', 'Inventory')

@section('content')
    <h1 class="text-2xl font-bold mb-4">Inventory Items</h1>
    <a href="{{ route('inventory.items.create') }}" class="btn btn-primary mb-4">Add New Item</a>

    <table class="min-w-full bg-white">
        <thead>
            <tr>
                <th class="border px-4 py-2">Item Name</th>
                <th class="border px-4 py-2">SKU</th>
                <th class="border px-4 py-2">Quantity</th>
                <th class="border px-4 py-2">Location</th>
                <th class="border px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($inventoryItems as $item)
            <tr>
                <td class="border px-4 py-2">{{ $item->name }}</td>
                <td class="border px-4 py-2">{{ $item->sku }}</td>
                <td class="border px-4 py-2">{{ $item->quantity }}</td>
                <td class="border px-4 py-2">{{ $item->location }}</td>
                <td class="border px-4 py-2">
                    <a href="{{ route('inventory.items.show', $item) }}" class="text-blue-600">View</a> |
                    <a href="{{ route('inventory.items.edit', $item) }}" class="text-yellow-600">Edit</a> |
                    <form action="{{ route('inventory.items.destroy', $item) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button class="text-red-600" onclick="return confirm('Delete this item?')">Delete</button>
                    </form>
                </td>
            </tr>
            @empty
                <tr><td colspan="5">No inventory items found.</td></tr>
            @endforelse
        </tbody>
    </table>
@endsection
