@extends('layouts.app')

@section('title', 'Create Quality Analysis - INVENTORY PRO')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0">Input Product Details (IPD)</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('quality-analysis.index') }}">Quality Analysis</a></li>
                    <li class="breadcrumb-item active">Create</li>
                </ol>
            </nav>
        </div>
        <div class="d-flex align-items-center">
            <div class="badge bg-primary me-2">Quality Analyst</div>
            <a href="{{ route('quality-analysis.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>

   <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Start with Quality Checks</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('quality-analysis.store') }}">
                    @csrf

                    <!-- Step 1: Select Purchase Order -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label for="vendorFilter" class="form-label">Select Vendor</label>
                            <select name="vendor_filter" id="vendorFilter" class="form-select">
                                <option value="">Select from Drop Down</option>
                                @foreach($vendors as $vendor)
                                    <option value="{{ $vendor->id }}">{{ $vendor->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="purchaseOrderSelect" class="form-label">View PO</label>
                            <select name="purchase_order_id" id="purchaseOrderSelect" class="form-select" required>
                                <option value="">Click to view</option>
                                @foreach($purchaseOrders as $po)
                                    <option 
                                        value="{{ $po->id }}" 
                                        data-vendor="{{ $po->vendor->id ?? '' }}"
                                        data-po-number="{{ $po->po_number }}"
                                        data-vendor-name="{{ $po->vendor->name ?? 'N/A' }}"
                                        data-po-date="{{ $po->created_at->format('M d, Y') }}"
                                        data-has-qa="{{ $po->hasQualityAnalysis() ? 'true' : 'false' }}"
                                        {{ isset($purchaseOrder) && $purchaseOrder->id == $po->id ? 'selected' : '' }}
                                    >
                                        {{ $po->po_number }} - {{ $po->vendor->name ?? 'N/A' }}
                                        @if($po->hasQualityAnalysis())
                                            <span class="text-warning">(QA Already Created)</span>
                                        @endif
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <!-- Selected PO Information -->
                    <div id="purchaseOrderInfo" class="alert alert-info" style="display: none;">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>PO Number:</strong> <span id="poNumber"></span><br>
                                <strong>Vendor:</strong> <span id="poVendor"></span>
                            </div>
                            <div class="col-md-6">
                                <strong>Date:</strong> <span id="poDate"></span><br>
                                <strong>Total Items:</strong> <span id="poItemCount"></span>
                            </div>
                        </div>
                    </div>

                    <!-- QA Already Exists Alert -->
                    <div id="qaExistsAlert" class="alert alert-warning" style="display: none;">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <div>
                                <strong>Quality Analysis Already Exists!</strong><br>
                                This purchase order already has a quality analysis created. You cannot create another one.
                                <a href="#" id="viewExistingQA" class="btn btn-sm btn-outline-primary ms-2">View Existing QA</a>
                            </div>
                        </div>
                    </div>

                    <!-- IPD Form -->
                    <div id="ipdForm" style="display: none;">
                        <h6 class="mb-3">Product Details for Quality Analysis</h6>
                        <div id="itemsContainer">
                            <!-- Items will be loaded here -->
                        </div>
                        
                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary" onclick="window.history.back()">
                                <i class="fas fa-arrow-left"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-success" id="submitBtn">
                                <i class="fas fa-check"></i> Create Quality Analysis
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Item Template -->
<template id="itemTemplate">
    <div class="card mb-3 item-card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0">Product: <span class="item-name"></span></h6>
            <span class="badge bg-info">Quantity: <span class="item-quantity"></span></span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-primary mb-3">Input Product Details (IPD)</h6>
                    
                    <div class="mb-3">
                        <label class="form-label">1. Product Name / Category</label>
                        <div class="row">
                            <div class="col-6">
                                <input type="text" name="items[INDEX][product_name]" class="form-control" placeholder="Product Name" required readonly>
                            </div>
                            <div class="col-6">
                                <input type="text" name="items[INDEX][product_category]" class="form-control" placeholder="Category" required readonly>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">2. Expected Volumetric Data of the product</label>
                        <div class="input-group">
                            <input type="number" name="items[INDEX][expected_volumetric_data]" class="form-control" step="0.01" placeholder="0.00" required>
                            <span class="input-group-text">%</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">3. Expected Weight of the product</label>
                        <div class="input-group">
                            <input type="number" name="items[INDEX][expected_weight]" class="form-control" step="0.01" placeholder="0.00" required>
                            <span class="input-group-text">g</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">4. Other Analysis Parameter</label>
                        <textarea name="items[INDEX][other_analysis_parameters]" class="form-control" rows="3" placeholder="Additional parameters..."></textarea>
                    </div>
                </div>

                <div class="col-md-6">
                    <h6 class="text-success mb-3">Quality Check Results</h6>
                    
                    <div class="mb-3">
                        <label class="form-label">Actual Volumetric Data</label>
                        <div class="input-group">
                            <input type="number" name="items[INDEX][actual_volumetric_data]" class="form-control" step="0.01" placeholder="0.00">
                            <span class="input-group-text">%</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Actual Weight</label>
                        <div class="input-group">
                            <input type="number" name="items[INDEX][actual_weight]" class="form-control" step="0.01" placeholder="0.00">
                            <span class="input-group-text">g</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Quantity Received</label>
                        <input type="number" name="items[INDEX][quantity_received]" class="form-control" step="0.01" placeholder="0.00" required readonly>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Manufacturing Date</label>
                                <input type="date" name="items[INDEX][manufacturing_date]" class="form-control">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Expiry Date</label>
                                <input type="date" name="items[INDEX][expiry_date]" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Remarks</label>
                        <textarea name="items[INDEX][remarks]" class="form-control" rows="2" placeholder="Quality check remarks..."></textarea>
                    </div>
                </div>
            </div>
            
            <input type="hidden" name="items[INDEX][purchase_order_item_id]" class="item-id">
        </div>
    </div>
</template>

@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Vendor filter
    $('#vendorFilter').on('change', function () {
        const vendorId = $(this).val();
        const poSelect = $('#purchaseOrderSelect');

        poSelect.find('option').each(function () {
            const optionVendor = $(this).attr('data-vendor');
            const isDefault = $(this).val() === '';
            const shouldShow = !vendorId || optionVendor == vendorId || isDefault;

            $(this).toggle(shouldShow);
        });

        poSelect.val('');
        hideAllSections();
    });

    // PO selection
    $('#purchaseOrderSelect').on('change', function() {
        const poId = $(this).val();
        const selectedOption = $(this).find('option:selected');
        
        if (poId) {
            const hasQA = selectedOption.data('has-qa') === 'true';
            
            // Update PO info
            $('#poNumber').text(selectedOption.data('po-number') || 'N/A');
            $('#poVendor').text(selectedOption.data('vendor-name') || 'N/A');
            $('#poDate').text(selectedOption.data('po-date') || 'N/A');
            $('#purchaseOrderInfo').show();
            
            if (hasQA) {
                // Show warning and disable form
                $('#qaExistsAlert').show();
                $('#ipdForm').hide();
                $('#submitBtn').prop('disabled', true);
                
                // Set up view existing QA link
                $('#viewExistingQA').attr('href', `/quality-analysis/purchase-order/${poId}`);
            } else {
                // Hide warning and enable form
                $('#qaExistsAlert').hide();
                $('#submitBtn').prop('disabled', false);
                loadPurchaseOrderItems(poId);
            }
        } else {
            hideAllSections();
        }
    });

    // Auto-load PO if set on page
    @if(isset($purchaseOrder) && $purchaseOrder)
        loadPurchaseOrderItems({{ $purchaseOrder->id }});
    @endif

    // Form submission validation
    $('form').on('submit', function(e) {
        const selectedOption = $('#purchaseOrderSelect option:selected');
        const hasQA = selectedOption.data('has-qa') === 'true';
        
        if (hasQA) {
            e.preventDefault();
            alert('Cannot create quality analysis. This purchase order already has a quality analysis.');
            return false;
        }
    });
});

function hideAllSections() {
    $('#purchaseOrderInfo').hide();
    $('#qaExistsAlert').hide();
    $('#ipdForm').hide();
}

function loadItems(items) {
    const container = $('#itemsContainer');
    const template = $('#itemTemplate').html();
    container.empty();

    if (!items || items.length === 0) {
        container.html('<div class="alert alert-info">No items to display.</div>');
        return;
    }

    items.forEach((item, index) => {
        let itemHtml = template.replace(/INDEX/g, index);
        const itemCard = $(itemHtml);

        // Basic fields
        const name = item.item_name || item.material_name || 'Unnamed';
        const category = item.material_category || '';

        itemCard.find('.item-name').text(name);
        itemCard.find('.item-category').text(category);
        itemCard.find('.item-quantity').text(item.quantity || '0');
        itemCard.find('.item-id').val(item.id || '');

        // Pre-fill fields
        itemCard.find(`input[name="items[${index}][product_name]"]`).val(name);
        itemCard.find(`input[name="items[${index}][product_category]"]`).val(category);
        itemCard.find(`input[name="items[${index}][quantity_received]"]`).val(item.quantity || '');
        itemCard.find(`input[name="items[${index}][batch_number]"]`).val(item.batch_number || '');
        itemCard.find(`input[name="items[${index}][expiry_date]"]`).val(item.expiry_date || '');
        itemCard.find(`input[name="items[${index}][manufacturing_date]"]`).val(item.manufacturing_date || '');

        // Hidden material ID
        itemCard.find('.item-id').after(`<input type="hidden" name="items[${index}][material_id]" value="${item.material_id || ''}">`);

        container.append(itemCard);
    });
}

// Fetch PO items with batch info
function loadPurchaseOrderItems(poId) {
    $('#itemsContainer').html('<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading items...</div>');

    $.ajax({
        url: `/quality-analysis/purchase-order-items/${poId}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success && Array.isArray(response.items) && response.items.length > 0) {
                $('#poItemCount').text(response.items.length);
                loadItems(response.items);
                $('#ipdForm').show();
            } else {
                $('#itemsContainer').html('<div class="alert alert-warning">No items found for this PO.</div>');
                $('#ipdForm').show();
            }
        },
        error: function(xhr) {
            let errorMessage = 'Error loading PO items.';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            }
            console.error('Error:', xhr.responseText);
            $('#itemsContainer').html(`<div class="alert alert-danger">${errorMessage}</div>`);
            $('#ipdForm').show();
        }
    });
}
</script>
@endsection