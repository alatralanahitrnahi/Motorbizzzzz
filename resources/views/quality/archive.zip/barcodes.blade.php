@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4">Generated Barcodes</h2>

    @if(empty($barcodes))
        <div class="alert alert-warning">
            No barcodes generated.
        </div>
    @else
        <div class="row">
            @foreach($barcodes as $entry)
                <div class="col-md-4 mb-4">
                    <div class="card p-3 text-center shadow-sm">
                        <h5 class="card-title mb-2">{{ $entry['item']->item_name }}</h5>
                        <div class="barcode">
                            {!! $entry['barcode'] !!}
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
