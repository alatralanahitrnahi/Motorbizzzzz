<?php $__env->startSection('title', 'Barcode Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="h3 mb-0">🎯 Barcode Management</h2>
                <div class="btn-group">
                    <a href="<?php echo e(route('barcode.dashboard')); ?>" class="btn btn-info">
                        <i class="fas fa-chart-bar me-1"></i> Dashboard
                    </a>
                  <!--  <a href="<?php echo e(route('barcode.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Generate Barcodes
                    </a>-->
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('barcode.index')); ?>" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Search</label>
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Barcode, Material, Supplier..." 
                                   value="<?php echo e(request('search')); ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">All Status</option>
                                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                                <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                <option value="damaged" <?php echo e(request('status') == 'damaged' ? 'selected' : ''); ?>>Damaged</option>
                                <option value="expired" <?php echo e(request('status') == 'expired' ? 'selected' : ''); ?>>Expired</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Material</label>
                            <select name="material_id" class="form-select">
                                <option value="">All Materials</option>
                                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($material->id); ?>" 
                                            <?php echo e(request('material_id') == $material->id ? 'selected' : ''); ?>>
                                        <?php echo e($material->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Expiry</label>
                            <select name="expiry_filter" class="form-select">
                                <option value="">All Items</option>
                                <option value="expired" <?php echo e(request('expiry_filter') == 'expired' ? 'selected' : ''); ?>>Expired</option>
                                <option value="expiring_soon" <?php echo e(request('expiry_filter') == 'expiring_soon' ? 'selected' : ''); ?>>Expiring Soon</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">&nbsp;</label>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i> Filter
                                </button>
                                <a href="<?php echo e(route('barcode.index')); ?>" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i> Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Barcodes Table -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Barcode List (<?php echo e($barcodes->total()); ?> total)</h5>
                </div>
                <div class="card-body p-0">
                    <?php if($barcodes->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th><input type="checkbox" id="selectAll"></th>
                                        <th>Barcode</th>
                                        <th>Material</th>
                                        <th>Batch</th>
                                        <th>Supplier</th>
                                        <th>Quantity</th>
                                        <th>Expiry</th>
                                        <th>Status</th>
                                        <th>Scans</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="barcode_ids[]" value="<?php echo e($barcode->id); ?>">
                                            </td>
                                            <td>
                                                <div class="fw-bold"><?php echo e($barcode->barcode_number); ?></div>
                                                <small class="text-muted"><?php echo e($barcode->material_code); ?></small>
                                            </td>
                                            <td>
                                                <div><?php echo e($barcode->material_name); ?></div>
                                                <small class="text-muted">Grade: <?php echo e($barcode->quality_grade); ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo e($barcode->batch->batch_number ?? 'N/A'); ?></span>
                                            </td>
                                            <td>  <?php if($barcode->purchaseOrder && $barcode->purchaseOrder->vendor): ?>
                                       <?php echo e($barcode->purchaseOrder->vendor->name); ?> - <?php echo e($barcode->purchaseOrder->vendor->phone); ?>

                                        <?php else: ?>
                                      N/A
                                          <?php endif; ?>
                                           </td>
                                            <td>
                                                <div><?php echo e($barcode->quantity); ?> units</div>
                                                <small class="text-muted"><?php echo e($barcode->weight); ?> kg</small>
                                            </td>
                                            <td>
                                                <?php if($barcode->expiry_date): ?>
                                                    <?php
                                                        $isExpired = $barcode->expiry_date->isPast();
                                                        $isExpiringSoon = $barcode->expiry_date->diffInDays(now()) <= 7;
                                                    ?>
                                                    <div class="<?php echo e($isExpired ? 'text-danger' : ($isExpiringSoon ? 'text-warning' : '')); ?>">
                                                        <?php echo e($barcode->expiry_date->format('d M, Y')); ?>

                                                    </div>
                                                    <?php if($isExpired): ?>
                                                        <small class="text-danger">Expired</small>
                                                    <?php elseif($isExpiringSoon): ?>
                                                        <small class="text-warning">Expiring Soon</small>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted">No expiry</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                    $statusColors = [
                                                        'active' => 'success',
                                                        'inactive' => 'secondary',
                                                        'damaged' => 'danger',
                                                        'expired' => 'warning'
                                                    ];
                                                ?>
                                                <span class="badge bg-<?php echo e($statusColors[$barcode->status] ?? 'secondary'); ?>">
                                                    <?php echo e(ucfirst($barcode->status)); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <div><?php echo e($barcode->print_count ?? 0); ?> prints</div>
                                                <?php if($barcode->last_scanned_at): ?>
                                                    <small class="text-muted">
                                                        Last: <?php echo e($barcode->last_scanned_at->diffForHumans()); ?>

                                                    </small>
                                                <?php else: ?>
                                                    <small class="text-muted">Never scanned</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo e(route('barcode.show', $barcode)); ?>" 
                                                       class="btn btn-outline-primary" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('barcode.batch-print', ['ids' => $barcode->id])); ?>" 
                                                       class="btn btn-outline-success" title="Print">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('barcode.edit', $barcode)); ?>" 
                                                       class="btn btn-outline-warning" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div class="card-footer">
                            <?php echo e($barcodes->withQueryString()->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-barcode fa-3x text-muted mb-3"></i>
                            <h5>No barcodes found</h5>
                            <p class="text-muted">Generate your first barcode to get started.</p>
                            <a href="<?php echo e(route('barcode.create')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus me-1"></i> Generate Barcode
                            </a>
                        </div>
                    <?php endif; ?>
            
        </div>
    </div>

    <!-- Bulk Actions -->
  <!---  <?php if($barcodes->count() > 0): ?>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form id="bulkActionForm" method="POST" action="<?php echo e(route('barcode.bulk-action')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label class="form-label">Bulk Actions</label>
                                    <select name="action" class="form-select" required>
                                        <option value="">Select Action</option>
                                        <option value="activate">Activate Selected</option>
                                        <option value="deactivate">Deactivate Selected</option>
                                        <option value="mark_damaged">Mark as Damaged</option>
                                        <option value="delete">Delete Selected</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-warning" disabled id="bulkActionBtn">
                                        <i class="fas fa-cogs me-1"></i> Apply to Selected
                                    </button>
                                </div>
                                <div class="col-md-6">
                                    <small class="text-muted">
                                        <span id="selectedCount">0</span> items selected
                                    </small>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
           </div>
    <?php endif; ?>
</div> --->

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Select all functionality
    $('#selectAll').change(function() {
        $('input[name="barcode_ids[]"]').prop('checked', this.checked);
        updateBulkActions();
    });

    // Individual checkbox change
    $('input[name="barcode_ids[]"]').change(function() {
        updateBulkActions();
    });

    // Update bulk actions state
    function updateBulkActions() {
        const checkedCount = $('input[name="barcode_ids[]"]:checked').length;
        $('#selectedCount').text(checkedCount);
        $('#bulkActionBtn').prop('disabled', checkedCount === 0);
        
        // Update form with selected IDs
        const selectedIds = [];
        $('input[name="barcode_ids[]"]:checked').each(function() {
            selectedIds.push($(this).val());
        });
        
        // Remove existing hidden inputs
        $('#bulkActionForm input[name="barcode_ids[]"]').remove();
        
        // Add selected IDs as hidden inputs
        selectedIds.forEach(function(id) {
            $('#bulkActionForm').append('<input type="hidden" name="barcode_ids[]" value="' + id + '">');
        });
    }

    // Bulk action form submission
    $('#bulkActionForm').submit(function(e) {
        const action = $('select[name="action"]').val();
        const count = $('input[name="barcode_ids[]"]:checked').length;
        
        if (count === 0) {
            e.preventDefault();
            alert('Please select at least one barcode.');
            return;
        }

        const confirmMessages = {
            'activate': `Are you sure you want to activate ${count} barcode(s)?`,
            'deactivate': `Are you sure you want to deactivate ${count} barcode(s)?`,
            'mark_damaged': `Are you sure you want to mark ${count} barcode(s) as damaged?`,
            'delete': `Are you sure you want to delete ${count} barcode(s)? This action cannot be undone.`
        };

        if (!confirm(confirmMessages[action])) {
            e.preventDefault();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/barcode/index.blade.php ENDPATH**/ ?>