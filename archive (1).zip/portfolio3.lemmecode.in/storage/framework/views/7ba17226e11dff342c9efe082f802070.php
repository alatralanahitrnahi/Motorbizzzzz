<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Edit Profile</h2>
<a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Profile
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <form id="send-verification" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
            </form>

            <form method="POST" action="<?php echo e(route('profile.update')); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="card">
                    <div class="card-header">
                        <h5>Profile Information</h5>
                    </div>
                    <div class="card-body">

                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo e(__('Name')); ?> *</label>
                            <input id="name" name="name" type="text" class="form-control" 
                                value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo e(__('Email')); ?> *</label>
                            <input id="email" name="email" type="email" class="form-control"
                                value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                                <div class="mt-2">
                                    <p class="text-muted mb-1">
                                        <?php echo e(__('Your email address is unverified.')); ?>

                                        <button form="send-verification" type="submit" class="btn btn-link p-0 align-baseline">
                                            <?php echo e(__('Click here to re-send the verification email.')); ?>

                                        </button>
                                    </p>

                                    <?php if(session('status') === 'verification-link-sent'): ?>
                                        <p class="text-success small mt-1">
                                            <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> <?php echo e(__('Save')); ?>

                        </button>

                        <?php if(session('status') === 'profile-updated'): ?>
                            <span class="text-success small" x-data="{ show: true }" x-show="show" 
                                  x-init="setTimeout(() => show = false, 2000)" x-transition>
                                <?php echo e(__('Saved.')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/profile/edit.blade.php ENDPATH**/ ?>