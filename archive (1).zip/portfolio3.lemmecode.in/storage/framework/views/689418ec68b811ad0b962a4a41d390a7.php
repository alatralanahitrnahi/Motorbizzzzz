<?php $__env->startSection('title', 'Warehouse Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">Warehouse Management</h1>
      
        <a href="<?php echo e(route('dashboard.warehouses.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add New Warehouse
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Warehouses</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['total']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-warehouse fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Active</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['active']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Inactive</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['inactive']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-pause-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Default</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['default']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-star fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <?php
    $paginatedWarehouses = $warehouses;
?>

<!-- Filters -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Filters</h6>
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('dashboard.warehouses.index')); ?>">
            <div class="row">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Search warehouses..."
                           value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <select name="type" class="form-control">
                        <option value="">All Types</option>
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(request('type') == $key ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-control">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="city" class="form-control">
                        <option value="">All Cities</option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city); ?>" <?php echo e(request('city') == $city ? 'selected' : ''); ?>>
                                <?php echo e($city); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="<?php echo e(route('dashboard.warehouses.index')); ?>" class="btn btn-secondary">Clear</a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Warehouses Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Warehouses List</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Default</th>
                        <th>Staff</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
             <?php $__empty_1 = true; $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                            <td><strong><?php echo e($warehouse->name); ?></strong></td>
                            <td>
                                <div class="text-sm">
                                    <?php echo e($warehouse->address); ?><br>
                                    <span class="text-muted"><?php echo e($warehouse->city); ?>, <?php echo e($warehouse->state); ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-info text-dark"><?php echo e($warehouse->type_display); ?></span>
                            </td>
                            <td>
                                <div class="text-sm">
                                    <?php if($warehouse->contact_phone): ?>
                                        <div><i class="fas fa-phone fa-sm"></i> <?php echo e($warehouse->contact_phone); ?></div>
                                    <?php endif; ?>
                                    <?php if($warehouse->contact_email): ?>
                                        <div><i class="fas fa-envelope fa-sm"></i> <?php echo e($warehouse->contact_email); ?></div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="custom-control custom-switch">
                                    <label class="custom-control-label" for="status<?php echo e($warehouse->id); ?>">
                                        <span class="badge badge-<?php echo e($warehouse->is_active ? 'success' : 'secondary'); ?> text-dark">
                                            <?php echo e($warehouse->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <?php if($warehouse->is_default): ?>
                                    <span class="badge badge-warning text-dark">
                                        <i class="fas fa-star"></i> Default
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-primary text-dark">
                                    <?php echo e($warehouse->users_count ?? $warehouse->users->count()); ?>

                                </span>
                            </td>
                          <td>
    <div class="btn-group" role="group">
      

<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'view', 'warehouses')): ?>
    <a href="<?php echo e(route('dashboard.warehouses.show', $warehouse)); ?>"
       class="btn btn-info btn-sm" title="View">
        <i class="fas fa-eye"></i>
    </a>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'edit', 'warehouses')): ?>
    <a href="<?php echo e(route('dashboard.warehouses.edit', $warehouse)); ?>"
       class="btn btn-warning btn-sm" title="Edit">
        <i class="fas fa-edit"></i>
    </a>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'assign', 'warehouses')): ?>
    <a href="<?php echo e(route('dashboard.warehouses.assign-staff', $warehouse)); ?>"
       class="btn btn-success btn-sm" title="Assign Staff">
        <i class="fas fa-users"></i>
    </a>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'delete', 'warehouses')): ?>
    <form method="POST" action="<?php echo e(route('dashboard.warehouses.destroy', $warehouse)); ?>"
          style="display: inline;" class="delete-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger btn-sm" title="Delete">
            <i class="fas fa-trash"></i>
        </button>
    </form>
<?php endif; ?>

    </div>
</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">No warehouses found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

<!-- Pagination -->
<div class="d-flex justify-content-center">
    <?php echo e($warehouses->links()); ?>  
</div>


    </div>
</div>


  <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h4><?php echo e($warehouse->name); ?></h4>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $warehouse->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="mt-3"><?php echo e($block->name); ?> (<?php echo e($block->rows); ?> x <?php echo e($block->columns); ?>)</h5>
                    <div class="d-flex flex-wrap" style="width: fit-content;">
                        <?php $__currentLoopData = $block->slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $color = match($slot->status) {
                                    'empty' => 'btn-success',
                                    'partial' => 'btn-warning',
                                    'full' => 'btn-danger',
                                    default => 'btn-secondary'
                                };
                            ?>
                            <button class="btn <?php echo e($color); ?> m-1" style="width: 50px; height: 50px;" title="Row: <?php echo e($slot->row); ?>, Col: <?php echo e($slot->column); ?>">
                                <?php echo e($slot->row); ?>x<?php echo e($slot->column); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Updated Modal Section in your Blade file -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete warehouse <strong id="warehouse-name"></strong>?</p>
        <p class="text-danger">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
<!-- Delete Button in Modal -->
<form method="POST" action="<?php echo e(route('dashboard.warehouses.destroy', $warehouse)); ?>" 
      style="display: inline;" 
      onsubmit="return confirm('Are you sure you want to delete <?php echo e($warehouse->name); ?>?')">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
        <i class="fas fa-trash"></i>
    </button>
</form>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Updated JavaScript Section -->
<script>
$(document).ready(function() {
    // When delete button is clicked
    $(document).on('click', '.delete-warehouse', function(e) {
        e.preventDefault();

        const warehouseId = $(this).data('warehouse-id');
        const warehouseName = $(this).data('warehouse-name');

        console.log('Warehouse ID:', warehouseId); // Debug log
        console.log('Warehouse Name:', warehouseName); // Debug log

        if (!warehouseId) {
            alert("Error: Warehouse ID is missing.");
            return;
        }

        // Set modal warehouse name
        $('#warehouse-name').text(warehouseName || 'Unknown');

        // Set delete URL - Make sure this route exists in your routes file
        const deleteUrl = `/dashboard/warehouses/${warehouseId}`;
        $('#delete-warehouse-form').attr('action', deleteUrl);
        
        console.log('Delete URL:', deleteUrl); // Debug log
        
        // Show modal
        $('#deleteModal').modal('show');
    });

    // Handle actual form submission
    $('#delete-warehouse-form').on('submit', function(e) {
        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true).text('Deleting...');
        
        // Optional: Add a small delay to show the loading state
        setTimeout(() => {
            // Form will submit normally after this
        }, 100);
    });

    // Reset modal form when closed
    $('#deleteModal').on('hidden.bs.modal', function() {
        $('#delete-warehouse-form button[type="submit"]').prop('disabled', false).text('Delete');
        $('#delete-warehouse-form').attr('action', ''); // Clear action
    });
});
</script>

<!-- Alternative: Direct form submission without modal (simpler approach) -->
<script>
// If you prefer a simple confirm dialog instead of modal:
$(document).on('click', '.delete-warehouse-simple', function(e) {
    e.preventDefault();
    
    const warehouseId = $(this).data('warehouse-id');
    const warehouseName = $(this).data('warehouse-name');
    
    if (confirm(`Are you sure you want to delete warehouse "${warehouseName}"? This action cannot be undone.`)) {
        // Create a form dynamically and submit it
        const form = $('<form method="POST" action="/dashboard/warehouses/' + warehouseId + '">' +
                      '<?php echo csrf_field(); ?>' +
                      '<?php echo method_field("DELETE"); ?>' +
                      '</form>');
        $('body').append(form);
        form.submit();
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/warehouses/index.blade.php ENDPATH**/ ?>