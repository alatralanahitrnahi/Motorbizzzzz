<?php $__env->startSection('title', 'Material Details'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><h3>Material Details</h3></div>
        <div class="card-body">
            <p><strong>Name:</strong> <?php echo e($material->name); ?></p>
            <p><strong>Code:</strong> <?php echo e($material->code); ?></p>
            <p><strong>Description:</strong><br><?php echo e($material->description ?? 'N/A'); ?></p>
            <p><strong>Unit:</strong> <?php echo e($material->unit); ?></p>
            <p><strong>Unit Price:</strong> <?php echo e(number_format($material->unit_price, 2)); ?></p>
            <p><strong>GST Rate:</strong> <?php echo e($material->gst_rate); ?>%</p>
            <p><strong>Category:</strong> <?php echo e($material->category ?? 'N/A'); ?></p>
            <p><strong>Available:</strong> 
                <span class="badge bg-<?php echo e($material->is_active ? 'success' : 'danger'); ?>">
                    <?php echo e($material->is_available ? 'Yes' : 'No'); ?>

                </span>
            </p>
            <p><strong>Created At:</strong> <?php echo e($material->created_at->format('M d, Y h:i A')); ?></p>
            <p><strong>Updated At:</strong> <?php echo e($material->updated_at->format('M d, Y h:i A')); ?></p>

            <a href="<?php echo e(route('materials.index')); ?>" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/materials/show.blade.php ENDPATH**/ ?>