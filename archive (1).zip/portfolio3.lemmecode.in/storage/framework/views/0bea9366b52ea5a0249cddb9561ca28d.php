<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Select Purchase Order</h2>

    <?php if($purchaseOrders->isEmpty()): ?>
        <div class="alert alert-warning">
            No purchase orders available.
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">PO Number: <?php echo e($po->po_number); ?></h5>
                            <p class="card-text">Vendor ID: <?php echo e($po->vendor_id); ?></p>
                            <a href="<?php echo e(route('quality.showPO', $po->id)); ?>" class="btn btn-primary">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/quality/index.blade.php ENDPATH**/ ?>