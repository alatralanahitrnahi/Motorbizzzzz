<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Purchase Order: <strong><?php echo e($po->po_number); ?></strong></h2>

    
    <form method="POST" action="<?php echo e(route('quality.generateBarcodes')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="po_id" value="<?php echo e($po->id); ?>">
        <div class="table-responsive">
            <table class="table table-bordered align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>Item Name</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Weight</th>
                        <th>Dimensions</th>
                        <th>Approval</th>
                        <th>Update</th>
                        <th>Select for Barcode</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $po->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->item_name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                            <td>
                                <input form="approveForm<?php echo e($item->id); ?>" type="text" name="weight" class="form-control"
                                    value="<?php echo e($item->weight ?? ($item->material->weight_per_unit ?? '')); ?>">
                            </td>
                            <td>
                                <input form="approveForm<?php echo e($item->id); ?>" type="text" name="dimensions"
                                    class="form-control" value="<?php echo e($item->dimensions); ?>"
                                    pattern="\d+" title="Only digits allowed"
                                    oninput="this.value = this.value.replace(/\D/g, '')">
                            </td>
                            <td>
                                <select form="approveForm<?php echo e($item->id); ?>" name="approval_status" class="form-select">
                                    <option value="approved" <?php echo e($item->approval_status === 'approved' ? 'selected' : ''); ?>>Approved</option>
                                    <option value="rejected" <?php echo e($item->approval_status === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                </select>
                            </td>
                            <td>
                                <form id="approveForm<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('quality.approveItem', $item->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                </form>
                            </td>
                            <td>
                                <?php if($item->approval_status === 'approved'): ?>
                                    <input type="checkbox" name="approved_items[]" value="<?php echo e($item->id); ?>">
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-muted">No items found for this Purchase Order.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <button type="submit" class="btn btn-success">Generate Barcodes</button>
        </div>
    </form>

    
    <form method="POST" action="<?php echo e(route('quality.approveDispatch')); ?>" class="mt-3">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $po->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->approval_status === 'approved'): ?>
                <input type="hidden" name="items[]" value="<?php echo e($item->id); ?>">
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn btn-warning">Approve Dispatch</button>
    </form>

    
    <?php if(session('barcodes')): ?>
    <div class="mt-5">
        <h4>Generated Barcodes</h4>
        <div class="text-end mb-3">
            <button onclick="window.print()" class="btn btn-outline-secondary">Print Barcodes</button>
        </div>
        <div class="row">
            <?php $__currentLoopData = session('barcodes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card p-3 text-center shadow-sm">
                        <h5 class="card-title mb-1"><?php echo e($entry['item']->item_name); ?></h5>
                        <p class="mb-1">Quantity: <?php echo e($entry['item']->quantity); ?></p>
                        <p class="mb-1 text-muted">Weight: <?php echo e($entry['item']->weight); ?></p>
                        <p class="mb-2 text-muted">Dimensions: <?php echo e($entry['item']->dimensions); ?></p>
                        <div class="barcode"><?php echo $entry['barcode']; ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/quality/show_po.blade.php ENDPATH**/ ?>