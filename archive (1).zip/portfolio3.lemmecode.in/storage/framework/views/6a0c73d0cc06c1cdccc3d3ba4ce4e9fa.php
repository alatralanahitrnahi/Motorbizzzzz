<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Pending Material Requests</h1>

    <?php if($requests->isEmpty()): ?>
        <div class="alert alert-info">
            No pending material requests found.
        </div>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Material Name</th>
                    <th>Requested By</th>
                    <th>Requested At</th>
                    <th>Create Material</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($request->name); ?></td>
                        <td><?php echo e($request->requestedBy->name ?? 'Unknown'); ?></td>
                        <td><?php echo e($request->created_at->format('d M Y, h:i A')); ?></td>
                        <td>
                            <a href="<?php echo e(route('materials.create', ['name' => $request->name])); ?>"
                               class="btn btn-sm btn-success">
                                Create
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/admin/material_requests/index.blade.php ENDPATH**/ ?>