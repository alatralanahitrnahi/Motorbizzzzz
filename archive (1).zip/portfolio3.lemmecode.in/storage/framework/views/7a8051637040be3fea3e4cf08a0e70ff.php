<?php $__env->startSection('title', 'Purchase Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Purchase Orders</h2>
            <p class="text-muted mb-0">Manage all purchase orders</p>
        </div>
        <a href="<?php echo e(route('purchase-orders.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Create Purchase Order
        </a>
    </div>

    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('purchase-orders.index')); ?>" class="row g-3">

                
                <div class="col-md-3">
                    <label for="po_number" class="form-label">PO Number</label>
                    <input type="text" class="form-control" id="po_number" name="po_number"
                           value="<?php echo e(request('po_number')); ?>" placeholder="Search PO Number">
                </div>

                
                <div class="col-md-3">
                    <label for="vendor" class="form-label">Vendor</label>
                    <input type="text" class="form-control" id="vendor" name="vendor"
                           value="<?php echo e(request('vendor')); ?>" placeholder="Search Vendor Name">
                </div>

                
                <div class="col-md-3">
                    <label for="item_name" class="form-label">Item Name</label>
                    <input type="text" class="form-control" id="item_name" name="item_name"
                           value="<?php echo e(request('item_name')); ?>" placeholder="Search Item Name">
                </div>

                
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                        <option value="ordered" <?php echo e(request('status') == 'ordered' ? 'selected' : ''); ?>>Ordered</option>
                        <option value="received" <?php echo e(request('status') == 'received' ? 'selected' : ''); ?>>Received</option>
                        <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                    </select>
                </div>

                
                <div class="col-md-3">
                    <label for="date_from" class="form-label">Date From</label>
                    <input type="date" class="form-control" id="date_from" name="date_from"
                           value="<?php echo e(request('date_from')); ?>">
                </div>

                
                <div class="col-md-3">
                    <label for="date_to" class="form-label">Date To</label>
                    <input type="date" class="form-control" id="date_to" name="date_to"
                           value="<?php echo e(request('date_to')); ?>">
                </div>

                
                <div class="col-md-6 d-flex align-items-end">
                    <button type="submit" class="btn btn-outline-primary me-2">
                        <i class="fas fa-search me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('purchase-orders.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i> Clear
                    </a>
                </div>

            </form>
        </div>
    </div>
</div>



    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Purchase Orders List</h5>
            <span class="badge bg-secondary"><?php echo e($orders->total()); ?> orders</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>PO Number</th>
                            <th>Vendor</th>
                            <th>PO Date</th>
                            <th>Expected Delivery</th>
                            <th>Items Qty</th>
                            <th>Total Amount</th>
                            <th>GST Amount</th>
                            <th>Final Amount</th>
                            <th>Status</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($order->po_number ?? 'N/A'); ?></strong>
                                </td>
                                <td>
    <div>
        <strong><?php echo e($order->vendor->name ?? 'Unknown Vendor'); ?></strong>
        
        <?php if($order->items && $order->items->count()): ?>
            <br>
            <small class="text-muted">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($item->item_name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </small>
        <?php endif; ?>
    </div>
</td>

                                <td>
                                    <?php if($order->po_date): ?>
                                        <?php echo e(\Carbon\Carbon::parse($order->po_date)->format('M d, Y')); ?>

                                        <br><small class="text-muted"><?php echo e(\Carbon\Carbon::parse($order->po_date)->diffForHumans()); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($order->expected_delivery): ?>
                                        <?php echo e(\Carbon\Carbon::parse($order->expected_delivery)->format('M d, Y')); ?>

                                        <?php if(\Carbon\Carbon::parse($order->expected_delivery)->isPast() && $order->status !== 'received'): ?>
                                            <br><small class="text-danger"><i class="fas fa-exclamation-triangle"></i> Overdue</small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                      <?php echo e(number_format($order->items->sum('quantity'), 0)); ?>

                                    </span>
                                </td>
                                <td>
                                    <strong><?php echo e(number_format($order->total_amount ?? 0, 2)); ?></strong>
                                </td>
                                <td>
                                    <?php echo e(number_format($order->gst_amount ?? 0, 2)); ?>

                                </td>
                                <td>
                                    <strong class="text-success">
                                        <?php echo e(number_format($order->final_amount ?? 0, 2)); ?>

                                    </strong>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e(match($order->status) {
                                        'approved' => 'success',
                                        'pending' => 'warning',
                                        'received' => 'info',
                                        'ordered' => 'primary',
                                        'cancelled' => 'danger',
                                        default => 'secondary'
                                    }); ?>">
                                        <?php echo e(ucfirst($order->status ?? 'Unknown')); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        
                                        <a href="<?php echo e(route('purchase-orders.show', $order)); ?>" 
                                           class="btn btn-sm btn-outline-info" 
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        
                                        <?php if(!in_array($order->status, ['received', 'cancelled'])): ?>
                                            <a href="<?php echo e(route('purchase-orders.edit', $order)); ?>" 
                                               class="btn btn-sm btn-outline-warning" 
                                               title="Edit Order">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        <?php endif; ?>

                                        
                                        <?php if(!in_array($order->status, ['received', 'cancelled'])): ?>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-sm btn-outline-primary dropdown-toggle" 
                                                        data-bs-toggle="dropdown" title="Update Status">
                                                    <i class="fas fa-tasks"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <?php if($order->status === 'pending'): ?>
                                                        <li><a class="dropdown-item status-update" 
                                                               href="#" data-order-id="<?php echo e($order->id); ?>" 
                                                               data-status="approved">
                                                            <i class="fas fa-check text-success"></i> Approve
                                                        </a></li>
                                                        <li><a class="dropdown-item status-update" 
                                                               href="#" data-order-id="<?php echo e($order->id); ?>" 
                                                               data-status="cancelled">
                                                            <i class="fas fa-times text-danger"></i> Cancel
                                                        </a></li>
                                                    <?php elseif($order->status === 'approved'): ?>
                                                        <li><a class="dropdown-item status-update" 
                                                               href="#" data-order-id="<?php echo e($order->id); ?>" 
                                                               data-status="ordered">
                                                            <i class="fas fa-shopping-cart text-primary"></i> Mark as Ordered
                                                        </a></li>
                                                    <?php elseif($order->status === 'ordered'): ?>
                                                        <li><a class="dropdown-item status-update" 
                                                               href="#" data-order-id="<?php echo e($order->id); ?>" 
                                                               data-status="received">
                                                            <i class="fas fa-check-circle text-info"></i> Mark as Received
                                                        </a></li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>

                                        
                                        <?php if(in_array($order->status, ['pending', 'cancelled'])): ?>
                                            <form action="<?php echo e(route('purchase-orders.destroy', $order)); ?>" 
                                                  method="POST" 
                                                  onsubmit="return confirm('Are you sure you want to delete this purchase order?');" 
                                                  style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                        title="Delete Order">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-inbox fa-3x mb-3"></i>
                                        <p>No purchase orders found.</p>
                                        <a href="<?php echo e(route('purchase-orders.create')); ?>" class="btn btn-primary">
                                            <i class="fas fa-plus"></i> Create First Purchase Order
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
   <!-- 
        <?php if($orders->hasPages()): ?>
            <div class="card-footer">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="text-muted">
                        Showing <?php echo e($orders->firstItem()); ?> to <?php echo e($orders->lastItem()); ?> of <?php echo e($orders->total()); ?> results
                    </div>
                    <?php echo e($orders->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>  -->
      
      
<?php if($orders->hasPages()): ?>
    <div class="card-footer">
        <div class="d-flex justify-content-between align-items-center">
            <div class="text-muted">
                Showing <?php echo e($orders->firstItem()); ?> to <?php echo e($orders->lastItem()); ?> of <?php echo e($orders->total()); ?> results
            </div>
            <div class="pagination pagination-lg mb-0">
                <?php echo e($orders->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

    
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6>Pending Orders</h6>
                            <h3><?php echo e($orders->where('status', 'pending')->count()); ?></h3>
                        </div>
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6>Approved Orders</h6>
                            <h3><?php echo e($orders->where('status', 'approved')->count()); ?></h3>
                        </div>
                        <i class="fas fa-check fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6>Received Orders</h6>
                            <h3><?php echo e($orders->where('status', 'received')->count()); ?></h3>
                        </div>
                        <i class="fas fa-box fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6>Total Value</h6>
                            <h3><?php echo e(number_format($orders->sum('final_amount'), 0)); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="statusUpdateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Order Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to update this order status?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmStatusUpdate">Update Status</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Status update functionality
    let orderIdToUpdate = null;
    let newStatus = null;
    
    document.querySelectorAll('.status-update').forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            orderIdToUpdate = this.getAttribute('data-order-id');
            newStatus = this.getAttribute('data-status');
            
            // Show confirmation modal
            const modal = new bootstrap.Modal(document.getElementById('statusUpdateModal'));
            modal.show();
        });
    });
    
    document.getElementById('confirmStatusUpdate').addEventListener('click', function() {
        if (orderIdToUpdate && newStatus) {
            // Make AJAX request to update status
            fetch(`/purchase-orders/${orderIdToUpdate}/status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({
                    status: newStatus
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload(); // Reload page to show updated status
                } else {
                    alert('Error updating status: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the status.');
            });
            
            // Hide modal
            bootstrap.Modal.getInstance(document.getElementById('statusUpdateModal')).hide();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/purchase_orders/index.blade.php ENDPATH**/ ?>