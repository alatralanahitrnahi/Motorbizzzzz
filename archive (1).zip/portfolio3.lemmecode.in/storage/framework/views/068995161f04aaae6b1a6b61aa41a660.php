<?php $__env->startSection('title', 'Edit Material'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><h3>Edit Material</h3></div>
        <div class="card-body">
           <form id="materialForm" action="<?php echo e(route('materials.update', $material)); ?>" method="POST">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('materials.partials.form', ['material' => $material], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/materials/edit.blade.php ENDPATH**/ ?>