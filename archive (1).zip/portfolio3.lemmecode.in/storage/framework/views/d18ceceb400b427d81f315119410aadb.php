<p>Hello Admin,</p>
<p>The vendor <strong><?php echo e($user->name); ?></strong> has requested a missing material: <strong><?php echo e($materialName); ?></strong>.</p>
<p>Please review and add it in the material section if valid.</p>
<?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/emails/material_missing.blade.php ENDPATH**/ ?>