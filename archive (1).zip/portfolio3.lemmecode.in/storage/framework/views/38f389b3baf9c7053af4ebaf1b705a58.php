<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>