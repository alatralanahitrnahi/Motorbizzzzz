<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Print Barcodes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 40px 20px 20px 20px; /* Increased top margin */
            font-family: Arial, sans-serif;
            font-size: 16px; /* Increased base font size */
        }

        .container {
            width: 100%;
            margin: auto;
        }

        .text-center {
            text-align: center;
        }

        .mb-5 {
            margin-bottom: 3rem;
        }

        .mt-2 {
            margin-top: 0.75rem;
        }

        .mt-4 {
            margin-top: 2rem;
        }

        h2 {
            font-size: 24px; /* Larger heading */
        }

        p, code {
            font-size: 18px;
        }

        .page-break {
            page-break-after: always;
        }

        @media print {
            body {
                margin: 40px 20px 20px 20px; /* Ensure top margin remains in print */
            }

            .page-break {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>
    <div class="container mt-4">

       <?php $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="text-center mb-5 page-break">
        <h2><?php echo e($analysis->product_name ?? 'Product'); ?></h2>
        <p>Category: <?php echo e($analysis->product_category ?? 'N/A'); ?></p>
        <p>SKU: <?php echo e($analysis->sku_id ?? 'N/A'); ?></p>
        <p>Quantity: <?php echo e($analysis->quantity ?? 'N/A'); ?></p>

        <svg class="barcode" data-code="<?php echo e($analysis->barcode); ?>"></svg>

        <div class="mt-2">
            <code><?php echo e($analysis->barcode ?? 'N/A'); ?></code>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.barcode').forEach(function (el) {
                const code = el.dataset.code;
                if (code) {
                    JsBarcode(el, code, {
                        format: "CODE128",
                        width: 2,
                        height: 60,
                        displayValue: false,
                        margin: 10
                    });
                }
            });

            window.print();
            window.onafterprint = function () {
                window.close();
            };
        });
    </script>
</body>
</html>
<?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/quality_analysis/print_barcodes.blade.php ENDPATH**/ ?>