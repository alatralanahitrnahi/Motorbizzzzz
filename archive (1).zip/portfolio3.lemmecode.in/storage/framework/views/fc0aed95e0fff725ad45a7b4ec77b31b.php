<?php $__env->startSection('title', 'Purchase Order Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Purchase Order Details</h1>
        <div>
            <a href="<?php echo e(route('purchase-orders.edit', $purchaseOrder)); ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i> Edit
            </a>
            <a href="<?php echo e(route('purchase-orders.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>


<div class="card mb-4">
    <div class="card-header"><h5>Order Information</h5></div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <tr><th>PO Number</th><td><?php echo e($purchaseOrder->po_number ?? 'N/A'); ?></td></tr>

                
                <tr><th>Vendor Name</th><td><?php echo e($purchaseOrder->vendor?->name ?? 'N/A'); ?></td></tr>
                <tr><th>Business Name</th><td><?php echo e($purchaseOrder->vendor?->business_name ?? 'N/A'); ?></td></tr>
                <tr><th>Vendor Email</th><td><?php echo e($purchaseOrder->vendor?->email ?? 'N/A'); ?></td></tr>
                <tr><th>Vendor Phone</th><td><?php echo e($purchaseOrder->vendor?->phone ?? 'N/A'); ?></td></tr>

                
                <tr><th>Warehouse Address</th><td><?php echo e($purchaseOrder->vendor?->warehouse_address ?? 'N/A'); ?></td></tr>
                <tr><th>Company Address</th><td><?php echo e($purchaseOrder->vendor?->company_address ?? 'N/A'); ?></td></tr>

                
                <tr><th>PO Date</th><td><?php echo e($purchaseOrder->po_date ? \Carbon\Carbon::parse($purchaseOrder->po_date)->format('M d, Y') : 'N/A'); ?></td></tr>
                <tr><th>Order Date</th><td><?php echo e($purchaseOrder->order_date ? \Carbon\Carbon::parse($purchaseOrder->order_date)->format('M d, Y') : 'N/A'); ?></td></tr>
                <tr><th>Expected Delivery</th><td><?php echo e($purchaseOrder->expected_delivery ? \Carbon\Carbon::parse($purchaseOrder->expected_delivery)->format('M d, Y') : 'N/A'); ?></td></tr>

                
                <tr><th>Shipping Address</th><td><?php echo e($purchaseOrder->shipping_address ?? 'N/A'); ?></td></tr>
                <tr><th>Shipping Cost</th><td>₹<?php echo e(number_format($purchaseOrder->shipping_cost ?? 0, 2)); ?></td></tr>
                <tr><th>Total Amount</th><td>₹<?php echo e(number_format($purchaseOrder->total_amount ?? 0, 2)); ?></td></tr>
                <tr><th>GST Amount</th><td>₹<?php echo e(number_format($purchaseOrder->gst_amount ?? 0, 2)); ?></td></tr>
                <tr><th>Final Amount</th><td><strong>₹<?php echo e(number_format($purchaseOrder->final_amount ?? 0, 2)); ?></strong></td></tr>

                
                <tr>
                    <th>Status</th>
                    <td>
                        <span class="badge bg-<?php echo e(match($purchaseOrder->status) {
                            'approved' => 'success',
                            'pending' => 'warning',
                            'received' => 'info',
                            'cancelled' => 'danger',
                            'ordered' => 'primary',
                            'completed' => 'success',
                            'shipped' => 'info',
                            'delivered' => 'success',
                            default => 'secondary'
                        }); ?>">
                            <?php echo e(ucfirst($purchaseOrder->status ?? 'Unknown')); ?>

                        </span>
                    </td>
                </tr>

                
                <?php if($purchaseOrder->notes): ?>
                    <tr><th>Notes</th><td><?php echo e($purchaseOrder->notes); ?></td></tr>
                <?php endif; ?>

                
                <tr><th>Created At</th><td><?php echo e($purchaseOrder->created_at ? $purchaseOrder->created_at->format('M d, Y h:i A') : 'N/A'); ?></td></tr>
                <tr><th>Updated At</th><td><?php echo e($purchaseOrder->updated_at ? $purchaseOrder->updated_at->format('M d, Y h:i A') : 'N/A'); ?></td></tr>
            </table>
        </div>
    </div>
</div>


<?php if($purchaseOrder->items && $purchaseOrder->items->count() > 0): ?>
    <div class="card">
        <div class="card-header">
            <h5>Order Items (<?php echo e($purchaseOrder->items->count()); ?> items)</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Item Name</th>
                            <th>Material Code</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Unit Price</th>
                            <th>Subtotal</th>
                            <th>GST Rate</th>
                            <th>GST Amount</th>
                            <th>Final Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchaseOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <?php echo e($item->material?->name ?? $item->item_name ?? 'N/A'); ?>

                                <?php if($item->material?->description): ?>
                                    <br><small class="text-muted"><?php echo e($item->material->description); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->material?->code ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($item->quantity ?? 0, 2)); ?></td>
                            <td><?php echo e($item->material?->unit ?? 'N/A'); ?></td>
                            <td>₹<?php echo e(number_format($item->material?->unit_price ?? $item->unit_price ?? 0, 2)); ?></td>
                            <td>₹<?php echo e(number_format($item->total_price ?? 0, 2)); ?></td>
                            <td><?php echo e(number_format($item->material?->gst_rate ?? $item->gst_rate ?? 0, 2)); ?>%</td>
                            <td>₹<?php echo e(number_format($item->gst_amount ?? 0, 2)); ?></td>
                            <td><strong>₹<?php echo e(number_format($item->final_amount ?? $item->total_price ?? 0, 2)); ?></strong></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th colspan="6">Total</th>
                            <th>₹<?php echo e(number_format($purchaseOrder->total_amount ?? 0, 2)); ?></th>
                            <th></th>
                            <th>₹<?php echo e(number_format($purchaseOrder->gst_amount ?? 0, 2)); ?></th>
                            <th><strong>₹<?php echo e(number_format($purchaseOrder->final_amount ?? 0, 2)); ?></strong></th>
                        </tr>
                    </tfoot>
                </table>
            </div>

            
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title">Order Summary</h6>
                            <p class="mb-1"><strong>Total Items:</strong> <?php echo e($purchaseOrder->items->count()); ?></p>
                            <p class="mb-1"><strong>Total Quantity:</strong> <?php echo e(number_format($purchaseOrder->items->sum('quantity'), 2)); ?></p>
                            <p class="mb-0"><strong>Average Item Value:</strong> ₹<?php echo e($purchaseOrder->items->count() > 0 ? number_format($purchaseOrder->final_amount / $purchaseOrder->items->count(), 2) : '0.00'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title">Amount Breakdown</h6>
                            <p class="mb-1"><strong>Subtotal:</strong> ₹<?php echo e(number_format($purchaseOrder->total_amount ?? 0, 2)); ?></p>
                            <p class="mb-1"><strong>GST:</strong> ₹<?php echo e(number_format($purchaseOrder->gst_amount ?? 0, 2)); ?></p>
                            <p class="mb-0"><strong>Final Total:</strong> <span class="text-success fw-bold">₹<?php echo e(number_format($purchaseOrder->final_amount ?? 0, 2)); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="card">
        <div class="card-header"><h5>Order Items</h5></div>
        <div class="card-body">
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> No items found for this purchase order.
            </div>
        </div>
    </div>
<?php endif; ?>



    
    <div class="mt-4 d-flex gap-2">
        <a href="<?php echo e(route('purchase-orders.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        <a href="<?php echo e(route('purchase-orders.edit', $purchaseOrder)); ?>" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit Order
        </a>
        <?php if(in_array($purchaseOrder->status, ['pending', 'cancelled'])): ?>
            <form action="<?php echo e(route('purchase-orders.destroy', $purchaseOrder)); ?>" method="POST" 
                  onsubmit="return confirm('Are you sure you want to delete this purchase order?');" 
                  style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </form>
        <?php endif; ?>
        <a href="<?php echo e(route('purchase_orders.generate_pdf', $purchaseOrder)); ?>" class="btn btn-info">
            <i class="fas fa-file-pdf"></i> Generate PDF
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/purchase_orders/show.blade.php ENDPATH**/ ?>