<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">All Warehouses - Blocks & Slots</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-5">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><?php echo e($warehouse->name); ?></h4>
                <a href="<?php echo e(route('warehouses.blocks.create', $warehouse->id)); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus"></i> Add Block
                </a>
            </div>

            <div class="card-body">
                <?php if($warehouse->blocks->isEmpty()): ?>
                    <div class="alert alert-info">No blocks found for this warehouse.</div>
                <?php else: ?>
                    <table class="table table-bordered table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Name</th>
                                <th>Dimensions</th>
                                <th>Total Slots</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $warehouse->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($block->name); ?></td>
                                    <td><?php echo e($block->rows); ?> × <?php echo e($block->columns); ?></td>
                                    <td>
                                        <span class="badge badge-info text-dark">
                                            <?php echo e($block->slots->count()); ?> slots
                                        </span>
                                    </td>
                                   <td>
    <div class="btn-group btn-group-sm" role="group">
        <a href="<?php echo e(route('warehouses.blocks.show', [$warehouse->id, $block->id])); ?>" class="btn btn-info">
            <i class="fas fa-eye"></i>
        </a>

        <a href="<?php echo e(route('warehouses.blocks.edit', [$warehouse->id, $block->id])); ?>" class="btn btn-warning">
            <i class="fas fa-edit"></i>
        </a>

        <form action="<?php echo e(route('warehouses.blocks.destroy', [$warehouse->id, $block->id])); ?>"
              method="POST"
              style="display:inline;"
              onsubmit="return confirm('Are you sure you want to delete this block and its slots?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">
                <i class="fas fa-trash"></i> 
            </button>
        </form>
    </div>
</td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/warehouses/blocks/all.blade.php ENDPATH**/ ?>