<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<!-- Welcome Section -->
<div class="welcome-section">
    <div class="welcome-content text-center">
        <h1 class="welcome-title">
            <i class="fas fa-hand-wave me-3"></i>
            Welcome back, <?php echo e(Auth::user()->name); ?>!
        </h1>
        <p class="welcome-subtitle">
            Ready to manage your inventory efficiently? Your <?php echo e(Auth::user()->getRoleDisplayName()); ?> dashboard is at your service.
        </p>
        <small class="text-muted">
            <i class="fas fa-clock me-1"></i>Last login: <?php echo e($stats['last_login']); ?>

        </small>
    </div>
</div>

<!-- Dashboard Stats -->
<div class="row g-4 mb-4">
    <?php if(Auth::user()->isAdmin()): ?>
        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card users">
                <div class="stats-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['total_users'] ?? 0); ?></div>
                <div class="stats-label">Total Users</div>
                <div class="stats-sublabel"><?php echo e($stats['active_users'] ?? 0); ?> active</div>
            </div>
        </div>

        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card vendors">
                <div class="stats-icon">
                    <i class="fas fa-truck"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['total_vendors'] ?? 0); ?></div>
                <div class="stats-label">Total Vendors</div>
            </div>
        </div>

        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card inventory">
                <div class="stats-icon">
                    <i class="fas fa-boxes"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['total_inventory_items'] ?? 0); ?></div>
                <div class="stats-label">Inventory Items</div>
                <?php if(($stats['low_stock_items'] ?? 0) > 0): ?>
                    <div class="stats-sublabel text-warning">
                        <?php echo e($stats['low_stock_items']); ?> low stock
                    </div>
                <?php endif; ?>
                <?php if(($stats['out_of_stock'] ?? 0) > 0): ?>
                    <div class="stats-sublabel text-danger">
                        <?php echo e($stats['out_of_stock']); ?> out of stock
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card orders">
                <div class="stats-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['total_purchase_orders'] ?? 0); ?></div>
                <div class="stats-label">Purchase Orders</div>
                <div class="stats-sublabel"><?php echo e($stats['pending_orders'] ?? 0); ?> pending</div>
            </div>
        </div>

        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card warehouses">
                <div class="stats-icon">
                    <i class="fas fa-warehouse"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['total_warehouses'] ?? 0); ?></div>
                <div class="stats-label">Warehouses</div>
            </div>
        </div>

       
<div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stats-card quality">
        <div class="stats-icon">
            <i class="fas fa-vials"></i> 
        </div>
        <div class="stats-number"><?php echo e($stats['pending_quality_checks'] ?? 0); ?></div>
        <div class="stats-label">Pending Quality Checks</div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stats-card quality approved">
        <div class="stats-icon">
            <i class="fas fa-check-circle text-success"></i>
        </div>
        <div class="stats-number"><?php echo e($stats['approved_quality_checks'] ?? 0); ?></div>
        <div class="stats-label">Approved Quality Checks</div>
    </div>
</div>

        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card logins">
                <div class="stats-icon">
                    <i class="fas fa-sign-in-alt"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['recent_logins'] ?? 0); ?></div>
                <div class="stats-label">Recent Logins</div>
            </div>
        </div>
  
<?php elseif(Auth::user()->role === 'purchase_team'): ?>
    
    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card orders">
            <div class="stats-icon">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="stats-number">
                <?php echo e($stats['total_orders'] ?? 'N/A'); ?>

            </div>
            <div class="stats-label">Total Orders</div>
        </div>
    </div>

    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card pending">
            <div class="stats-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stats-number">
                <?php echo e($stats['pending_orders'] ?? 'N/A'); ?>

            </div>
            <div class="stats-label">Pending Orders</div>
        </div>
    </div>

    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card vendors">
            <div class="stats-icon">
                <i class="fas fa-truck"></i>
            </div>
            <div class="stats-number">
                <?php echo e($stats['total_vendors'] ?? 'N/A'); ?>

            </div>
            <div class="stats-label">Total Vendors</div>
        </div>
    </div>

    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card budget">
            <div class="stats-icon">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="stats-number">
                ₹<?php echo e(number_format($stats['budget_utilized'] ?? 0, 0)); ?>

            </div>
            <div class="stats-sublabel">This month</div>
        </div>
    </div>
        
   <?php elseif(Auth::user()->role === 'inventory_manager'): ?>
    
    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card inventory">
            <div class="stats-icon">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="stats-number"><?php echo e($stats['total_items'] ?? 0); ?></div>
            <div class="stats-label">Total Items</div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card low-stock">
            <div class="stats-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="stats-number"><?php echo e($stats['low_stock_items'] ?? 0); ?></div>
            <div class="stats-label">Low Stock Items</div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card out-of-stock">
            <div class="stats-icon">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="stats-number"><?php echo e($stats['out_of_stock'] ?? 0); ?></div>
            <div class="stats-label">Out of Stock</div>
        </div>
    </div>
    
    <div class="col-xl-3 col-lg-6 col-md-6">
        <div class="stats-card warehouses">
            <div class="stats-icon">
                <i class="fas fa-warehouse"></i>
            </div>
            <div class="stats-number"><?php echo e($stats['total_warehouses'] ?? 0); ?></div>
            <div class="stats-label">Warehouses</div>
        </div>
    </div>

        
<!--  <?php else: ?>
        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card profile">
                <div class="stats-icon">
                    <i class="fas fa-user"></i>
                </div>
<div class="stats-number">
    <?php echo e($stats['profile_completion'] ?? 0); ?>%<br>
</div>
                <div class="stats-label">Profile Completion</div>
            </div>
        </div>
        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card role">
                <div class="stats-icon">
                    <i class="fas fa-id-badge"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['role'] ?? 'User'); ?></div>
                <div class="stats-label">Your Role</div>
            </div>
        </div>
        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card activity">
                <div class="stats-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['last_activity'] ?? 'Never'); ?></div>
                <div class="stats-label">Last Activity</div>
            </div>
        </div>
        
        <div class="col-xl-3 col-lg-6 col-md-6">
            <div class="stats-card created">
                <div class="stats-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stats-number"><?php echo e($stats['account_created'] ?? 'Unknown'); ?></div>
                <div class="stats-label">Account Created</div>
            </div>
        </div> -->
    <?php endif; ?>
</div>
<!-- Quick Actions -->
<div class="col-lg-8">
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
        </div>
        <div class="card-body">
            <?php
                use Illuminate\Support\Facades\Auth;

                $user = Auth::user();
                $roleDisplay = method_exists($user, 'getRoleDisplayName') ? $user->getRoleDisplayName() : null;
                $role = strtolower($roleDisplay ?: '');

                $excludedRoutes = collect([
                    'dashboard',
                    'reports.index',
                    'admin.users',
                    'barcode.dashboard',
                    'dashboard.blocks.all',
                ]);

                $excludedTitles = collect([
                    'dashboard',
                    'reports & analytics',
                    'report analysis',
                    'user management',
                    'barcode management',
                    'view blocks',
                ]);

                $quickActions = collect($navigationItems ?? [])->filter(function($item, $key) use ($user, $role, $excludedRoutes, $excludedTitles) {
                    $route = $item['route'] ?? '';
                    $title = strtolower(trim($item['title'] ?? ''));

                    if ($key === 'dashboard' || $key === 'reports') return false;
                    if ($excludedRoutes->contains(is_array($route) ? $route[0] : $route)) return false;
                    if ($excludedTitles->contains($title)) return false;

                    if ($user->isAdmin()) return true;

                    if ($role === 'purchase') {
                        return in_array($title, ['purchase orders']);
                    }

                    if ($role === 'inventory') {
                        return in_array($title, ['inventory control', 'barcode management']);
                    }

                    return false;
                });
            ?>

            <div class="row g-3">
                
                <?php $__empty_1 = true; $__currentLoopData = $quickActions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
    try {
        $url = is_array($item['route'])
            ? route($item['route'][0], $item['route'][1])
            : route($item['route']);
    } catch (\Exception $e) {
        $title = isset($item['title']) ? $item['title'] : 'Unknown';
        \Log::error("Invalid route for Quick Action '{$title}': " . $e->getMessage());
        $url = '#';
    }
?>


                    <div class="col-md-6 col-lg-4">
                        <a href="<?php echo e($url); ?>" class="btn btn-outline-primary w-100 position-relative d-flex flex-column align-items-center py-3"
                           title="<?php echo e($item['title'] ?? 'Quick Action'); ?>">
                            <i class="<?php echo e($item['icon'] ?? 'fas fa-link'); ?> fa-2x mb-2"></i>
                            <span><?php echo e($item['title'] ?? 'Untitled'); ?></span>

                            <?php if(!empty($item['view_only'])): ?>
                                <span class="badge bg-secondary position-absolute top-0 start-100 translate-middle">
                                    View Only
                                </span>
                            <?php endif; ?>

                            <?php if(!empty($item['section'])): ?>
                                <small class="text-muted mt-1"><?php echo e($item['section']); ?></small>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            No quick actions available. Please contact your administrator for access to additional features.
                        </div>
                    </div>
                <?php endif; ?>

                
                <div class="col-md-6 col-lg-4">
                    <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-outline-secondary w-100 d-flex flex-column align-items-center py-3" title="Reports & Analytics">
                        <i class="fas fa-file-alt fa-2x mb-2"></i>
                        <span>Reports & Analytics</span>
                        <small class="text-muted mt-1">Reports</small>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>



<?php if(Auth::user()->isAdmin()): ?>
<!-- Notifications Panel -->
<div class="col-lg-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Recent Notifications</h5>
            <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                <span class="badge bg-primary"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div id="notifications-container" style="max-height: 400px; overflow-y: auto;">
                <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                    <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $data = is_array($notification->data) ? $notification->data : json_decode($notification->data, true);
                            $purchaseOrder = \App\Models\PurchaseOrder::find($data['order_id'] ?? null);
                            $orderExists = $purchaseOrder !== null;
                        ?>

                        <div class="notification-item alert alert-info d-flex justify-content-between align-items-start mb-3"
                             id="notification-<?php echo e($notification->id); ?>">
                            <div class="flex-grow-1">
                                <strong><?php echo e($data['title'] ?? 'Notification'); ?></strong>
                                <p class="mb-2"><?php echo e($data['message'] ?? 'No message'); ?></p>
                                <small class="text-muted">
                                    <i class="fas fa-clock me-1"></i><?php echo e($notification->created_at->diffForHumans()); ?>

                                </small>

                                
                                <?php if(($data['type'] ?? '') === 'purchase_order_deleted'): ?>
                                    <div class="alert alert-warning mt-2 mb-0 p-2">
                                        Purchase Order <strong>#<?php echo e($data['purchase_order_number'] ?? 'N/A'); ?></strong> was deleted by user 
                                        <strong><?php echo e($data['deleted_by'] ?? 'Unknown'); ?></strong>.
                                    </div>
                                <?php endif; ?>

                                
                                <?php if(($data['type'] ?? '') === 'purchase_order_updated'): ?>
                                    <div class="alert alert-info mt-2 mb-0 p-2">
                                        PO <strong>#<?php echo e($data['purchase_order_number'] ?? 'N/A'); ?></strong> was updated by 
                                        <strong><?php echo e($data['updated_by'] ?? 'Unknown'); ?></strong>.
                                        <?php if(isset($data['changes'])): ?>
                                            <ul class="mt-2 mb-0">
                                                <?php $__currentLoopData = $data['changes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><strong><?php echo e(ucfirst($field)); ?></strong>: "<?php echo e($values['old'] ?? 'N/A'); ?>" → "<?php echo e($values['new'] ?? 'N/A'); ?>"</li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if(isset($data['approve_url']) && $orderExists && Auth::user()->can('approve', $purchaseOrder)): ?>
                                    <form action="<?php echo e($data['approve_url']); ?>" method="POST" class="mt-2 d-inline-block">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="notification_id" value="<?php echo e($notification->id); ?>">
                                        <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                    </form>
                                <?php endif; ?>
                            </div>

                            <div class="ms-3">
                                <div class="btn-group-vertical" role="group" aria-label="Notification Actions">
                                    <?php if(isset($data['url'])): ?>
                                        <?php if($orderExists): ?>
                                            <a href="<?php echo e($data['url']); ?>" class="btn btn-sm btn-primary mb-1" title="View Purchase Order">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-secondary mb-1" disabled title="Purchase order has been deleted">
                                                <i class="fas fa-eye-slash"></i>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <button class="btn btn-sm btn-outline-success mb-1" 
                                            onclick="markAsRead('<?php echo e($notification->id); ?>')" 
                                            title="Mark as read">
                                        <i class="fas fa-check"></i>
                                    </button>

                                    <button class="btn btn-sm btn-outline-danger" 
                                            onclick="dismissNotification('<?php echo e($notification->id); ?>')" 
                                            title="Dismiss notification">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(auth()->user()->unreadNotifications->count() > 1): ?>
                        <div class="text-center mt-3">
                            <button class="btn btn-outline-success btn-sm me-2" onclick="markAllAsRead()">
                                <i class="fas fa-check-double me-1"></i>Mark All as Read
                            </button>
                            <button class="btn btn-outline-danger btn-sm" onclick="dismissAllNotifications()">
                                <i class="fas fa-trash me-1"></i>Dismiss All
                            </button>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                        <p>No new notifications.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Enhanced notification management functions
    function dismissNotification(notificationId) {
        if (!confirm('Are you sure you want to dismiss this notification? This action cannot be undone.')) {
            return;
        }
        
        const notificationElement = document.getElementById(`notification-${notificationId}`);
        const sidebarNotificationElement = document.getElementById(`sidebar-notification-${notificationId}`);
        
        // Show loading state
        if (notificationElement) {
            notificationElement.style.opacity = '0.5';
        }
        if (sidebarNotificationElement) {
            sidebarNotificationElement.style.opacity = '0.5';
        }
        
        fetch(`/notifications/${notificationId}/dismiss`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove notification from both places
                if (notificationElement) {
                    notificationElement.remove();
                }
                if (sidebarNotificationElement) {
                    sidebarNotificationElement.remove();
                }
                
                // Check if no notifications left
                checkEmptyNotifications();
                
                // Show success message
                showToast('Notification dismissed successfully', 'success');
            } else {
                // Restore opacity on error
                if (notificationElement) {
                    notificationElement.style.opacity = '1';
                }
                if (sidebarNotificationElement) {
                    sidebarNotificationElement.style.opacity = '1';
                }
                showToast('Error dismissing notification', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            // Restore opacity on error
            if (notificationElement) {
                notificationElement.style.opacity = '1';
            }
            if (sidebarNotificationElement) {
                sidebarNotificationElement.style.opacity = '1';
            }
            showToast('Error dismissing notification', 'error');
        });
    }
    
    function markAsRead(notificationId) {
        fetch(`/notifications/${notificationId}/read`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const notificationElement = document.getElementById(`notification-${notificationId}`);
                if (notificationElement) {
                    notificationElement.classList.remove('alert-info');
                    notificationElement.classList.add('alert-success');
                    notificationElement.style.opacity = '0.7';
                }
                showToast('Notification marked as read', 'success');
            } else {
                showToast('Error marking notification as read', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Error marking notification as read', 'error');
        });
    }
    
    function dismissAllNotifications() {
        if (!confirm('Are you sure you want to dismiss ALL notifications? This action cannot be undone.')) {
            return;
        }
        
        fetch('/notifications/dismiss-all', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showToast('Error dismissing all notifications', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Error dismissing all notifications', 'error');
        });
    }
    
    function markAllAsRead() {
        fetch('/notifications/mark-all-read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelectorAll('.notification-item').forEach(item => {
                    item.classList.remove('alert-info');
                    item.classList.add('alert-success');
                    item.style.opacity = '0.7';
                });
                showToast('All notifications marked as read', 'success');
            } else {
                showToast('Error marking all notifications as read', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Error marking all notifications as read', 'error');
        });
    }
    
    function checkEmptyNotifications() {
        const notificationContainer = document.getElementById('notifications-container');
        if (notificationContainer && notificationContainer.children.length === 0) {
            notificationContainer.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                    <p>No notifications to display.</p>
                </div>
            `;
        }
    }
    
    function showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
        toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        toast.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 5000);
    }

    // Auto-refresh notifications for admin users
    <?php if(Auth::user()->isAdmin()): ?>
        setInterval(function() {
            // Check for new notifications
            fetch('/admin/notifications/count')
                .then(response => response.json())
                .then(data => {
                    if (data.count > 0) {
                        // Update notification indicator if needed
                        console.log('New notifications available:', data.count);
                    }
                })
                .catch(error => console.error('Error checking notifications:', error));
        }, 60000); // Check every minute
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/index.blade.php ENDPATH**/ ?>