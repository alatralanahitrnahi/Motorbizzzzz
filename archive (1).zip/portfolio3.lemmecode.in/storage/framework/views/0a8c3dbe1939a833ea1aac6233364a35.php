<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Inventory Reports</h2>
    
    
    <form method="GET" action="<?php echo e(route('reports.index')); ?>">
        <div class="row g-3">
            <div class="col-md-2 col-sm-6">
                <label for="from_date" class="form-label">From Date:</label>
                <input type="date" id="from_date" name="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
            </div>
            <div class="col-md-2 col-sm-6">
                <label for="to_date" class="form-label">To Date:</label>
                <input type="date" id="to_date" name="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
            </div>
            <div class="col-md-3 col-sm-6">
                <label for="material_id" class="form-label">Material:</label>
                <select id="material_id" name="material_id" class="form-select">
                    <option value="">All Materials</option>
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($material->id); ?>" <?php echo e(request('material_id') == $material->id ? 'selected' : ''); ?>>
                            <?php echo e($material->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2 col-sm-6">
                <label for="type" class="form-label">Type:</label>
                <select id="type" name="type" class="form-select">
                    <option value="">All Types</option>
                    <option value="intake" <?php echo e(request('type') == 'intake' ? 'selected' : ''); ?>>Intake</option>
                    <option value="dispatch" <?php echo e(request('type') == 'dispatch' ? 'selected' : ''); ?>>Dispatch</option>
                </select>
            </div>
            <div class="col-md-2 col-sm-6">
                <label class="form-label">&nbsp;</label>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
            <div class="col-md-1 col-sm-6">
                <label class="form-label">&nbsp;</label>
                <div class="d-grid">
                    <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </div>
        </div>
    </form>

    <hr class="my-4">

    
    <div class="mb-3 d-flex flex-wrap gap-2">
        <a href="<?php echo e(route('reports.exportPDF', request()->query())); ?>" class="btn btn-danger">
            <i class="fas fa-file-pdf"></i> Export PDF
        </a>
        <?php if(method_exists('App\Http\Controllers\ReportController', 'exportExcel')): ?>
        <a href="<?php echo e(route('reports.exportExcel', request()->query())); ?>" class="btn btn-success">
            <i class="fas fa-file-excel"></i> Export Excel
        </a>
        <?php endif; ?>
       
    </div>

    
    <?php if($transactions->total() > 0): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> 
            Showing <?php echo e($transactions->firstItem()); ?> to <?php echo e($transactions->lastItem()); ?> of <?php echo e($transactions->total()); ?> results
        </div>
    <?php endif; ?>

    
    <?php if($transactions->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Transaction ID</th>
                        <th>Material</th>
                        <th>Type</th>
                        <th class="text-end">Quantity</th>
                        <th class="text-end">Weight (kg)</th>
                        <th class="text-end">Value (₹)</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($txn->transaction_id); ?></td>
                            <td>
                                <span class="badge bg-secondary"><?php echo e($txn->batch->material->name ?? 'N/A'); ?></span>
                            </td>
                            <td>
                                <span class="badge <?php echo e($txn->type == 'intake' ? 'bg-success' : 'bg-warning'); ?>">
                                    <?php echo e(ucfirst($txn->type)); ?>

                                </span>
                            </td>
                            <td class="text-end"><?php echo e(number_format($txn->quantity)); ?></td>
                            <td class="text-end"><?php echo e(number_format($txn->weight, 2)); ?></td>
                            <td class="text-end">₹<?php echo e(number_format($txn->total_value ?? 0, 2)); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($txn->transaction_date)->format('d M Y')); ?></td>
                            <td>
                                <?php if(Route::has('transactions.show')): ?>
                                <a href="<?php echo e(route('transactions.show', $txn->id)); ?>" class="btn btn-sm btn-outline-primary" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <?php if($transactions->count() > 5): ?>
                <tfoot class="table-light">
                    <tr>
                        <th colspan="3">Page Total</th>
                        <th class="text-end"><?php echo e(number_format($transactions->sum('quantity'))); ?></th>
                        <th class="text-end"><?php echo e(number_format($transactions->sum('weight'), 2)); ?></th>
                        <th class="text-end">₹<?php echo e(number_format($transactions->sum('total_value'), 2)); ?></th>
                        <th colspan="2"></th>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>

        
        <div class="d-flex justify-content-center">
            <?php echo e($transactions->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center">
            <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
            <h5>No transactions found</h5>
            <p class="mb-0">No transactions match your selected criteria. Try adjusting your filters.</p>
        </div>
    <?php endif; ?>
</div>


<style>
@media print {
    .btn, .pagination, .alert-info {
        display: none !important;
    }
    .table {
        font-size: 12px;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/reports/index.blade.php ENDPATH**/ ?>