<?php $__env->startSection('title', 'Edit Warehouse Block'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow rounded">
        <div class="card-header bg-warning text-white">
            <h4 class="mb-0 text-dark">Edit Block - <?php echo e($block->name); ?></h4>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('warehouses.blocks.update', [$warehouse->id, $block->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Block Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $block->name)); ?>" required placeholder="e.g. Block A">
                </div>
                <div class="form-row mt-3">
                    <div class="form-group col-md-6">
                        <label for="rows">Number of Rows</label>
                        <input type="number" class="form-control" id="rows" name="rows" min="1" value="<?php echo e(old('rows', $block->rows)); ?>" required>
                        <small class="text-muted">Current: <?php echo e($block->rows); ?></small>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="columns">Number of Columns</label>
                        <input type="number" class="form-control" id="columns" name="columns" min="1" value="<?php echo e(old('columns', $block->columns)); ?>" required>
                        <small class="text-muted">Current: <?php echo e($block->columns); ?></small>
                    </div>
                </div>
                <div class="alert alert-info mt-3">
                    <strong>Note:</strong> Changing dimensions will recreate all slots. Any existing slot data will be lost.
                </div>
                <button type="submit" class="btn btn-warning mt-3">Update Block</button>
                <a href="<?php echo e(route('warehouses.blocks.index', $warehouse->id)); ?>" class="btn btn-secondary mt-3">Back</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/warehouses/blocks/edit.blade.php ENDPATH**/ ?>