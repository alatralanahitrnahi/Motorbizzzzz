<?php $__env->startSection('title', 'Edit Inventory Batch'); ?>

<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2 class="mb-0">
                <i class="fas fa-edit text-primary"></i>
                Edit Inventory Batch
            </h2>
            <p class="text-muted">Modify inventory batch details</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('inventory.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Inventory
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-info-circle"></i> Batch Information
                    </h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('inventory.update', $batch->id)); ?>" method="POST" id="inventoryForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="batch_number" class="form-label">Batch Number</label>
                                <input type="text" 
                                       id="batch_number"
                                       name="batch_number"
                                       class="form-control" 
                                       value="<?php echo e(old('batch_number', $batch->batch_number)); ?>" 
                                       readonly>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="purchase_order_id" class="form-label">Purchase Order</label>
                                <select id="purchase_order_id" 
                                        name="purchase_order_id" 
                                        class="form-select" disabled>
                                    <option value="">Select PO (Optional)</option>
                                    <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($po->id); ?>"
                                            <?php echo e($batch->purchase_order_id == $po->id ? 'selected' : ''); ?>>
                                            <?php echo e($po->po_number); ?> - <?php echo e(optional($po->vendor)->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <?php if(count($selectedPoItems) > 0): ?>
                        <div class="alert alert-info mb-4">
                            <h6><i class="fas fa-info-circle"></i> PO Item Information</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Item:</strong> <?php echo e($selectedPoItems[0]->item_name); ?><br>
                                    <strong>Ordered Quantity:</strong> <?php echo e(number_format($selectedPoItems[0]->quantity, 2)); ?>

                                </div>
                                <div class="col-md-6">
                                    <strong>Unit Price:</strong> ₹<?php echo e(number_format($selectedPoItems[0]->unit_price, 2)); ?><br>
                                    <strong>Total Value:</strong> ₹<?php echo e(number_format($selectedPoItems[0]->total_price, 2)); ?>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="initial_quantity" class="form-label">Receiving Quantity</label>
                                <input type="number" id="initial_quantity" name="initial_quantity" 
       class="form-control <?php echo e($remainingQty == 0 && (old('initial_quantity', $batch->initial_quantity) == 0) ? 'is-invalid' : ''); ?>" 
       value="<?php echo e(old('initial_quantity', $batch->initial_quantity)); ?>" 
       required min="0" step="0.01">

                            </div>
                            <div class="col-md-6">
                                <label for="remaining_quantity" class="form-label">Remaining Quantity</label>
                                <input type="number" id="remaining_quantity" 
                                       class="form-control" 
                                       readonly 
                                       value="<?php echo e(max(0, $orderedQty - $totalReceivedQty - $batch->initial_quantity)); ?>">
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="quality_grade" class="form-label">Quality Grade</label>
                                <select id="quality_grade" name="quality_grade" class="form-select">
                                    <option value="">Select Grade (Optional)</option>
                                    <?php $__currentLoopData = ['A', 'B', 'C', 'Premium', 'Standard']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($grade); ?>" 
                                            <?php echo e(old('quality_grade', $batch->quality_grade) == $grade ? 'selected' : ''); ?>>
                                            <?php echo e($grade); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <!-- Warehouse Selection -->
<div class="col-md-6">
    <label for="warehouse_id" class="form-label">Warehouse</label>
    <select id="warehouse_id"
            name="warehouse_id"
            class="form-select <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <option value="">Select Warehouse</option>
        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($warehouse->id); ?>"
                <?php echo e((old('warehouse_id', $batch->warehouse_id ?? '') == $warehouse->id) ? 'selected' : ''); ?>>
                <?php echo e($warehouse->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="received_date" class="form-label">Received Date</label>
                                <input type="date" 
                                       id="received_date"
                                       name="received_date" 
                                       class="form-control" 
                                       value="<?php echo e(old('received_date', $batch->received_date->format('Y-m-d'))); ?>" 
                                       max="<?php echo e(date('Y-m-d')); ?>"
                                       required>
                            </div>
                            <div class="col-md-6">
                                <label for="expiry_date" class="form-label">Expiry Date</label>
                                <input type="date" 
                                       id="expiry_date"
                                       name="expiry_date" 
                                       class="form-control" 
                                       value="<?php echo e(old('expiry_date', optional($batch->expiry_date)->format('Y-m-d'))); ?>">
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea id="notes" 
                                      name="notes" 
                                      class="form-control" 
                                      rows="3" 
                                      maxlength="1000"><?php echo e(old('notes', $batch->notes)); ?></textarea>
                        </div>

                        <div class="d-flex gap-2 flex-wrap">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Batch
                            </button>
                            <a href="<?php echo e(route('inventory.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Sidebar -->
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header"><strong>Batch Summary</strong></div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>PO Quantity:</span>
                        <strong><?php echo e(number_format($orderedQty, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Already Received:</span>
                        <strong><?php echo e(number_format($totalReceivedQty, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Receiving Now:</span>
                        <strong class="text-primary"><?php echo e(number_format($batch->initial_quantity, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Will Remain:</span>
                        <strong class="text-warning">
                            <?php echo e(number_format(max(0, $orderedQty - $totalReceivedQty - $batch->initial_quantity), 2)); ?>

                        </strong>
                    </div>

                    <?php if(count($selectedPoItems) > 0): ?>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Unit Price:</span>
                        <strong>₹<?php echo e(number_format($selectedPoItems[0]->unit_price, 2)); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span><strong>Batch Value:</strong></span>
                        <strong class="text-success">
                            ₹<?php echo e(number_format($selectedPoItems[0]->unit_price * $batch->initial_quantity, 2)); ?>

                        </strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const receivedDateInput = document.getElementById('received_date');
        const expiryDateInput = document.getElementById('expiry_date');

        function setExpiryMinDate() {
            if (receivedDateInput.value) {
                expiryDateInput.min = receivedDateInput.value;
            }
        }

        receivedDateInput.addEventListener('change', function () {
            setExpiryMinDate();

            // Optional: Clear expiry date if it’s invalid after changing received date
            if (expiryDateInput.value && expiryDateInput.value < receivedDateInput.value) {
                expiryDateInput.value = '';
            }
        });

        // Initialize on page load
        setExpiryMinDate();
    });
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/inventory/edit.blade.php ENDPATH**/ ?>