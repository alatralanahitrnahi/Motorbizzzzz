<?php $__env->startSection('title', 'Materials List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Materials</h3>
            <a href="<?php echo e(route('materials.create')); ?>" class="btn btn-primary">Add New Material</a>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Unit</th>
                        <th>Unit Price</th>
                        <th>GST Rate (%)</th>
                        <th>Available</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($material->name); ?></td>
                            <td><?php echo e($material->code); ?></td>
                            <td><?php echo e($material->unit); ?></td>
                            <td><?php echo e(number_format($material->unit_price, 2)); ?></td>
                            <td><?php echo e($material->gst_rate); ?>%</td>
                            <td>
                                <span class="badge bg-<?php echo e($material->is_available ? 'success' : 'secondary'); ?>">
                                    <?php echo e($material->is_available ? 'Yes' : 'No'); ?>

                                </span>
                            </td>
                            <td>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $material)): ?>
                                    <a href="<?php echo e(route('materials.show', $material->id)); ?>" class="btn btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $material)): ?>
                                    <a href="<?php echo e(route('materials.edit', $material->id)); ?>" class="btn btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $material)): ?>
                                    <form action="<?php echo e(route('materials.destroy', $material->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No materials found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($materials->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/materials/index.blade.php ENDPATH**/ ?>