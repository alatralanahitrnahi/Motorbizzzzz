<?php $__env->startSection('title', 'Warehouse Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">Warehouse Details: <?php echo e($warehouse->name); ?></h1>
        <div>
            <a href="<?php echo e(route('dashboard.warehouses.edit', $warehouse)); ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i> Edit
            </a>
           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignStaff', $warehouse)): ?>
    <a href="<?php echo e(route('dashboard.warehouses.assign-staff', $warehouse)); ?>" class="btn btn-success">
        <i class="fas fa-users"></i> Manage Staff
    </a>
<?php endif; ?>

            <a href="<?php echo e(route('dashboard.warehouses.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>

    <div class="row">
        <!-- Main Information -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Warehouse Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Name:</strong></td>
                                    <td>
                                      <span class="badge badge-info text-dark" style="font-size: 1rem;">
                               <?php echo e($warehouse->name); ?> </span>
                                  </td>
                                </tr>
                                <tr>
    <td><strong>Type:</strong></td>
    <td>
        <span class="badge badge-info text-dark" style="font-size: 1rem;">
            <?php echo e($warehouse->type_display); ?>

        </span>
    </td>
</tr>
<tr>
    <td><strong>Status:</strong></td>
    <td>
        <span class="badge badge-<?php echo e($warehouse->is_active ? 'success' : 'secondary'); ?> text-dark" style="font-size: 1rem;">
            <?php echo e($warehouse->is_active ? 'Active' : 'Inactive'); ?>

        </span>
    </td>
</tr>
<tr>
    <td><strong>Default:</strong></td>
    <td>
        <?php if($warehouse->is_default): ?>
            <span class="badge badge-warning text-dark" style="font-size: 1rem;">
                <i class="fas fa-star"></i> Default Warehouse
            </span>
        <?php else: ?>
            <span class="text-muted" style="font-size: 1rem;">No</span>
        <?php endif; ?>
    </td>
</tr>

                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Created:</strong></td>
                                    <td><?php echo e($warehouse->created_at->format('M d, Y g:i A')); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Last Updated:</strong></td>
                                    <td><?php echo e($warehouse->updated_at->format('M d, Y g:i A')); ?></td>
                                </tr>
                               <tr>
    <td><strong>Assigned Staff:</strong></td>
    <td>
        <span class="badge badge-primary"><?php echo e($warehouse->users->count()); ?></span>

    <a href="<?php echo e(route('dashboard.warehouses.assign-staff', $warehouse)); ?>" 
       class="btn btn-sm btn-outline-success ml-2">Manage</a>


    </td>
</tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Location Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Location Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <p><strong>Full Address:</strong></p>
                            <address class="ml-3">
                                <?php echo e($warehouse->address); ?><br>
                             <?php echo e($warehouse->city); ?>, <?php echo e($warehouse->state); ?><br>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Status toggle functionality
    $('.status-toggle').change(function() {
        const warehouseId = $(this).data('warehouse-id');
        const isActive = $(this).is(':checked');
        const status = isActive ? 'active' : 'inactive';
        
        $.ajax({
            url: `/dashboard/warehouses/${warehouseId}/toggle-status`,
            method: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                status: status
            },
            success: function(response) {
                if (response.success) {
                    const badge = $(this).siblings('label').find('.badge');
                    badge.removeClass('badge-success badge-secondary')
                         .addClass(isActive ? 'badge-success' : 'badge-secondary')
                         .text(isActive ? 'Active' : 'Inactive');
                    
                    toastr.success(response.message);
                }
            }.bind(this),
            error: function() {
                $(this).prop('checked', !isActive);
                toastr.error('Failed to update warehouse status');
            }.bind(this)
        });
    });

    // Delete warehouse functionality
    $('.delete-warehouse').click(function() {
        const warehouseId = $(this).data('warehouse-id');
        const warehouseName = $(this).data('warehouse-name');
        
        $('#warehouse-name').text(warehouseName);
        $('#delete-form').attr('action', `/dashboard/warehouses/${warehouseId}`);
        $('#deleteModal').modal('show');
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/warehouses/show.blade.php ENDPATH**/ ?>