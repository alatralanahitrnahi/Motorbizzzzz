<?php $__env->startSection('title', 'Vendor List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Vendors</h3>
            <a href="<?php echo e(route('vendors.create')); ?>" class="btn btn-primary">Add New Vendor</a>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php $__empty_1 = true; $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($loop->first): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Business Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Company Address</th>
                            <th>Warehouse Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                <?php endif; ?>
                        <tr>
                            <td><?php echo e($vendor->name); ?></td>
                            <td><?php echo e($vendor->business_name); ?></td>
                            <td><?php echo e($vendor->email); ?></td>
                            <td><?php echo e($vendor->phone); ?></td>
                            <td><?php echo e($vendor->company_address); ?></td>
                            <td><?php echo e($vendor->warehouse_address); ?></td>
                          <td>
    <div class="d-flex align-items-center gap-1">
      
<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'view', 'vendors')): ?>
    <a href="<?php echo e(route('vendors.show', $vendor)); ?>" class="btn btn-info btn-sm" title="View">
        <i class="fas fa-eye"></i>
    </a>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'edit', 'vendors')): ?>
    <a href="<?php echo e(route('vendors.edit', $vendor)); ?>" class="btn btn-warning btn-sm" title="Edit">
        <i class="fas fa-edit"></i>
    </a>
<?php endif; ?>


<?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'delete', 'vendors')): ?>
    <form action="<?php echo e(route('vendors.destroy', $vendor)); ?>" method="POST" onsubmit="return confirm('Delete this vendor?');" style="display:inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-sm btn-danger" title="Delete">
            <i class="fas fa-trash-alt"></i>
        </button>
    </form>
<?php endif; ?>

    </div>
</td>


                        </tr>
                <?php if($loop->last): ?>
                    </tbody>
                </table>

                <?php echo e($vendors->links()); ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center">No vendors found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/vendors/index.blade.php ENDPATH**/ ?>