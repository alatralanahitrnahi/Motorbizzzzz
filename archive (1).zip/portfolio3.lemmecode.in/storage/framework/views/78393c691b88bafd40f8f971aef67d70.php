<?php echo e($slot); ?>

<?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>