<?php $__env->startSection('content'); ?>

       <div class="container">
    <div class="row">
        <div class="col-12">
            <h2 class="mb-4">All Warehouses - Blocks & Slots</h2>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4 shadow-sm">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><?php echo e($warehouse->name); ?></h4>
                        <a href="<?php echo e(route('warehouses.blocks.create', $warehouse->id)); ?>" class="btn btn-light btn-sm">
                            <i class="fas fa-plus"></i> Add Block
                        </a>
                    </div>

                    <div class="card-body p-0">
                        <?php if($warehouse->blocks->isEmpty()): ?>
                            <div class="alert alert-info m-3">
                                <i class="fas fa-info-circle"></i> No blocks found for this warehouse.
                            </div>
                        <?php else: ?>
                            
                            <div class="d-none d-lg-block">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover mb-0">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Name</th>
                                                <th>Dimensions</th>
                                                <th>Total Slots</th>
                                                <th class="text-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $warehouse->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="fw-bold"><?php echo e($block->name); ?></td>
                                                    <td><?php echo e($block->rows); ?> × <?php echo e($block->columns); ?></td>
                                                    <td>
                                                        <span class="badge bg-info text-dark">
                                                            <?php echo e($block->slots->count()); ?> slots
                                                        </span>
                                                    </td>
                                                    <td class="text-center">
                                                        <div class="btn-group btn-group-sm">
                                                            <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'view', 'blocks')): ?>
                                                                <a href="<?php echo e(route('warehouses.blocks.show', [$warehouse->id, $block->id])); ?>"
                                                                   class="btn btn-outline-info" title="View">
                                                                    <i class="fas fa-eye"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                            <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'edit', 'blocks')): ?>
                                                                <a href="<?php echo e(route('warehouses.blocks.edit', [$warehouse->id, $block->id])); ?>"
                                                                   class="btn btn-outline-warning" title="Edit">
                                                                    <i class="fas fa-edit"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                            <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'delete', 'blocks')): ?>
                                                                <form action="<?php echo e(route('warehouses.blocks.destroy', [$warehouse->id, $block->id])); ?>"
                                                                      method="POST" class="d-inline">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-outline-danger"
                                                                            onclick="return confirm('Delete this block?')" title="Delete">
                                                                        <i class="fas fa-trash"></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            
                            <div class="d-lg-none">
                                <?php $__currentLoopData = $warehouse->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border-bottom px-3 py-3">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h6 class="fw-bold mb-1"><?php echo e($block->name); ?></h6>
                                                <div class="text-muted small mb-2">
                                                    <?php echo e($block->rows); ?> × <?php echo e($block->columns); ?> dimensions
                                                </div>
                                                <span class="badge bg-info text-dark">
                                                    <?php echo e($block->slots->count()); ?> slots
                                                </span>
                                            </div>
                                            <div class="text-end">
                                                <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'view', 'blocks')): ?>
                                                    <a href="<?php echo e(route('warehouses.blocks.show', [$warehouse->id, $block->id])); ?>"
                                                       class="btn btn-outline-info btn-sm mb-1">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'edit', 'blocks')): ?>
                                                    <a href="<?php echo e(route('warehouses.blocks.edit', [$warehouse->id, $block->id])); ?>"
                                                       class="btn btn-outline-warning btn-sm mb-1">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (\Illuminate\Support\Facades\Blade::check('canAccess', 'delete', 'blocks')): ?>
                                                    <form action="<?php echo e(route('warehouses.blocks.destroy', [$warehouse->id, $block->id])); ?>"
                                                          method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-outline-danger btn-sm"
                                                                onclick="return confirm('Delete this block?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/dashboard/warehouses/blocks/index.blade.php ENDPATH**/ ?>