<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .navbar, .btn, .alert, footer {
            display: none !important;
        }
        .card {
            page-break-inside: avoid;
            border: none;
            box-shadow: none;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Generated Barcodes</h2>

    <?php if(empty($barcodes)): ?>
        <div class="alert alert-warning">
            No barcodes generated.
        </div>
    <?php else: ?>
        <div class="text-end mb-3">
            <button onclick="window.print()" class="btn btn-outline-secondary">Print</button>
        </div>

        <div class="row">
        <?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card p-3 text-center shadow-sm">
            <h5 class="card-title mb-1">
                <?php echo e($entry['item']->item_name); ?>

            </h5>
            <p class="mb-1 fw-semibold text-primary">
                SKU: <?php echo e($entry['item']->sku); ?>

            </p>
            <p class="mb-1">
                Quantity: <?php echo e($entry['item']->quantity); ?>

            </p>
            <p class="mb-1 text-muted">
                Weight: <?php echo e($entry['item']->weight); ?>

            </p>
            <p class="mb-2 text-muted">
                Dimensions: <?php echo e($entry['item']->dimensions); ?>

            </p>
            <div class="barcode">
                <?php echo $entry['barcode']; ?>

            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lemmecode-portfolio3/htdocs/portfolio3.lemmecode.in/resources/views/quality/barcodes.blade.php ENDPATH**/ ?>