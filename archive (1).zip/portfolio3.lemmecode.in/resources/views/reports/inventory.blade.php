@extends('layouts.app')

@section('title', 'Inventory Report')

@section('content')
    <h1 class="text-2xl font-bold mb-4">Inventory Report</h1>

    <!-- Example table or report content -->
    <p>Report content goes here...</p>
@endsection
