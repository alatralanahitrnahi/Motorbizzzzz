<p>Hello Admin,</p>
<p>The vendor <strong>{{ $user->name }}</strong> has requested a missing material: <strong>{{ $materialName }}</strong>.</p>
<p>Please review and add it in the material section if valid.</p>
